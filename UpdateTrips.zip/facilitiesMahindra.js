const express = require("express");
const multer = require("multer");
const mongodb = require("@intugine-technologies/mongodb");
const fs = require("fs");
const bodyparser = require("body-parser");
const path = require("path");
const csv = require("fast-csv");
const axios = require("axios");
let __db = null;
const app = express();
//app.use(express.static('./public'))
app.use(bodyparser.json());
app.use(
  bodyparser.urlencoded({
    extended: true,
  })
);
mongodb(
  "mongodb+srv://rsaundatikar:XsYMMAtx8afuEmhY@cluster0.zhjde.mongodb.net/admin?retryWrites=true&replicaSet=Cluster0-shard-0&readPreference=secondaryPreferred&srvServiceName=mongodb&connectTimeoutMS=10000&authSource=admin",
  "telenitytracking"
).then((db) => {
  __db = db;
});
var storage = multer.diskStorage({
  destination: (req, file, callBack) => {
    callBack(null, "./uploads/");
  },
  filename: (req, file, callBack) => {
    callBack(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  },
});
var upload = multer({
  storage: storage,
});

app.post("/api/uploadcsv", upload.single("uploadcsv"), (req, res) => {
  csvToDb(__dirname + "/uploads/" + req.file.filename);
  res.json({
    msg: "File successfully inserted!",
    file: req.file,
  });
});
function csvToDb(csvUrl) {
  let stream = fs.createReadStream(csvUrl);
  let collectionCsv = [];
  let csvFileStream = csv
    .parse()
    .on("data", async function (data) {
      let element = {
        name: "A. T. AUTOMOBILES_Jaipur",
        client: "mahindra",
        client_client: "Mahindra Logistics Bussiness Unit 1",
        trip_location_type: ["DESTINATION"],
        location: [21.778109, 87.7517427],
        extra_info: {},
      };
      //console.log(data[0],data[1]);
      //process.exit(0);

      // if(data[1]=="location" || data[1].trim() == "#N/A"){
      //     return
      // }
      let res = null;
      try {
        //res = await axios.get(`https://tf9cehwrv7.execute-api.ap-south-1.amazonaws.com/dev?pincode=${data[3]}`)
        //  console.log(res.data)
        element["name"] = data[0];
        element["location"] = data[1].split(",").map((l) => parseFloat(l));

        //console.log(element)
        collectionCsv.push(element);
        // return
        //      process.exit(1)
      } catch (error) {
        console.log(error.message);
        console.log(data[1]);
        //return
      }

      //console.log(collectionCsv)
    })
    .on("end", async function () {
      // console.log("input data",collectionCsv)

      //db operation
      setTimeout(async function () {
        console.log(collectionCsv);
        console.log(collectionCsv.length, "shit");

        let result = await __db.create("facilities", collectionCsv);
        console.log(result);
      }, 10000);

      fs.unlinkSync(csvUrl);
    });
  stream.pipe(csvFileStream);
}
const PORT = process.env.PORT || 5555;
app.listen(PORT, () => console.log(`Node app serving on port: ${PORT}`));
