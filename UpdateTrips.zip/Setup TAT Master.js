
  //  this need to be added in customer_master_data in this format
//script customer_master_data_iocl.js
{
    "_id" : "IOCL|src_code+dest_code|0034+12345567",
    "createdAt" : new Date(),
    "client_client" : null,
    "data" : {
        "eta_days": 1.3
    },
    "key" : "src_code+dest_code",
    "user" : "IOCL",
    "value" : "0034+12345567"
}

 

// Also push to 'config.trips.master_data': {

// "key" : "src_code+dest_code",

// "trip_start_fields" : [

// "eta_days"

// ]

// }

// to all users of IOCL

db.getCollection("users").updateMany(
    {"config.client": "IOCL"},
    {
        $push:{
           
            'config.trips.master_data': {

                "key" : "src_code+dest_code",
                
                "trip_start_fields" : [ "eta_days"]
                
                }
        }
    })