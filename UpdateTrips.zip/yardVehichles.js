const express = require('express')
const multer = require('multer')
const mongodb = require('@intugine-technologies/mongodb')
const fs = require('fs')
const bodyparser = require('body-parser')
const path = require('path')
const csv = require('fast-csv')
const axios = require('axios')
let __db = null;
const app = express()
//app.use(express.static('./public'))
app.use(bodyparser.json())
app.use(
  bodyparser.urlencoded({
    extended: true,
  }),
)
mongodb("mongodb+srv://rsaundatikar:XsYMMAtx8afuEmhY@cluster0.zhjde.mongodb.net/admin?retryWrites=true&replicaSet=Cluster0-shard-0&readPreference=secondaryPreferred&srvServiceName=mongodb&connectTimeoutMS=10000&authSource=admin", "telenitytracking").then(db => {__db = db});
//mongodb("mongodb://localhost:27017", "firstDb").then(db => { __db = db })
var storage = multer.diskStorage({
  destination: (req, file, callBack) => {
    callBack(null, './uploads/')
  },
  filename: (req, file, callBack) => {
    callBack(
      null,
      file.fieldname + '-' + Date.now() + path.extname(file.originalname),
    )
  },
})
var upload = multer({
  storage: storage,
})

  let insertData = [];
  let sampleData = {
   

    // "_id" : "FKT EWAYBILL|srcname|",//branch code in sheet
    // "user" : "FKT EWAYBILL",
    // "key" : "srcname", 
    // "value" : "YKB_Flex",//branch code in sheet 
    // "data" : {
    //     "src" : "28.4770160000,76.7962030000" //lat, long in sheet
    // }

    
    "createdAt" : "date",
    "vendor_name" : "Camions Logistics Solutions Pvt Ltd",
    "truck_number" : "RJ32GD3084",
    "truck_length" : "32 FT"
  

};

app.post('/api/uploadcsv', upload.single('uploadcsv'), (req, res) => {
  csvToDb(__dirname + '/uploads/' + req.file.filename)
  res.json({
    msg: 'File successfully inserted!',
    file: req.file,
  })
})

function flattenAndLog(obj, prefix = '') {
    for (const key in obj) {
        if (typeof obj[key] === 'object' && !Array.isArray(obj[key])) {
            flattenAndLog(obj[key], prefix + key + '.');
        } else {
            console.log(prefix + key + ':', obj[key]);
        }
    }
}

function csvToDb(csvUrl) {
  let stream = fs.createReadStream(csvUrl)
  let csvFileStream = csv
    .parse()
    .on('data', async function (data) { console.log("Data",data)
    let temp_data = JSON.parse(JSON.stringify(sampleData));

    //temp_data._id = temp_data._id + data[0]; 
//     temp_data.value = data[0];
//     temp_data.data={
//         src : [parseFloat(data[1]),parseFloat(data[2])]  
// },

        temp_data.createdAt = new Date()
        temp_data.vendor_name = data[1],
        temp_data.truck_number = data[2],
        temp_data.truck_length = data[0].match(/\d+/)[0] + " FT"  
        temp_data.enterprise = data[3]


    // temp_data.customer_name = data[1];
    // temp_data[data.spocs.name] = data[1];
    // temp_data[data.spocs.contact.email] = [data[3]];
    // temp_data[data.spocs.contact.phone] = [data[2]];
    // temp_data[data.customer_name] = data[1];
      
    // name:data[1],
    // contact:{email:[data[3]],phone:[data[2]]},

    let res = await __db.update("yard_management_vehicles", {"truck_number" : temp_data.truck_number}, temp_data, {upsert:true});
  console.log(res, temp_data.truck_number)

     // insertData.push(temp_data)
    })
    .on('end', async function () {
      console.log("done");
     // console.log(insertData[16]);
      //flattenAndLog(insertData[16]);
    //   console.log("Inner Data",insertData[16].data);
    //   console.log("EMAIL AND PHONE",insertData[16].data.spocs.contact);

    //  let res = await __db.create("yard_management_vehicles", insertData, {upsert:true});
    //  console.log(res)
      fs.unlinkSync(csvUrl)
    })
  stream.pipe(csvFileStream)
}
const PORT = process.env.PORT || 5556
app.listen(PORT, () => console.log(`Node app serving on port: ${PORT}`))




