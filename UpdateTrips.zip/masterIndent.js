const express = require('express')
const multer = require('multer')
const mongodb = require('@intugine-technologies/mongodb')
const {ObjectId} = require("mongodb");

const fs = require('fs')
const bodyparser = require('body-parser')
const path = require('path')
const csv = require('fast-csv')
const axios = require('axios')
let __db = null;
const app = express()
//app.use(express.static('./public'))
app.use(bodyparser.json())
app.use(
  bodyparser.urlencoded({
    extended: true,
  }),
)
mongodb("mongodb+srv://rsaundatikar:XsYMMAtx8afuEmhY@cluster0.zhjde.mongodb.net/admin?retryWrites=true&replicaSet=Cluster0-shard-0&readPreference=secondaryPreferred&srvServiceName=mongodb&connectTimeoutMS=10000&authSource=admin", "__IMS__").then(db => {__db = db});
var storage = multer.diskStorage({
  destination: (req, file, callBack) => {
    callBack(null, './uploads/')
  },
  filename: (req, file, callBack) => {
    callBack(
      null,
      file.fieldname + '-' + Date.now() + path.extname(file.originalname),
    )
  },
})
var upload = multer({
  storage: storage,
})

  let insertData = [];
  let sampleData = {
 

    
    
    
    "client_name": "",	
    "new_address":"",
    "city"	:"",
    "state"	:"",
    "pincode"	:"",
    "reference_id"	:"",
    "client_spoc_name"	:"",
    "client_spoc_contact"	:"",
    "client_spoc_email"	:"",
    "sales_spoc_name"	:"",
    "sales_spoc_contact"	:"",
    "sales_spoc_email"	:"",
    "rsm_name"	:"",
    "rsm_contact"	:"",
    "rsm_email"	:"",
    "asm_name"	 :"",
    "asm_contact"	:"",
    "asm_email"	:"",
    "gstin"	:"",
    "user"	: "Centuary India",
    "created_by"	:"bangalore_cfpl@centuaryindia.com",
    "created_at"	: new Date(),
    "source" : [new ObjectId('64c26d4103e4aaafd02e3a5a')]
    			

    };

app.post('/api/uploadcsv', upload.single('uploadcsv'), (req, res) => {
  csvToDb(__dirname + '/uploads/' + req.file.filename)
  res.json({
    msg: 'File successfully inserted!',
    file: req.file,
  })
})
function csvToDb(csvUrl) {
  let stream = fs.createReadStream(csvUrl)
  let csvFileStream = csv
    .parse()
    .on('data', function (data) {
    let temp_data = JSON.parse(JSON.stringify(sampleData));

    temp_data.client_name = data[0]; 
    temp_data.new_address = data[1];
    temp_data.city = data[2]; 
    temp_data.state = data[3];
    temp_data.pincode = data[4]; 
    temp_data.reference_id = data[5];
    temp_data.client_spoc_name = data[6]; 
    temp_data.client_spoc_contact = data[7];
    temp_data.client_spoc_email = data[8]; 
    temp_data.sales_spoc_name = data[9];
    temp_data.sales_spoc_contact = data[10]; 
    temp_data.sales_spoc_email = data[11];
    temp_data.rsm_name = data[12]; 
    temp_data.rsm_contact = data[13];
    temp_data.rsm_email = data[14];
    temp_data.asm_name = data[15]; 
    temp_data.asm_contact = data[16];
    temp_data.asm_email = data[17]; 
    temp_data.gstin = data[18];
    
    
      
      insertData.push(temp_data)
    })
    .on('end', async function () {
      console.log("done")
      console.log(insertData)
    //   let res = await __db.create("customer_data", insertData);
      console.log(res)
      fs.unlinkSync(csvUrl)
    })
  stream.pipe(csvFileStream)
}
const PORT = process.env.PORT || 5555
app.listen(PORT, () => console.log(`Node app serving on port: ${PORT}`))




