const express = require("express");
const multer = require("multer");
const mongodb = require("@intugine-technologies/mongodb");
const fs = require("fs");
const bodyparser = require("body-parser");
const path = require("path");
const csv = require("fast-csv");
const axios = require("axios");
const _ = require("lodash");
let __db = null;
const app = express();

let globalObject = null;

//app.use(express.static('./public'))
app.use(bodyparser.json());
app.use(
  bodyparser.urlencoded({
    extended: true,
  })
);
mongodb(
  "mongodb+srv://rsaundatikar:XsYMMAtx8afuEmhY@cluster0.zhjde.mongodb.net/admin?retryWrites=true&replicaSet=Cluster0-shard-0&readPreference=secondaryPreferred&srvServiceName=mongodb&connectTimeoutMS=10000&authSource=admin",
  "telenitytracking"
).then((db) => {
  __db = db;
});
var storage = multer.diskStorage({
  destination: (req, file, callBack) => {
    callBack(null, "./uploads/");
  },
  filename: (req, file, callBack) => {
    callBack(
      null,
      file.fieldname + "-" + Date.now() + path.extname(file.originalname)
    );
  },
});
var upload = multer({
  storage: storage,
});

let insertData = [];
let sampleData = {
  _id: "IOCL|dest_code|",
  client_client: null,
  data: {
    dest: ["22.038284", "82.2996553"],
  },
  key: "dest_code",
  updatedAt: new Date(),
  user: "IOCL",
  value: "0000037636",
};

app.post("/api/uploadcsv", upload.single("uploadcsv"), async (req, res) => {
  globalObject = await csvToDb(__dirname + "/uploads/" + req.file.filename);
  for (let k of globalObject) {
    const output2 = await getGeocodeData(k.data.dest);
    k.data.dest = output2;

    // console.log(output);
    console.log(k);
    const [res] = await __db.read("customer_master_data", { _id: k._id });
    console.log(res);
    let output = null;
    if (res) {
      output = await __db.update(
        "customer_master_data",
        { _id: k._id },
        { $set: { ...k, updatedAt: new Date() } }
      );
    } else {
      output = await __db.create("customer_master_data", k);
    }
    console.log(output);

    // let res = await __db.create("customer_master_data", k);
    // console.log(res);
  }
  // console.log(globalObject);
  //console.log(globalObject, "New");
  res.json({
    msg: "File successfully inserted!",
    file: req.file,
  });
});

function flattenAndLog(obj, prefix = "") {
  for (const key in obj) {
    if (typeof obj[key] === "object" && !Array.isArray(obj[key])) {
      flattenAndLog(obj[key], prefix + key + ".");
    } else {
      console.log(prefix + key + ":", obj[key]);
    }
  }
}

async function getGeocodeData(address) {
  // console.log(address);
  const axios = require("axios");

  let config = {
    method: "get",
    maxBodyLength: Infinity,
    url: `https://api.geocoding.intusystems.info/geocode?address=${address}`,
    headers: {
      "x-api-key": "176E7CDD9FABF6958AEA15D3671CE",
    },
  };

  const { data } = await axios.request(config);
  // console.log(data);
  return data.lat_lon;
}

function csvToDb(csvUrl) {
  return new Promise((resolve, reject) => {
    let stream = fs.createReadStream(csvUrl);
    let csvFileStream = csv.parse();
    let insertData = [];

    csvFileStream
      .on("data", function (data) {
        let temp_data = JSON.parse(JSON.stringify(sampleData));

        temp_data._id = temp_data._id + data[0];
        temp_data.value = data[0];
        temp_data.data = {
          dest: data[1],
        };

        insertData.push(temp_data);
      })
      .on("end", function () {
        console.log("CSV parsing completed");
        resolve(insertData);
      })
      .on("error", function (err) {
        console.error("Error while parsing CSV:", err);
        reject(err);
      });

    stream.on("error", function (err) {
      console.error("Error reading CSV file:", err);
      reject(err);
    });

    stream.pipe(csvFileStream);
  });
}

const PORT = process.env.PORT || 5556;
app.listen(PORT, () => console.log(`Node app serving on port: ${PORT}`));
