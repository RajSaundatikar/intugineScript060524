'use strict';
var fs = require('fs');
var md5 = require('js-md5');
const mongo     = require("@intugine-technologies/mongodb");  
var Promise = require("bluebird");
const axios = require("axios");
const XLSX = require('xlsx');
let mongoURI = "mongodb+srv://rsaundatikar:XsYMMAtx8afuEmhY@cluster0.zhjde.mongodb.net/admin?retryWrites=true&replicaSet=Cluster0-shard-0&readPreference=secondaryPreferred&srvServiceName=mongodb&connectTimeoutMS=10000&authSource=admin";
let dbName = 'telenitytracking';
let mongoConn = null;
let locs = {};
let dbCount = 0;

mongo(mongoURI, dbName).then((db => { mongoConn = db}));
function start () {

    const data=[]

    mongoConn.aggregate("fastag_responses", 
    [
        {
            $group: {_id: "$tripId", tripId: {$first: "$tripId"}, truck_number: {$first: "$truck_number"}, events: {$first: "$result.events"}}
        },
        { $limit: 150 }
    ]).then(fastag_res => {
        console.log("Total fastag res", fastag_res.length)
        Promise.map(fastag_res, async function(fastag) {
            let [trip] = await mongoConn.read("trips", {_id: fastag.tripId}, "all", 0, 
            { 
                srcname: 1, 
                destname: 1, 
                startTime: 1, 
                endTime: 1, 
                base_google_distance: 1,
                src: 1, 
                dest: 1, 
                truck_number: 1});
            // let fastagCount = 1;
            // if (trip.length) {
                let src = trip.src;
                // for(let i=0; i<fastag.length; i++) {
                    // let e = fastag[i]
                    if (fastag.events?.length) {
                        for(let j=0; j<fastag.events.length; j++) {
                            let v = fastag.events[j]

                            const [tollLat, tollLon] = v.tollPlazaGeocode.split(',')

                            // console.log(v)
                            trip[`Toll Name ${j+1}`] = v.tollPlazaName;
                            trip[`Toll crossing ${j+1}`] = v.readTime;
                            //trip[`Distance ${j+1}`] = v.tollPlazaName;
                            let dest = v.tollPlazaGeocode.split(",").map(a => a.trim())
                            // console.log(src, dest)
                            let {data: {distance} = {}} = await axios.get(`https://api.geocoding.intusystems.info/onroad-distance?srclat=${src[0]}&srclon=${src[1]}&destlat=${tollLat}&destlon=${tollLon}`,  {headers: {
                                "x-api-key": "6PQ0B2804709A3WZ1JBHK4DS"
                            }})
                            src = dest;
                            trip[`Distance from source/previous toll ${j+1}`] = distance
                            // console.log(distance)
                        }
                    }
                // };
            // }
            // console.log(fastag)
            data.push(trip);
        }, {concurrency: 1}).then((res) => {// console.log(fastag)
            
            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils.json_to_sheet(data);
            XLSX.utils.book_append_sheet(workbook, worksheet, 'Data')
            XLSX.writeFile(workbook, './data.xlsx')


            // console.log("Doneeeeeeeeeeeeeeeeeeeeee", res)
            process.exit(0)
            // const csvString = [
            //     [
            //       "ID",
            //       "TruckNumber",
            //       "Src lat",
            //       "Src lon",
            //       "1",
            //       "Src State",
            //       "Src City",
            //       "Dest lat",
            //       "Dest lon",
            //       "2",
            //       "Dest State",
            //       "Dest City",
            //       "User",
            //       "Client",
            //       "Transporter",
            //       "Start time",
            //       "End time",
            //       "Base google distance"
            //     ],
            //     ...res.map(item => [
            //         item._id,
            //         item.truck_number,
            //         item.src,
            //         item.src1,
            //         item.src_state,
            //         item.src_city,
            //         item.dest,
            //         item.dest1,
            //         item.dest_state,
            //         item.dest_city,
            //         item.user,
            //         item.client,
            //         item.vendor,
            //         item.startTime,
            //         item.endTime,
            //         item.base_google_distance
            //     ])
            //   ]
            //    .map(e => e.join(",")) 
            //    .join("\n");
            // //    console.log("==========", csvString)
            // console.log("Total calls", dbCount, memCount)
            //    setTimeout(() => {
            //     fs.writeFile('google.csv', csvString, 'utf8', function(err) {
            //         if (err) {
            //           console.log('Some error occured - file either not saved or corrupted file saved.');
            //         } else {
            //           console.log('It\'s saved!');
            //           process.exit(0)
            //         }
            //       });
            //    }, 10000)
               
            
        })
    }).catch((err) => console.log("Err", err));

    // console.log(data)
}
async function abc(loc) {
    if (!Array.isArray(loc) || !loc.length) {
        return [];
    }
    loc  = loc.map(Number).reverse();
    loc = loc.filter(item => item && typeof item === 'number' )
    if (!loc.length) {
        return [];
    }
    // console.log("locccccc", loc)
    try {
        let loc_md5 = md5(loc);
        if (loc_md5 in locs) {
            memCount++;
            return locs[loc_md5];
        }
        let val =  await mongoConn1.read("district", {
            "geometry": {
            $geoIntersects: {
                $geometry: {
                "type": "Point",
                "coordinates":  loc
                }
            }
            }
        }, 1, 0, {"properties.NAME_1" : 1, "properties.NAME_2" : 1}, {});
        if (val.length) {
            locs[loc_md5] = val;
        }
        dbCount++;
        return val;
    } catch (err) {
        console.log("Err1", err);
        return [];
    }
}
setTimeout(start, 3000)