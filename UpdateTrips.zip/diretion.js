const axios = require('axios');
// const XLSX = require('xlsx');
const Promise = require('bluebird');
// const inspect = require('util').inspect;
// const fs = require('fs');
const Google = axios.create({
	baseURL: "https://maps.googleapis.com/maps/api"
})

const directions = (obj = {}) => {
	// console.log("@@@@@@@@@@",obj)
	const options = {
		url: '/directions/json',
		method: 'GET',
		params: {
			key: "AIzaSyAJcPw4EFmKrg3vkun5xyOIahw9slqiwQE",
			...obj
		}
	};
	// console.log(options)
	return Google(options)
	.then((r) => {
		return Promise.resolve({
			success: true,
			error: null,
			data: r.data
		})
	})
	.catch((e) => {
		console.error(e.response ? e.response.data : e)
		return Promise.resolve({
			success: false,
			error: e.response ? e.response.data : e,
			data: null
		})
	});
}

/*
const locations = `17.6588552,83.2021982
18.280262148823088, 83.33269722959625
18.573803845978464, 83.35842668755589
18.783180490463472, 83.42693049327328
19.17117217283112, 83.41498377488823
19.629153658648686, 83.50335067703169
19.984570833333333,83.30672972222222
20.112683888888892,83.08749666666667
20.286623618113655, 82.76226189377795
20.80605697207068, 82.5362277397236
21.04863793502615, 82.39871306466111
21.117321922308637, 82.08527050216193
21.202578745523322, 81.97366591976484
21.399477405195334, 81.9368601551027
21.539695541219732, 82.16784221186977
21.66563050348047, 82.16246118832498
21.6045644,82.0507869`.split(/\n/).map(k => k.replace(/\s/g, '').split(','));
*/

// 
const locations = `29.9266537,74.9645568
30.3667694,75.5031525
30.3467775,76.3266512
30.3721956,76.7362268
30.1322404,77.2290121
28.8896613,76.5339322
29.8614375,77.8536258
29.9266756,78.0649154`.split(/\n/).map(k => k.replace(/\s/g, '').split(','));


console.log(locations)
directions({
	origin: locations[0].join(),
	destination: locations.slice(-1)[0].join(),
	waypoints: locations.slice(1, -1).map(k => k.join()).join('|'),
    // optimizeWaypoints: true,
    //   travelMode: "DRIVING",
})
.then((r) => {
	console.log(r.data);
	if(r.data && r.data.routes && r.data.routes[0]){
		console.log("!!!!!!", r.data.routes[0])
		console.log(typeof r.data.routes[0].overview_polyline.points, r.data.routes[0].overview_polyline.points)
	}
})
.catch((e) => {
	console.error(e);
})


