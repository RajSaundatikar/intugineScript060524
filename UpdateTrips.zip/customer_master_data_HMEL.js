const express = require('express')
const multer = require('multer')
const mongodb = require('@intugine-technologies/mongodb')
const fs = require('fs')
const bodyparser = require('body-parser')
const path = require('path')
const csv = require('fast-csv')
const axios = require('axios')
let __db = null;
const app = express()
//app.use(express.static('./public'))
app.use(bodyparser.json())
app.use(
  bodyparser.urlencoded({
    extended: true,
  }),
)
mongodb("mongodb+srv://rsaundatikar:XsYMMAtx8afuEmhY@cluster0.zhjde.mongodb.net/admin?retryWrites=true&replicaSet=Cluster0-shard-0&readPreference=secondaryPreferred&srvServiceName=mongodb&connectTimeoutMS=10000&authSource=admin", "telenitytracking").then(db => {__db = db});
var storage = multer.diskStorage({
  destination: (req, file, callBack) => {
    callBack(null, './uploads/')
  },
  filename: (req, file, callBack) => {
    callBack(
      null,
      file.fieldname + '-' + Date.now() + path.extname(file.originalname),
    )
  },
})
var upload = multer({
  storage: storage,
})

  let insertData = [];
  let sampleData = {
  

    "_id" : "HMEL|destaddress|",
    "createdAt" : new Date(),
    "client_client" : null,
    "data" : {
        "dest": [29.202, 79.148]
    },
    "key" : "destaddress",
    "user" : "HMEL",
    "value" : "Polyplex Corporation Ltd 227MI-228MI Udham Singh Nagar 262401 Uttarakhand"
      

};

app.post('/api/uploadcsv', upload.single('uploadcsv'), (req, res) => {
  csvToDb(__dirname + '/uploads/' + req.file.filename)
  res.json({
    msg: 'File successfully inserted!',
    file: req.file,
  })
})

function flattenAndLog(obj, prefix = '') {
    for (const key in obj) {
        if (typeof obj[key] === 'object' && !Array.isArray(obj[key])) {
            flattenAndLog(obj[key], prefix + key + '.');
        } else {
            console.log(prefix + key + ':', obj[key]);
        }
    }
}

function csvToDb(csvUrl) {
  let stream = fs.createReadStream(csvUrl)
  let csvFileStream = csv
    .parse()
    .on('data', function (data) { console.log("Data",data)
    let temp_data = JSON.parse(JSON.stringify(sampleData));

    temp_data._id = temp_data._id + data[0]; 
    temp_data.value = data[0];
    temp_data.data = {
      dest  : JSON.parse(data[1])
    }

   // temp_data[data.src] = data[1];

   
    // temp_data.customer_name = data[1];
    // temp_data[data.spocs.name] = data[1];
    // temp_data[data.spocs.contact.email] = [data[3]];
    // temp_data[data.spocs.contact.phone] = [data[2]];
    // temp_data[data.customer_name] = data[1];
      



      insertData.push(temp_data)
    })
    .on('end', async function () {
      console.log("done");
       console.log(insertData);
      // flattenAndLog(insertData[16]);
    //   console.log("Inner Data",insertData[16].data);
    //   console.log("EMAIL AND PHONE",insertData[16].data.spocs.contact);

      let res = await __db.create("customer_master_data", insertData);
      console.log(res)

      // for(let k of insertData){
      //   console.log(k);
      //   let res = await __db.update('customer_master_data', {
      //     _id:k._id,
      // }, {
      //     $set: k,
      // }, {
      //     upsert: true,
      // });
      // console.log(res);
      // };

  //    
     


      // fs.unlinkSync(csvUrl)
    })
  stream.pipe(csvFileStream)
}
const PORT = process.env.PORT || 5555
app.listen(PORT, () => console.log(`Node app serving on port: ${PORT}`))

