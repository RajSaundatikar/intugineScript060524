const express = require('express')
const multer = require('multer')
const mongodb = require('@intugine-technologies/mongodb')
const fs = require('fs')
const bodyparser = require('body-parser')
const path = require('path')
const csv = require('fast-csv')
const axios = require('axios')

const app = express()
//app.use(express.static('./public'))
app.use(bodyparser.json())
app.use(
  bodyparser.urlencoded({
    extended: true,
  }),
)
mongodb("mongodb+srv://rsaundatikar:XsYMMAtx8afuEmhY@cluster0.zhjde.mongodb.net/admin?retryWrites=true&replicaSet=Cluster0-shard-0&readPreference=secondaryPreferred&srvServiceName=mongodb&connectTimeoutMS=10000&authSource=admin", "telenitytracking").then(db => {__db = db});
var storage = multer.diskStorage({
  destination: (req, file, callBack) => {
    callBack(null, './uploads/')
  },
  filename: (req, file, callBack) => {
    callBack(
      null,
      file.fieldname + '-' + Date.now() + path.extname(file.originalname),
    )
  },
})
var upload = multer({
  storage: storage,
})

app.post('/api/uploadcsv', upload.single('uploadcsv'), (req, res) => {
  csvToDb(__dirname + '/uploads/' + req.file.filename)
  res.json({
    msg: 'File successfully inserted!',
    file: req.file,
  })
})
function csvToDb(csvUrl) {
  let stream = fs.createReadStream(csvUrl)
  let collectionCsv = []
  let csvFileStream = csv
    .parse()
    .on('data', function (data) {
      collectionCsv.push(data)
    })
    .on('end', async function () {
      //console.log("input data",collectionCsv)

      //db operation
      
      for (let i=0; i<collectionCsv.length; i++) {
        await dbOperation(collectionCsv[i])
      }
      
      fs.unlinkSync(csvUrl)
    })
  stream.pipe(csvFileStream)
}
const PORT = process.env.PORT || 5555
app.listen(PORT, () => console.log(`Node app serving on port: ${PORT}`))

const dbOperation = async (data) => {
  console.log(data)
  let invoice = data[0].split(",")[0];
  // console.log("=======",invoice)
  let trip = await __db.read("trips", {"user" : "Sterlite", "running": {$ne:null}, "export_invoice": {$regex : invoice, $options : "i"}});
  trip = trip[0];
  // console.log(trip)

  let change = {
    expiresAt: null,
    tracking_tag: "CONTAINER-1",
    destname:data[1],
    dest: data[2].split(",").map(v => parseFloat(v)) 
  };
  let unset = {"$unset" : {"reached_set_time" : ""}};
  // console.log(change)
  // process.exit(0)
  let updateTrip = await __db.update("trips", {_id : trip._id}, change);
  let updateTrip1 = await __db.update("trips", {_id : trip._id}, unset);
  let restartTrip;
  try {
    restartTrip = await axios.put("https://sct.intutrack.com/api/test/trips/restart/"+trip._id, {}, {
      "auth": {
        "username": "dosSdn4gpC32xD1fcFOiJIIvhmukXjI4Y6Xpirv2kRL3dLphfRRNWBx841IJ5wdi",
        "password": "d1ZEFkdoB7Q7F5peeSFRbdANjpTGQfVzq4gkMfB5nEiPLoiFebdogM1CpaZEq7Qv"
      }
    })
  } catch (err) {
    console.log(trip._id, err.message)
  }

  console.log("id ====", trip._id, change, updateTrip, updateTrip1)
  //process.exit(0)
}