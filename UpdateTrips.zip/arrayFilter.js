const express = require('express')
const multer = require('multer')
const mongodb = require('@intugine-technologies/mongodb')
const fs = require('fs')
const bodyparser = require('body-parser')
const path = require('path')
const csv = require('fast-csv')
const axios = require('axios')
let __db = null;
const app = express()
//app.use(express.static('./public'))
app.use(bodyparser.json())
app.use(
  bodyparser.urlencoded({
    extended: true,
  }),
)
//mongodb("mongodb+srv://rsaundatikar:XsYMMAtx8afuEmhY@cluster0.zhjde.mongodb.net/admin?retryWrites=true&replicaSet=Cluster0-shard-0&readPreference=secondaryPreferred&srvServiceName=mongodb&connectTimeoutMS=10000&authSource=admin", "telenitytracking").then(db => {__db = db});
//mongodb("mongodb://localhost:27017", "firstDb").then(db => { __db = db })
var storage = multer.diskStorage({
  destination: (req, file, callBack) => {
    callBack(null, './uploads/')
  },
  filename: (req, file, callBack) => {
    callBack(
      null,
      file.fieldname + '-' + Date.now() + path.extname(file.originalname),
    )
  },
})
var upload = multer({
  storage: storage,
})

app.post('/api/uploadcsv', upload.single('uploadcsv'), (req, res) => {
  csvToDb(__dirname + '/uploads/' + req.file.filename)
  res.json({
    msg: 'File successfully inserted!',
    file: req.file,
  })
})
function csvToDb(csvUrl) {
  let stream = fs.createReadStream(csvUrl)
  let csvFileStream = csv
    .parse()
    .on('data', async function (data) {
    //   console.log(data)
            
    //$addToSet //It should be in array
      let updateData = {
        // "config.filter_trips_by": ["src_wh_code", "dest_zone", "drops.customer_code"],
        // "config.src_wh_code": data[1].split(",").map(e => e.trim()),
        // "config.dest_zone": data[1].split(",").map(e => e.trim()),
        // config["drops.customer_code"]: data[1].split(",")

        "config.trips.newtripinputfields.$[elem].values" : [{      
          "name":data[1] //data[1]
  }],
  "config.trips.newtripinputfields.$[elem].type": "list"

      }
      
    //   console.log(updateData)
      let res = await __db.update("users", {username: data[0].toLowerCase()}, {$push:updateData}, {
        arrayFilters: [
                        { "elem.key": "vendor" }
        ]
    } )

    
       console.log(res, "username:", data[0])
    })
    .on('end', function () {
      console.log("done")
      fs.unlinkSync(csvUrl)
    })
  stream.pipe(csvFileStream)
}
const PORT = process.env.PORT || 5556
app.listen(PORT, () => console.log(`Node app serving on port: ${PORT}`))

   // "config.filter_trips_by":["location_code"],
   // "config.location_code":["2022", "2008"]




//{"config.filter_trips_by" : [data[1]], key : data[2].map(l => parseFloat(l)) }

    //element["location"] = data[1].split(',').map(l => parseFloat(l));