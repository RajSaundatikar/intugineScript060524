
    const mongo = require('@intugine-technologies/mongodb');
const excelFilePath = 'listOfUsers.xlsx';
const DB_URI = 'mongodb://intugine:NkVPR6VQUEXhyUwYHgQg4hjHspDH5k9a@cluster0-shard-00-00-zhjde.mongodb.net:27017,cluster0-shard-00-01-zhjde.mongodb.net:27017,cluster0-shard-00-02-zhjde.mongodb.net:27017/telenitytracking?replicaSet=Cluster0-shard-0&ssl=true&authSource=admin';
const DB_NAME = 'telenitytracking';
const ExcelJS = require('exceljs');

async function readExcelData(filePath) {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(filePath);
    const worksheet = workbook.getWorksheet(1);
  
    const data = [];
  
    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber !== 1) {
        // Assuming the first row contains headers
        const rowData = {};
        row.eachCell((cell, colNumber) => {
          rowData[worksheet.getCell(1, colNumber).value] = cell.value;
        });
        data.push(rowData);
      }
    });
  
    return data;
}


mongo(DB_URI,DB_NAME).then(async(db)=>{
    console.log("DB CONNECTED");
    const excelData = await readExcelData(excelFilePath);
    const userlist = excelData.map((u)=>u.Username);
    const dbUserlist = await db.read('users',{username:{$in:userlist}},'all',0,{username:1});
    const dbUserArray = dbUserlist.map((d)=>d.username);
    const filtereduser = userlist.filter((u)=>!dbUserArray.includes(u))
    console.log("User not present in DB are:",filtereduser);
})