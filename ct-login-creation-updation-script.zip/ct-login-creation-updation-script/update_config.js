const addNewEscalation = () => {
  const new_escalation = {
    $push: {
      "config.issues": {
        tag: "Ewaybill Expiry",
        func: "eway_bill_expiry",
        params: [
          {
            time_threshold: 1440.0,
            priority: "MEDIUM",
            rep_allowed: true,
          },
          {
            time_threshold: 0.0,
            priority: "HIGH",
            rep_allowed: true,
          },
        ],
      },
    },
  };
  return new_escalation;
};

const UPDATE_CONFIG = {
  update_query: [{ client: "Intugine Demo", update: addNewEscalation() }],
};

export default UPDATE_CONFIG;
