import * as dotenv from "dotenv";
dotenv.config();

import { dbConnection, fetchSctUserConfig, updateSctConfig } from "./src/db.js";
import { createCtLogins } from "./src/process.js";
import CONFIG from "./config.js";
import { saveAsJson } from "./src/utils.js";

/*
  Set .env for DB_URI, SCT_DB, CT_DB, API_KEY, BASE_URL
*/
const generateLogins = async () => {
  let sct_db = null;
  try {
    sct_db = await dbConnection(process.env.SCT_DB);

    for (const login_cred of CONFIG.login_creds) {
      const [sct_config] = await fetchSctUserConfig(sct_db, login_cred);

      if (sct_config) {
        let new_ct_login = await createCtLogins(login_cred, sct_config);

        if (new_ct_login) {
          // Backup of SCT user config
          saveAsJson(
            { sct_config, ct_config: new_ct_login },
            `${
              new_ct_login.username
            }_sct_ct_config_${new Date().toDateString()}`
          );

          let updated_sct_config = await updateSctConfig(
            sct_db,
            new_ct_login,
            sct_config
          );
          if (updated_sct_config?.modifiedCount) {
            console.log(
              "User Creation Successful: ",
              new_ct_login,
              updated_sct_config
            );
          } else {
            console.log(
              "User Creation Failed: ",
              new_ct_login,
              updated_sct_config
            );
          }
        }
      } else {
        console.log(`No config found for '${login_cred.username}' in SCT`);
      }
    }
  } catch (error) {
    console.log(error);
  } finally {
    sct_db.close();
  }
};

generateLogins();
