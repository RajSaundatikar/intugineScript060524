///// users

db.getCollection("users").updateMany(
  { "config.client": { $in: ["HMEL", "IOCL", "BAYER"] } },
  {
    $set: {
      "config.location_providers": {
        airtel: {
          provider: "TELENITY",
          service: "IVRALT",
        },
        idea: {
          provider: "TELENITY",
          service: "IVRALT",
        },
        vodafone: {
          provider: "TELENITY",
          service: "IVRALT",
        },
        jio: {
          provider: "JIO",
          service: "DEFAULT",
        },
        bsnl: {
          provider: "TELENITY",
          service: "SMARTTRAIL",
        },
      },
      "config.pingrate": 900000,
    },
  }
);

///// trips
db.getCollection("trips").updateMany(
  { user: { $in: ["HMEL", "IOCL", "BAYER"] }, running: true },
  {
    $set: {
      ping_rate: 900000,
    },
  }
);
