db.getCollection("users").updateMany(
  { "config.client": "bridgestone_ewb" },
  { $set: { "config.tracking.parallel_fastag_fallback": true } }
);

////
db.getCollection("trips").updateMany(
  { user: "bridgestone_ewb", running: true },
  {
    $set: { "tracking.parallel_fastag_fallback": true },
  }
);
