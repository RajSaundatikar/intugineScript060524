// Set 'config.trips.expire_trip_based_on_sla': {
// 'operator': "+",
// threshold: 3 * 24 * 60 * 60 * 1000
// }
// in all ussers of this client i.e. PANTOS

// Also set in running trips similar to fixed threshold in trips where eta_days is not null, set expiresAt will be startTime + (eta_days) * 24 * 60 * 60 * 1000 + 3 * 24 * 60 * 60 * 1000

//"config.client":"PANTOS"

db.getCollection("users").updateMany(
    { "config.client": "PANTOS" },
    {
      "$set": {
        "config.trips.expire_trip_based_on_sla": {
          "operator": "+",
          "threshold": 259200000
        }
       
      }
    }
  );

  /////
  //May

  db.getCollection("trips")
  .find({
    user: "PANTOS",
    running: true,
    eta_days:{$ne:null},
    $or: [{
      expiresAt: null,
    }, {
      expiryNote: 'Expiry based on TAT exceeded'
    }]
  })
  .sort({ _id: -1 })
  .forEach((k) => {
    print(
      k.startTime,k.eta_days,
      new Date(k.startTime.valueOf() + k.eta_days * 24 * 60 * 60 * 1000 + 259200000)
    );

    db.getCollection("trips").updateOne(
      { _id: k._id },

      {
        $set: {
          expiresAt: new Date(k.startTime.valueOf() + (parseFloat(k.eta_days) * 24 * 60 * 60 * 1000) + 259200000),
          expiryNote: 'Expiry based on TAT exceeded'
        },
      }
    );
  });





  /////
//Rev
//   db.getCollection("trips")
//   .find({
//     user: "PANTOS",
//     running: true,
//     eta_days:{$ne:null}
//   })
//   .sort({ _id: -1 })
//   .forEach((k) => {
//     print(
//       k.startTime,k.eta_days,
//       new Date(k.startTime.valueOf() + k.eta_days * 24 * 60 * 60 * 1000 + 259200000)
//     );

//     db.getCollection("trips").updateOne(
//       { _id: k._id },

//       {
//         $set: {
//           expiresAt: new Date(k.startTime.valueOf() + k.eta_days * 24 * 60 * 60 * 1000 + 259200000),
          
//         },
//       }
//     );
//   });