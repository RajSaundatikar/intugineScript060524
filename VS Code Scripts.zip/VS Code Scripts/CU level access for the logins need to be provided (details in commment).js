
 


     db.getCollection("users").updateOne(
                { 
                    username:"bayer_east"},
                {
                    $set:{
                        "config.filter_trips_by": ["src_wh_code", "dest_zone"],

                        "config.src_wh_code": ["IN44", "IN47", "IN70", "IN61", "IN29", "IN42", "IN45", "IN35", "IN39", "7719", "7718", "2020", "2136", "2030", "2014", "7715", "7716", "7717"],

                        "config.dest_zone": ["IN44", "IN47", "IN70", "IN61", "IN29", "IN42", "IN45", "IN35", "IN39", "7719", "7718", "2020", "2136", "2030", "2014", "7715", "7716", "7717"]
                    }
                })

    
                db.getCollection("users").updateOne(
                    { 
                        username:"bayer_north"},
                    {
                        $set:{
                            "config.filter_trips_by": ["src_wh_code", "dest_zone"],
    
                            "config.src_wh_code": ["IN33","IN40","IN41","IN49","IN65","IN69","IN24","IN37","2028","7713","7707","2025","2023","7711","7712","7708"],
    
                            "config.dest_zone": ["IN33","IN40","IN41","IN49","IN65","IN69","IN24","IN37","2028","7713","7707","2025","2023","7711","7712","7708"]
                        }
                    })

                    

                 db.getCollection("users").updateOne(
                        { 
                            username:"bayer_south"},
                        {
                            $set:{
                                "config.filter_trips_by": ["src_wh_code", "dest_zone"],
        
                                "config.src_wh_code": ["IN56","IN46","IN38","IN31","IN67","2027","7705","5712","2017","7706"],
        
                                "config.dest_zone": ["IN56","IN46","IN38","IN31","IN67","2027","7705","5712","2017","7706"]
                            }
                        })

    
                
                
                db.getCollection("users").updateOne(
                        { 
                            username:"bayer_west"},
                        {
                            $set:{
                                "config.filter_trips_by": ["src_wh_code", "dest_zone"],
        
                                "config.src_wh_code": ["IN22","IN79","IN23","IN25","IN21","2021","7502","2024","7721","7720"],
        
                                "config.dest_zone": ["IN22","IN79","IN23","IN25","IN21","2021","7502","2024","7721","7720"]
                            }
                        })


                        