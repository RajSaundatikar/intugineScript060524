db.getCollection("users").updateMany(
  { "config.client": "MRC India" },
  { $set: { "config.tracking.parallel_fastag_fallback": true } }
);

////

db.getCollection("trips").updateMany(
  { user: "MRC India", running: true },
  {
    $set: { "tracking.parallel_fastag_fallback": true },
  }
);
