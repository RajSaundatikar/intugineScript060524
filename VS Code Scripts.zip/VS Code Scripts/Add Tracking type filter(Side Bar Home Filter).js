
    // 'config.home.options.additional_filters':{
    //                     "key" : "tracking_type",
    //                     "label" : "Tracking Type",
    //                     "values" : [
    //                         "Fastag Tracked",
    //                         "Fastag Untracked",
    //                         "SIM Tracked",
    //                         "SIM Untracked",
    //                         "GPS Tracked",
    //                         "GPS Untracked"
    //                     ]
    //                 }

         db.getCollection("users").updateMany(
            {'config.client': "HMEL"},
            {
                $addToSet:{
                    'config.home.options.additional_filters':{
                            "key" : "tracking_type",
                            "label" : "Tracking Type",
                            "values" : [
                            "Fastag Tracked",
                            "Fastag Untracked",
                            "SIM Tracked",
                            "SIM Untracked",
                            "GPS Tracked",
                            "GPS Untracked"
                        ]

                    }
                }
            })