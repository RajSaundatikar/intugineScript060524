db.getCollection("users").updateMany(
  {
    "config.client": "bridgestone",
    "config.ewaybillParams": { $exists: true },
  },
  {
    $push: {
      "config.ewaybillParams.autoExtendEnabled.cc_email":
        "hatimsunelwala@intugine.com",
    },
  }
);
