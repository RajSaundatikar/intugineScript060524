
       //Halt Alerts

      db.getCollection("users").updateMany(
        {"config.client" : "Starline Express"},
        {
            "$set":
        
            {
                "config.alerts.halt": {
                    "recipients": {
                        "internal": [
                            "support@intugine.com"
                        ],
                        "client": ["prabinkaran@starlineexpress.co.in", "skroadways.bbsr@gmail.com", "starlineoffice@starlineexpress.co.in", "shawn@intugine.com"]
        
                    },
                    "haltParams": [{
                        "durationThreshold": 21600000,
                        "sendOncePerHalt": true,
                        "recipients": [
        
                        ]
                    }]
                }
            }
        
        })
    