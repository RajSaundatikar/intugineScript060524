
       db.getCollection("users").updateMany(
  { "config.client": "IOCL" },
  {
    $set: {
      "config.reachParams.geofence": 25000
    },
  }
);