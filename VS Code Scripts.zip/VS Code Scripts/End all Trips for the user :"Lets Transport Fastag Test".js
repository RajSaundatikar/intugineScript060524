
     db.getCollection("trips").updateMany(
        {"user": "Lets Transport Fastag Test", "running": true},
        {
        $set:{
           "expiresAt": new Date(),
           "expiryNote": "Forced ended"
        }
        })