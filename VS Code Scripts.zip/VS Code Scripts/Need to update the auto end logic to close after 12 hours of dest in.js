
    db.getCollection("users").updateMany(
    {"config.client": "Woodpeckers Distilleries & Breweries Pvt. Ltd (SOM INDIA)"},
        {    
            $set:{
                
                "config.reachParams.geofence_in.trip_changes.endsIn": 43200000
                }
        }
    )