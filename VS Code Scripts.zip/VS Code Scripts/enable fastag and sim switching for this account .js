
    


    db.getCollection("users").updateMany(
  { "config.client": "ASAHI GLASS" },
  { $set: { "config.tracking.parallel_fastag_fallback": true } }
);

////

db.getCollection("trips").updateMany(
  { user: "ASAHI GLASS", running: true },
  {
    $set: { "tracking.parallel_fastag_fallback": true },
  }
);