
    db.getCollection("users").updateMany(
    {"config.client": "yatayat"},
    {
        $set:{
            "config.trips.distance_based_tat":{
                "distance" : 250000
            }
        }
    })