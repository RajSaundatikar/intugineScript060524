
    {
    
    "userId" : ObjectId("61d2d0782210a8363fda6664"),
    "type" : "credit",
    "previous_state" : {
        "previous_state" : {
            "_id" : ObjectId("61d2d0782210a8363fda6664"),
            "client" : "total integrated logistics solutions",
            "client_name" : "",
            "client_client" : "",
            "available_credits" : NumberInt(-2),
            "env" : "live",
            "tel" : [
        
            ],
            "email" : [
        
            ],
            "createdAt" : ISODate("2022-01-03T10:31:20.168+0000"),
            "updatedAt" : ISODate("2023-10-21T13:02:47.377+0000"),
            "is_locked" : false,
            "account_status" : "activated",
            "mail_alerts" : {
                "10_CREDIT_MAIL" : true,
                "5_CREDIT_MAIL" : true,
                "0_CREDIT_MAIL" : true
            }
        }
    },
    "amount" : NumberInt(4800),
    "total_amount" : NumberInt(4798),
    "manual" : true,
    "createdAt" : ISODate("2023-11-03T05:29:33.395+0000")
}
