db.getCollection("users").updateOne(
  { username: "usldiageotgadmin@intugine.com" },
  {
    $set: {
      "config.filter_trips_by": ["srcname"],
      "config.srcname": ["RK Distilleries", "Nacharam", "Malkajgiri"],
    },
  }
);
