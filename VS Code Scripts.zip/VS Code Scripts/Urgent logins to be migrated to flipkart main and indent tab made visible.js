
     db.getCollection("users").updateMany(
        { "username": { $in: ["tarun.kumar2@flipkart.com", "sumit.satbir@flipkart.com", "anuj.saini@flipkart.com", "sukhdev.singh@flipkart.com", "harpreetsingh.k@flipkart.com", "arunkumar.d@flipkart.com", "satyanarayana.m@flipkart.com", "p.ramu@flipkart.com", "umesh.m@flipkart.com", "chinmoy.kk@flipkart.com", "vhora.izamamul@flipkart.com", "sujit.p@flipkart.com", "tushar.sanjay@flipkart.com", "sourav.mourya@flipkart.com", "sunil.sharma3@flipkart.com", "ajay.pandey8@flipkart.com", "pradeepkumar.m1@flipkart.com", "yogesh.kumar5@flipkart.com", "bhupesh.kumar@flipkart.com", "mohit.beniwal@flipkart.com", "rahul.kaushik@flipkart.com", "ravi.sheoran@flipkart.com", "aniket.sagar@flipkart.com", "mohit.a@flipkart.com", "khaveer.husain@flipkart.com", "jony.k@flipkart.com", "mishra.mukesh@flipkart.com", "dinesh.kp@flipkart.com", "pradeep.charles@flipkart.com", "khaveer.husain@flipkart.com"] } },
        {
            $set: {
                "config.client" : "FKT_Main"
            }
        })

        



        db.getCollection("users").find(
            {
                username: { $in: ["tarun.kumar2@flipkart.com", "sumit.satbir@flipkart.com", "anuj.saini@flipkart.com", "sukhdev.singh@flipkart.com", 
        "harpreetsingh.k@flipkart.com", "arunkumar.d@flipkart.com", "satyanarayana.m@flipkart.com", "p.ramu@flipkart.com", "umesh.m@flipkart.com", "chinmoy.kk@flipkart.com", 
        "vhora.izamamul@flipkart.com", "sujit.p@flipkart.com", "tushar.sanjay@flipkart.com", "sourav.mourya@flipkart.com", "sunil.sharma3@flipkart.com", "ajay.pandey8@flipkart.com",
         "pradeepkumar.m1@flipkart.com", "yogesh.kumar5@flipkart.com", "bhupesh.kumar@flipkart.com", "mohit.beniwal@flipkart.com", "rahul.kaushik@flipkart.com", "ravi.sheoran@flipkart.com", 
         "aniket.sagar@flipkart.com", "mohit.a@flipkart.com", "khaveer.husain@flipkart.com", "jony.k@flipkart.com", "mishra.mukesh@flipkart.com", "dinesh.kp@flipkart.com", 
         "pradeep.charles@flipkart.com", "khaveer.husain@flipkart.com"] }, 

         "config.navbar_headers_field":{$exists:true} 
         
        }).count()
