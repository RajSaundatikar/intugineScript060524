// UAT so hil_testing and not hil
    db.getCollection("customer_master_data").insertMany([
    {
        "_id" : "superprocuretest|partnerClientId#partnerBranchId|HIL1#HIL12006",
        "user" : "superprocure",
        "client_client" : null,
        "key" : "partnerClientId#partnerBranchId",
        "value" : "HIL1#HIL12006",
        "data" : {
        "username" : "hil_testing"
        },
        "updatedAt" : new Date()
    },
    {
            "_id" : "superprocuretest|partnerClientId#partnerBranchId|HIL1#HIL12032",
            "user" : "superprocure",
            "client_client" : null,
            "key" : "partnerClientId#partnerBranchId",
            "value" : "HIL1#HIL12032",
            "data" : {
            "username" : "hil_testing"
            },
            "updatedAt" : new Date()
     }

    ])







//     Plant Code : 2006


// 	"partnerClientId": "HIL1",
// 	"partnerBranchId": "HIL12006"

// Plant Code : 2032


// 	"partnerClientId": "HIL1",
// 	"partnerBranchId": "HIL12032"

///He wanted I not 1 
{
    "_id" : "superprocuretest|partnerClientId#partnerBranchId|HILI#HIL12006",
    "user" : "superprocure",
    "client_client" : null,
    "key" : "partnerClientId#partnerBranchId",
    "value" : "HILI#HIL12006",
    "data" : {
    "username" : "hil_testing"
    },
    "updatedAt" : new Date()
}