//Cfa.hubli@himalayawellness.com



    db.getCollection("users").updateOne(
        {"username":"cfa.hubli@himalayawellness.com"},
        {
            $set:{
                "config.filter_trips_by":["shipToCode"],
                "config.shipToCode":["7028"]
            }
        })