
db.getCollection("users").updateMany(
    {"config.client": "BAYER"},
    { $set:{
        "config.tracking.webhookQueuePushEnabled": false
    } })

    db.getCollection("trips").updateMany(
        {user: "BAYER", running: true},
        {
            $set:{
                "tracking.webhookQueuePushEnabled": false
            }
        }
        )