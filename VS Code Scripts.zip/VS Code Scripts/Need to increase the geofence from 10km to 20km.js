
    db.getCollection("users").updateMany(
  { "config.client": "BAYER" },
  {
    $set: {
      "config.reachParams.geofence": 20000,
      "config.tracking.geofence_radius.drop": 20000
    }
  }
);