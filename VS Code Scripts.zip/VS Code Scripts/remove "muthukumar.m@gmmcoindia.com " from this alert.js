db.getCollection("users").updateMany(
    {"config.client":"GMMCO INDIA", "config.alerts.halt":{$exists:true} },
    {
        $set:{
            "config.alerts.halt" : {
   
                "isTripLevel" : true,
                "recipients" : {
                    "internal" : [
                        "mandar@intugine.com",
                        "support@intugine.com"
                    ],
                    "client" : [
        
                    ]
                },
                "haltParams" : [
                    {
                        "durationThreshold" : NumberInt(21600000),
                        "sendOncePerHalt" : true,
                        "recipients" : [
                            "appavuraja.b@gmmcoindia.com",
                            "hidayathullah.m@gmmcoindia.com"
                        ]
                    },
                    {
                        "durationThreshold" : NumberInt(43200000),
                        "sendOncePerHalt" : true,
                        "recipients" : [
                            "appavuraja.b@gmmcoindia.com", "Rajeshkumar.k@gmmcoindia.com", "hidayathullah.m@gmmcoindia.com"
                        ]
                    },
                    {
                        "durationThreshold" : NumberInt(86400000),
                        "sendOncePerHalt" : true,
                        "recipients" : [
                            "appavuraja.b@gmmcoindia.com", "Rajeshkumar.k@gmmcoindia.com", "hidayathullah.m@gmmcoindia.com"
                        ]
                    }
                ]
            
         }
        }
    }
)

