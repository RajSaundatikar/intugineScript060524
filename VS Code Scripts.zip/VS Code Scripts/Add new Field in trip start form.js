db.getCollection("users").updateMany(
  { "config.client": "USL Diageo" },
  {
    $push: {
      "config.trips.newtripinputfields": {
        key: "lock_otp_phone",
        placeholder: "Phone Numbers for OTP",
        type: "text",
      },
    },
  }
);
