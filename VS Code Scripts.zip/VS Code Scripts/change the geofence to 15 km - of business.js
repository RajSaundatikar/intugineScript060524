
     db.getCollection("users").updateMany(
  { "config.client": "OF BUSINESS" },
  {
    $set: {
      "config.reachParams.geofence": 15000
    },
  }
);
