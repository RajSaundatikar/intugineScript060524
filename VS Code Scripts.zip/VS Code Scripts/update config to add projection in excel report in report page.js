
    


     db.getCollection("users").updateMany(
        {'config.client': "FKT_Main"},
        {
            $set:{
                "config.reports.otheroption.fetch_specific_keys" : true
            }
        }
     )