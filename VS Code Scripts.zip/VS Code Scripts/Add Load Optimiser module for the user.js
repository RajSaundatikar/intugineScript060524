Pushed in "config.extra_headers"
            {
                "title" : "LOAD OPTIMIZER",
                "icon" : "",
                "path" : "/load-optimizer",
                "show" : true
            }
And if navbar header exists push in it
Pushed   "/load-optimizer" in "config.show_pages" if show_pages exist
