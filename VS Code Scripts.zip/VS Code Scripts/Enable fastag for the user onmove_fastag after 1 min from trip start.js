
    db.getCollection("configurations").insertOne({
    action: "ENABLE_FASTAG_IN_TRIPS",
    user: "Onmove ",
    threshold: {
    from: "TRIP_START",
    duration: 60000,
    },
    });


"Onmove "