
    //Halt Alerts
        db.getCollection("users").updateMany(
            {"config.client" : " Drop truck"},
            {
                $set:
                {
                    "config.alerts.halt": {
                        "recipients": {
                            "internal": [
                                "support@intugine.com"
                            ],
                            "client": ["naveen@droptruck.in"]
            
                        },
                        "haltParams": [{
                            "durationThreshold": 7200000,
                            "sendOncePerHalt": true,
                            "recipients": [
            
                            ]
                        }]
                    }
                }
            
            })
        
        
            //ETA Breach and Geofence Alerts
        
            db.getCollection("geofence_alerts_temp").insertOne(
                {
                "user" : " Drop truck",
                "geofenceAlertData" : {
                "src": 5000,
                "dest": 5000,
                "disableMailAlerts" : false,
                "displayName" :" Drop truck",
                "alert_emails" : ["naveen@droptruck.in"]
                }
        
                })
    
    
    
    
    
                  //mis
    
    {
        "action": "TRIGGER_MIS_REPORT",
        "user": " Drop truck",
        "query": {
          "client_client": null
        },
        "cron_expression": "30 4 * * *",
        "config": {
          "recipients": {"to" : ["naveen@droptruck.in"]}
        }
      }