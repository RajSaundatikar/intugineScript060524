
    db.getCollection("users").updateMany(
            {"config.client" : "Himalaya Production"},
            {
                $set:{
                    "config.trips.otheroption.validate_status_update": true
                }
            })

    
            // db.getCollection("users").updateMany(
            //     {"config.client" : "Himalaya Production"},
            //     {
            //         $set:{
            //             "config.trips.otheroption.validate_status_update": false
            //         }
            //     })