//users
db.getCollection("users").updateMany(
  { "config.client": "mahindra" },
  {
    $set: {
      "config.pingrate": 1800000,
    },
  }
);

///// trips
db.getCollection("trips").updateMany(
  { user: "mahindra", running: true },
  {
    $set: {
      ping_rate: 1800000,
    },
  }
);
