db.getCollection("users").updateOne(
  { username: "dakuri.venkatsrinivas@bayer.com" },
  {
    $set: {
      "config.filter_trips_by": [
        "dest_zone",
        "src_wh_code",
        "drops.customer_code",
      ],
      "config.dest_zone": ["IN71", "IN72", "IN73"],
      "config.src_wh_code": ["IN71", "IN72", "IN73"],
    },
  }
);

db.getCollection("users").updateOne(
  { username: "erappa.aremal@bayer.com" },
  {
    $set: {
      "config.filter_trips_by": [
        "dest_zone",
        "src_wh_code",
        "drops.customer_code",
      ],
      "config.dest_zone": ["2299", "2010", "2008"],
      "config.src_wh_code": ["2299", "2010", "2008"],
    },
  }
);
