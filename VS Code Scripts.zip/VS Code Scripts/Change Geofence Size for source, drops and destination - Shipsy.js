
     db.getCollection("users").updateMany(
  { "config.client": "Shipsy" },
  {
    $set: {
      "config.reachParams.geofence": 20000,
      "config.tracking.geofence_radius.drop": 20000,
      "config.reachParams.geofence_in.trip_changes.endsIn": 21600000
    },
  }
);


