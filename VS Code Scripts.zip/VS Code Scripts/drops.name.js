
      db.getCollection("users").find({username: {$in: ["mohsin.s@flipkart.com", "shivamtiwari.r@flipkart.com", "amitkumar.b2@flipkart.com", 
      "lokesh.yadav2@flipkart.com", "prachi.goel@flipkart.com", "tuntun.mishra@flipkart.com", "rakesh.mitharwal@flipkart.com", "pushpender.sharma@flipkart.com", 
      "bisht.hemlata@flipkart.com", "dineshkumar.r1@flipkart.com", "rajpal.singh1@myntra.com", "suraj.saini@myntra.com,", "himanshu.mishra@myntra.com", "vinay.yadav@flipkart.com", 
      "sharma.sachin@flipkart.com"]}}).forEach((k) => {
                            let new_config = k.config;
                            new_config["drops.name"] = k.config.srcname;
                            //new_config["filter_trips_by"].push("drops.customer_code");
                            print(new_config)
                            /*
                            db.getCollection('users').updateOne(
                            {_id: k._id, },  
                                {
                                $set: {
                                    config: new_config
                                }
                            })
                            */
                        })



                        db.getCollection("users").find({username: {$in: []  }}).forEach((k) => {
                                              let new_config = k.config;
                                              new_config["drops.name"] = k.config.srcname;
                                              //new_config["filter_trips_by"].push("drops.customer_code");
                                              print(new_config)
                                              /*
                                              db.getCollection('users').updateOne(
                                              {_id: k._id, },  
                                                  {
                                                  $set: {
                                                      config: new_config
                                                  }
                                              })
                                              */
                                          })




                    // "drops.name" : []