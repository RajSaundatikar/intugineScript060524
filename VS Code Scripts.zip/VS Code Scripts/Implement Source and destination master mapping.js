
   // 1. Set config.trips.master_fetch_enabled true

   // ran customer_master_data_OFB.js
    2. AddtoSet config.trips.master_data [{
                    "key" : "destname",
                    "trip_start_fields" : [
                        "dest"
                    ]
                }, {
                    "key" : "srcname",
                    "trip_start_fields" : [
                        "src"
                    ]
                }]

// 1, 2
                db.getCollection("users").updateMany(
                    {"config.client": "OF BUSINESS"},
                    {
                        $set:{
                            "config.trips.master_fetch_enabled": true,
                            "config.trips.master_data": [{
                                "key" : "destname",
                                "trip_start_fields" : [
                                    "dest"
                                ]
                            }, {
                                "key" : "srcname",
                                "trip_start_fields" : [
                                    "src"
                                ]
                            }]
                        }
                    })




    For every entry in the ofb src dest list excel file, add 2 entries in customer_master_data
{
    "_id" : "OF BUSINESS|destname|ABC",
    "createdAt" : new Date(),
    "client_client" : null,
    "data" : {
        "dest" : [
            26.447,
            80.265
        ]
    },
    "key" : "destname",
    "user" : "OF BUSINESS",
    "value" : "ABC"
}
{
    "_id" : "OF BUSINESS|srcname|ABC",
    "createdAt" : new Date(),
    "client_client" : null,
    "data" : {
        "src" : [
            26.447,
            80.265
        ]
    },
    "key" : "srcname",
    "user" : "OF BUSINESS",
    "value" : "ABC"
}