//Gives list of unique value names from different documents. 
//https://www.mongodb.com/docs/manual/reference/method/db.collection.distinct/ to know more

db.getCollection("device").distinct('last_status.vendor_name')