// db.getCollection("users").updateMany(
//     {"config.client": "Kuehne+Nagel Pvt Ltd", "config.trips.bulk_upload.triplistheaders":{$exists:true}},
// {
//         $push:{
//         "config.trips.bulk_upload.triplistheaders":   {
//             "key" : "eta_days",
//             "value" : "SLA"
//             }

//             }
// })

db.getCollection("users").updateMany(
  {
    "config.client": "Kuehne+Nagel Pvt Ltd",
    "config.trips.bulk_upload.triplistheaders": { $exists: true },
  },
  {
    $push: {
      "config.trips.bulk_upload.triplistheaders": {
        key: "eta_days",
        value: "SLA",
      },
    },
  }
);
