
     db.getCollection("users").updateMany(
    {
        "config.client": "FKT EWAYBILL"
    },
    {
        $set:{
            "config.trips.uniq_trip_key": "trip_id"
        }
    })