
    db.getCollection("status").updateMany(
        {"tripId" : ObjectId("64b54091ac13436040bfa607")},
        {
            $set:{
                "isRejected" : false
            }
        })