
    db.getCollection("geofence_alerts_temp").deleteOne({"user":"Akzo Nobel India Limited"})


        db.getCollection("configurations").deleteMany({"user":"Akzo Nobel India Limited"})

