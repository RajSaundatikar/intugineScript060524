db.getCollection("customer_master_data").find({key:"suspicious_locations"})

          {
                "type" : "Feature",
                "geometry" : {
                    "type" : "Point",
                    "coordinates" : [
                        21.312186083443624, 83.31468462396097
                    ]
                },
                "properties" : {
                    "address" : "Hotel Prakash"
                }
            }
