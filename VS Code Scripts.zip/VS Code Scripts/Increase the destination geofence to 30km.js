
     db.getCollection("users").updateMany(
    {"config.client": "BAYER"},
        {    
            $set:{
                "config.reachParams.geofence": 30000
                }
        }
    )