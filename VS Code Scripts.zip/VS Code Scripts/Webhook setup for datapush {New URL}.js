
     db.getCollection("users").updateMany(
        { "config.client":"Onmove" },
        {
            $set:{
                'config.tracking.webhookQueueLocationUrl': "http://stg-rohitk.zastlogisolutions.com/v2/trip/intugine-webhook"
            }
        })


        db.getCollection("trips").updateMany(
            {"user": "Onmove", "running": true},
            {
            $set:{
                'tracking.webhookQueueLocationUrl': "http://stg-rohitk.zastlogisolutions.com/v2/trip/intugine-webhook"
            }
            })