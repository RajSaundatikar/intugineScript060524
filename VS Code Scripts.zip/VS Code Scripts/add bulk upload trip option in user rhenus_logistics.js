
    "config.trips.bulk_upload" : {
                "show" : true,
                "google" : true,
                "fixed_headers" : true
            },