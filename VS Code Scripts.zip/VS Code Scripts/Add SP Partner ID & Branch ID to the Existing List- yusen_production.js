
    db.getCollection("customer_master_data").insertMany([
    {
        "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#NARH",
        "user" : "superprocure",
        "client_client" : null,
        "key" : "partnerClientId#partnerBranchId",
        "value" : "YUSL#NARH",
        "data" : {
        "username" : "yusen_production"
        },
        "updatedAt" : new Date()
    },
    {
            "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#JAMA",
            "user" : "superprocure",
            "client_client" : null,
            "key" : "partnerClientId#partnerBranchId",
            "value" : "YUSL#JAMA",
            "data" : {
            "username" : "yusen_production"
            },
            "updatedAt" : new Date()
     },
    {
                "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#DELH",
                "user" : "superprocure",
                "client_client" : null,
                "key" : "partnerClientId#partnerBranchId",
                "value" : "YUSL#DELH",
                "data" : {
                "username" : "yusen_production"
                },
                "updatedAt" : new Date()
    },
        {
                    "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#LUDH",
                    "user" : "superprocure",
                    "client_client" : null,
                    "key" : "partnerClientId#partnerBranchId",
                    "value" : "YUSL#LUDH",
                    "data" : {
                    "username" : "yusen_production"
                    },
                    "updatedAt" : new Date()
          },
          {
                        "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#LUCK",
                        "user" : "superprocure",
                        "client_client" : null,
                        "key" : "partnerClientId#partnerBranchId",
                        "value" : "YUSL#LUCK",
                        "data" : {
                        "username" : "yusen_production"
                        },
                        "updatedAt" : new Date()
            },
            {
                "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#JAIP",
                "user" : "superprocure",
                "client_client" : null,
                "key" : "partnerClientId#partnerBranchId",
                "value" : "YUSL#JAIP",
                "data" : {
                "username" : "yusen_production"
                },
                "updatedAt" : new Date()
    },
    {
        "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#TEPL",
        "user" : "superprocure",
        "client_client" : null,
        "key" : "partnerClientId#partnerBranchId",
        "value" : "YUSL#TEPL",
        "data" : {
        "username" : "yusen_production"
        },
        "updatedAt" : new Date()
}

    ])