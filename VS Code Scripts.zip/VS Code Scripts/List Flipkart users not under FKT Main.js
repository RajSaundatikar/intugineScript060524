
    db.getCollection("users").find({'config.client': 
        { $in: [
            "FKT - Large Pilot",
            "FKT - MHDH",
            "FKT - Transporter",
            "FKT - Transporter1",
            "FKT - Transporter2",
            "FKT EWAYBILL",
            "FKT_lock",
            "Flipkart",
            "Flipkart Large SCT",
            "Flipkart PL",
            "Flipkart Testing",
            "Flipkart-Transporter",
            "flipkart",
            "flipkart_redefine",
            "myntra",
            "raghavendra.c@flipkart.com"
        ] }}
        ).count()


        db.getCollection("users").find({'config.client': { $in: [
            "FKT - Large Pilot",
            "FKT - MHDH",
            "FKT - Transporter",
            "FKT - Transporter1",
            "FKT - Transporter2",
            "FKT EWAYBILL",
            "FKT_lock",
            "Flipkart",
            "Flipkart Large SCT",
            "Flipkart PL",
            "Flipkart Testing",
            "Flipkart-Transporter",
            "flipkart",
            "flipkart_redefine",
            "myntra",
            "raghavendra.c@flipkart.com"
            ] }},{ _id:0, username:1, "config.client":1 })