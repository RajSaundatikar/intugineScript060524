
     db.getCollection("users").updateMany(
        {'config.client': "RADURE HANDLING"},
        {
            $set:{
                'config.webhooks.locations.url' : "https://app.vfryt.com/intugine-eta-events"
            }
        })