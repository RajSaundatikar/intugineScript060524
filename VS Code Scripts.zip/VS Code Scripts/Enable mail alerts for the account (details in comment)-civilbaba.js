
     //Halt Alerts

        
     db.getCollection("users").updateMany(
            {"config.client" : "CivilBaba"},
            {
                $set:
                {
                    "config.alerts.halt": {
                        "recipients": {
                            "internal": [
                                "support@intugine.com"
                            ],
                            "client": ["shivam.singhal@civilbaba.in"]
            
                        },
                        "haltParams": [{
                            "durationThreshold": 7200000,
                            "sendOncePerHalt": true,
                            "recipients": [
            
                            ]
                        }]
                    }
                }
            
            })
        
        
            //ETA Breach and Geofence Alerts
        
            db.getCollection("geofence_alerts_temp").insertOne(
                {
                "user" : "CivilBaba",
                "geofenceAlertData" : {
                "src": 5000,
                "dest": 5000,
                "disableMailAlerts" : false,
                "displayName" : "CivilBaba",
                "alert_emails" : ["shivam.singhal@civilbaba.in"]
                }
        
                })

            
                {
                    "action": "TRIGGER_MIS_REPORT",
                    "user": "CivilBaba",
                    "query": {
                      "client_client": null
                    },
                    "cron_expression": "30 4 * * *",
                    "config": {
                      "recipients": {"to" : ["shivam.singhal@civilbaba.in"] }
                    }
                  }