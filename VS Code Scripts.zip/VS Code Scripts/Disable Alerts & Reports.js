
//Reference user: reliance_admin

// Disable all alerts & reports for this client as the pilot has ended

//"config.client":"Reliance Digital"
// @Raj Saundatikar Remove 'config.alerts' from all users of this client
// Also remove entry from geofence_alerts_temp if there's any

//For users
db.getCollection("users").updateMany(
    { "config.client": "Reliance Digital" },
    { $unset: { "config.alerts": "" } }
  );
  
//For "geofence_alerts_temp"
db.getCollection("geofence_alerts_temp").updateMany(
    {user:"Reliance Digital"},
    {$unset:{geofenceAlertData: ""}}
);