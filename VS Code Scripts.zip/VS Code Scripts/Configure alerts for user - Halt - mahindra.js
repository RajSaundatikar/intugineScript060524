
    //Halt Alerts

      db.getCollection("users").updateMany(
        {"config.client" : "mahindra", "config.client_client" : "Mahindra Logistics Bussiness Unit 1"},
        {
            $set:
            {
                "config.alerts.halt": {
                    "recipients": {
                        "internal": [
                            "support@intugine.com"
                        ],
                        "client": ["bhosale.ganesh2@mahindra.com", "sawant.karishma@mahindra.com", "daware.dhiraj@mahindra.com", "amrita@intugine.com", "support@intugine.com", "shawn@intugine.com"]
        
                    },
                    "haltParams": [{
                        "durationThreshold": 1800000,
                        "sendOncePerHalt": true,
                        "recipients": [
        
                        ]
                    }]
                }
            }
        
        })
    
    
        //ETA Breach and Geofence Alerts
    
        db.getCollection("geofence_alerts_temp").insertOne(
            {
            "user" : "mahindra",
            "client_client" : "Mahindra Logistics Bussiness Unit 1",
            "geofenceAlertData" : {
            "src": 5000,
            "dest": 5000,
            "disableMailAlerts" : false,
            "displayName" : "mahindra",
            "alert_emails" : ["bhosale.ganesh2@mahindra.com", "sawant.karishma@mahindra.com", "daware.dhiraj@mahindra.com", "amrita@intugine.com", "support@intugine.com", "shawn@intugine.com"]
            }
    
            })



            db.getCollection("users").updateMany(
                { "config.client": "mahindra",  "config.client_client" : "Mahindra Logistics Bussiness Unit 1"},
                {
                  $set: {
                    "config.reachParams.geofence": 5000,
                    "config.tracking.geofence_radius.drop": 5000,
                  },
                }
              );