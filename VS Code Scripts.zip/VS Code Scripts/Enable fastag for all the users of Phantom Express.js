//Enable fastag for all the users of Phantom Express 

//"config.client" : "Phantom Express"

db.getCollection("configurations").insertOne({
    action: "ENABLE_FASTAG_IN_TRIPS",
    user: "Phantom Express",
    threshold: {
      from: "TRIP_START",
      duration: 7200000,
    },
  });