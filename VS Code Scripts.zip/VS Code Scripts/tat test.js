db.getCollection("trips")
.find({
  user: "PANTOS",
  running: true,
  eta_days:{$ne:null}
})
.sort({ _id: -1 })
.forEach((k) => {
  print(
    k.startTime,k.eta_days,
    new Date(k.startTime.valueOf() + k.eta_days * 24 * 60 * 60 * 1000 + 259200000)
  );

 
});