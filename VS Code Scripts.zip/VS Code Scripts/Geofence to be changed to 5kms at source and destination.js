
    db.getCollection("users").updateMany(
  { "config.client": "mahindra" },
  {
    $set: {
      "config.reachParams.geofence": 5000
    },
  }
);