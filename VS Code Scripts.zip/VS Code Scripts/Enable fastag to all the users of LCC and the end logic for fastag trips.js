//Enable fastag to all the users of LCC and the end logic for fastag trips



db.getCollection("configurations").insertOne({
    action: "ENABLE_FASTAG_IN_TRIPS",
    user: "Lakshmi Cargo Company",
    threshold: {
      from: "TRIP_START",
      duration:  7200000,
    },
  });





  