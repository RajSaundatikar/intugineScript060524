
db.getCollection("users").updateMany(
  { "config.client": "CCI Logistics" },
  {
    "$set": {
      "config.trips.expire_trip_based_on_sla": {
        "operator": "+",
        "threshold": 0
      }
    }
  }
);