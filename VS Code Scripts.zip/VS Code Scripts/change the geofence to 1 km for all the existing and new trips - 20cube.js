
    db.getCollection("users").updateMany(
  { "config.client": "20 Cube" },
  {
    $set: {
      "config.reachParams.geofence": 1000
      
    },
  }
);