
    db.getCollection("users").updateOne(
        {"username":"iocl0033@gmail.com"},
        {
            $set:{
                "config.filter_trips_by":["src_code"],
                "config.src_code":["0033"]
            }
        })

        
        db.getCollection("users").updateMany(
            {"username": { $in:["nareshnagpal7876@gmail.com", "rahuldhaniya25@gmail.com"] }},
            {
                $set:{
                    "config.filter_trips_by":["src_code"],
                    "config.src_code":["0031"]
                }
            })


            db.getCollection("users").updateMany(
                {"username": { $in:["jaglanrohit502@gmail.com", "junaidaalam9518@gmail.com"] }},
                {
                    $set:{
                        "config.filter_trips_by":["src_code"],
                        "config.src_code":["0033"]
                    }
                })

                db.getCollection("users").updateMany(
                    {"username": { $in:["bikashbaral166@gmail.com", "kamalakantasahoo7894@gmail.com"] }},
                    {
                        $set:{
                            "config.filter_trips_by":["src_code"],
                            "config.src_code":["0038"]
                        }
                    })