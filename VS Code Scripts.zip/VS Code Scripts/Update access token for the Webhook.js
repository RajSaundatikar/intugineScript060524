
    // "https://api.mywebxpress.com/wh/in/sim/location/C00169?code=3ywZbXey118a5Rdzn65Hu5N6F7ktlcg0GLVXclRcgKVajuPwA7Ok5Q==&AccessKey=0c3dc784-4dc2-4ff1-ac28-cf0511e06ec0&subscription-key=2f6d8403265942b7a736e928b35c3c17"


    // 0c3dc784-4dc2-4ff1-ac28-cf0511e06ec0


    

    db.getCollection("users").updateMany(
        {"config.client": "SAR TRANSPORT"},
        {
            $set:{
                "config.tracking.webhookQueueLocationUrl": "https://api.mywebxpress.com/wh/in/sim/location/C00169?code=3ywZbXey118a5Rdzn65Hu5N6F7ktlcg0GLVXclRcgKVajuPwA7Ok5Q==&AccessKey=84b689ed-7762-48bb-8b29-54ef1ab43eb9&subscription-key=2f6d8403265942b7a736e928b35c3c17"
            }
        }
    )

    