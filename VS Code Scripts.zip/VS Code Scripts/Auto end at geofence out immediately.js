//Sample username: hmel
// Client: hmel
// @Raj Saundatikar


// Set 'config.reachParams.geofence_out.trip_changes.endsIn to 1
// and unset 'config.reachParams.geofence_in.trip_changes.endsIn

// in all users of HMEL

db.getCollection("users").updateMany(
    {"config.client":"HMEL"},
        {    $set:{
                "config.reachParams.geofence_out.trip_changes.endsIn": 1,
                    },
            $unset:{
                "config.reachParams.geofence_in.trip_changes.endsIn": ""
                }
        }
    )