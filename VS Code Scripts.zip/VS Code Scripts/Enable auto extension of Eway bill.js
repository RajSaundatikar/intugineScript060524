
    db.getCollection("users").updateMany(
                    {"config.client": "bridgestone", "config.ewaybillParams": {$exists:true}},
                    {
                        $set:{
                            "config.ewaybillParams.autoExtendEnabled":{

                                            
                                            "to_email" : [
                                                "hardik-soni@bridgestone.co.in", "sachin-modi@bridgestone.co.in", "vaibhav-karadiya.ext@bridgestone.co.in", "ashish-patil@bridgestone.co.in"
                                            ],
                                            "cc_email" : [
                                                "pulkitsrivastava@intugine.com",
                                                "support@intugine.com"
                                            ]
                            }
                        }
                    }) 


