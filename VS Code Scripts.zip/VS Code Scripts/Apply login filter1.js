db.getCollection("users").updateOne(
  { username: "uslbelagavi@intugine.com" },
  {
    $set: {
      "config.filter_trips_by": ["srcname"],
      "config.srcname": ["Hermes Plant"],
    },
  }
);

db.getCollection("users").updateOne(
  { username: "uslkombalgodu@intugine.com" },
  {
    $set: {
      "config.filter_trips_by": ["srcname"],
      "config.srcname": ["USL Kombalgodu"],
    },
  }
);
