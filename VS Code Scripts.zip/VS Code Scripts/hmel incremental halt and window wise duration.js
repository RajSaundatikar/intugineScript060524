
    db.getCollection("users").updateMany(
    {"config.client": "HMEL", "config.alerts":{$exists:true}},
    {
        $set:{
            "config.alerts.halt.day_windows": [
                {
                  "name": "Day",
                  "window": {
                    "timezone": "Asia/Kolkata",
                    "from": 25200000,
                    "to": 43200000
                  }
                },
                {
                  "name": "Night",
                  "window": {
                    "timezone": "Asia/Kolkata",
                    "from": 68400000,
                    "to": 43200000
                  }
                }
              ]
        }
    })


    db.getCollection("users").updateMany(
        {"config.client": "HMEL", "config.alerts":{$exists:true}},
        {
            $set:{
                
                  "config.alerts.halt.haltParams.$[].incrementThreshold": 21600000
            }
        },
        {
           multi: true
        })



    // db.collection.update({},
    //     {
    //       $set: {
    //         "info.data.$[].isActive": false
    //       }
    //     },
    //     {
    //        multi: true
    //     })