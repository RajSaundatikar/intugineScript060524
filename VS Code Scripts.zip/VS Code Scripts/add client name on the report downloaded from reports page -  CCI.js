
    db.getCollection("users").updateMany(
            {
                "config.client": "CCI Logistics"
            },
            {
                $push:{
                    "config.reports.report_extra_columns":{
                        key:"client_name",
                        placeholder:"Client Name"
                    }
                }
            })




            // db.getCollection("users").updateOne(
            //     {
            //         "username": "cci_admin"
            //     },
            //     {
            //         $push:{
            //             "config.reports.report_extra_columns":{
            //                 key:"client_name",
            //                 placeholder:"Client Name"
            //             }
            //         }
            //     })