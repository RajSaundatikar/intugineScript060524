
    {

"action" : "TRIGGER_MIS_REPORT",
"user" : "Shree Cements",
"query" : {
"client_client" : null,
"$expr" : {
"$lte" : [
"$startTime",
{
"$dateSubtract" : {
"startDate" : "$$NOW",
"unit" : "day",
"amount" : NumberInt(4)
}
}
]
}
},
"cron_expression" : "30 4 * * *",
"config" : {
"enabled" : true,
"group_by" : "destname",
"recipients" : {
"to" : [
"Honey.Varghese@shreecement.com",
"Divya.Dubey@shreecement.com",
"pratik@intugine.com",
"lakhandhanani@intugine.com"
],
"Beawar" : [
"Rajesh.Patni@shreecement.com"
],
"Ras" : [
"Rajesh.Patni@shreecement.com"
],
"Karnataka Plant" : [
"Rakesh.Janardanrao@shreecement.com"
],
"Chhattisgarh Plant" : [
"Ashutosh.Tiwari@shreecement.com",
"Ashwani.Dewangan@shreecement.com"
]
}
},

}