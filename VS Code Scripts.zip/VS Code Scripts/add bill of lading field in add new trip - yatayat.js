db.getCollection("users").updateMany(
  { "config.client": "yatayat" },
  {
    $push: {
      "config.trips.newtripinputfields": {
        key: "bill_of_lading",
        placeholder: "Bill of Lading",
        type: "text",
      },
    },
  }
);
