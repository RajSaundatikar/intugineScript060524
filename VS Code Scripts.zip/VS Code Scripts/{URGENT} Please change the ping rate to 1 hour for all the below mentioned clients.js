

    //users
db.getCollection("users").updateMany(
    { "config.client": { $in: ["Calcutta Express roadlines Pvt ltd", "Ashok Leyland", "Rhenus Logistics", "DCM SHRIRAM AGRO", "Prozo", "GHCL", "Nilkamal Furniture", "SKL Cargo", "Centuary Mattresses India", "TI Cycles", "Multimodes Transport", "PBL Transport", "Vertiv Engergy", "shrimaa_polyfabs", "B BRAUN", "Onmove", "TI CYCLES"] }  },
    {
      $set: {
        
        "config.pingrate": 3600000
      }
    }
  );
  
  ///// trips
  db.getCollection("trips").updateMany(
    { user: { $in: ["Calcutta Express roadlines Pvt ltd", "Ashok Leyland", "Rhenus Logistics", "DCM SHRIRAM AGRO", "Prozo", "GHCL", "Nilkamal Furniture", "SKL Cargo", "Centuary Mattresses India", "TI Cycles", "Multimodes Transport", "PBL Transport", "Vertiv Engergy", "shrimaa_polyfabs", "B BRAUN", "Onmove", "TI CYCLES"] }, running: true },
    {
      $set: {
        "ping_rate": 3600000,
      },
    }
  );