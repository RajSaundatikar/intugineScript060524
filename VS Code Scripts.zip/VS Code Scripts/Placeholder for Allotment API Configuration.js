//Insert this in customer_master_data



db.getCollection("customer_master_data").insertMany([
    {
        "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#BHIW",
        "user" : "superprocure",
        "client_client" : null,
        "key" : "partnerClientId#partnerBranchId",
        "value" : "YUSL#BHIW",
        "data" : {
        "username" : "yusen_production"
        },
        "updatedAt" : new Date()
    },
    {
            "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#TALO",
            "user" : "superprocure",
            "client_client" : null,
            "key" : "partnerClientId#partnerBranchId",
            "value" : "YUSL#TALO",
            "data" : {
            "username" : "yusen_production"
            },
            "updatedAt" : new Date()
     },
    {
                "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#XGZUYSHG",
                "user" : "superprocure",
                "client_client" : null,
                "key" : "partnerClientId#partnerBranchId",
                "value" : "YUSL#XGZUYSHG",
                "data" : {
                "username" : "yusen_production"
                },
                "updatedAt" : new Date()
    },
        {
                    "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#CEHUBMJN",
                    "user" : "superprocure",
                    "client_client" : null,
                    "key" : "partnerClientId#partnerBranchId",
                    "value" : "YUSL#CEHUBMJN",
                    "data" : {
                    "username" : "yusen_production"
                    },
                    "updatedAt" : new Date()
          },
          {
                        "_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#CRIVKTSF",
                        "user" : "superprocure",
                        "client_client" : null,
                        "key" : "partnerClientId#partnerBranchId",
                        "value" : "YUSL#CRIVKTSF",
                        "data" : {
                        "username" : "yusen_production"
                        },
                        "updatedAt" : new Date()
            }

    ])