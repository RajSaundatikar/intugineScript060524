
  //  update the lat long for SMF - Khurda


  //DB _IMS_, collection locations mein ye object 6193457a495839d2bb88352a mein loc update karna hai