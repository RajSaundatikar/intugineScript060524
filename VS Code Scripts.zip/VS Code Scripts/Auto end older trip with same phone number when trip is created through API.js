
    db.getCollection("users").updateMany(
        {"config.client": "HMEL"},
        {
            $set:{
                'config.tracking.tripConflictReplacementEnabled': true
            }
        })


        db.getCollection("trips").updateMany(
            {"user": "HMEL", "running": true},
            {
                $set:{
                    'tracking.tripConflictReplacementEnabled': true
                }
            })