
    db.getCollection("users").updateMany(
        {username: {$in: ["rijo.varghese@flipkart.com", "athira.sivan1@flipkart.com", "bibin.varghese@flipkart.com", "jophin.joy@flipkart.com", "pradeep.vk@flipkart.com", "rinshad.tr@flipkart.com", "vishnu.pv@flipkart.com", "biju.kk@flipkart.com", "justin.john@flipkart.com"] }},
        {
            $set:{
                "config.client": "FKT_Main",
                "config.client_client": "FKT"
            }
        })
