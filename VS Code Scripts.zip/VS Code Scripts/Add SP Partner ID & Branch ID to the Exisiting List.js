
    YUSL TALO


    {
"_id" : "superprocure|partnerClientId#partnerBranchId|YUSL#TALO",
"user" : "superprocure",
"client_client" : null,
"key" : "partnerClientId#partnerBranchId",
"value" : "YUSL#TALO",
"data" : {
"username" : "yusen_production"
},
"updatedAt" : new Date()
}

// Run customer_master_data.js script