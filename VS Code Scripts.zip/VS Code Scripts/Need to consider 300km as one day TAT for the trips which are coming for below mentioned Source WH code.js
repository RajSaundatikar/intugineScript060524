
//     Add the following to 'config.trips.master_data' in all users of bayer
// {
// "key" : "src_wh_code",
// "trip_start_fields" : [
// "per_day_to_distance_travel"
// ]
// }

    db.getCollection("users").updateMany({
        "config.client": "BAYER"
    },
    {
        $push:{
            "config.trips.master_data": {
                "key" : "src_wh_code",
                "trip_start_fields" : [
                "per_day_to_distance_travel"
                ]
                }
        }
    })
    
    //2. Ran customer_master_data_BAYER.js