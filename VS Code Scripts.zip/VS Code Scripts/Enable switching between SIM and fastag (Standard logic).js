
    db.getCollection("users").updateMany(
  { "config.client": "Virya Logistics" },
  { $set: { "config.tracking.parallel_fastag_fallback": true } }
);

////

db.getCollection("trips").updateMany(
  { user: "Virya Logistics", running: true },
  {
    $set: { "tracking.parallel_fastag_fallback": true },
  }
);