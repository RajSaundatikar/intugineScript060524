// set  in all users of that client. don't set the same in running trips. Just comment on the task that it'll be in effect for new trips which gets started from this point forward

db.getCollection("users").updateMany(
  { "config.client": "MRC India" },
  {
    $set: {
      "config.tracking.invalid_location_vendors": ["WHEELSEYE"],
    },
  }
);
