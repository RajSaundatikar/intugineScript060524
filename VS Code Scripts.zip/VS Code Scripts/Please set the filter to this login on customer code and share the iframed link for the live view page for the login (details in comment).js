
    db.getCollection("users").updateOne(
    {username:"radcl0000001"},
    {
        $set:{
            
            "config.filter_trips_by":["customer_code"],
            "config.customer_code": ["RADCL0000001"]
            
        }
    })