
    db.getCollection("users").updateMany(
        {'config.client': 'bridgestone', 'config.vendor': 'SSRC'},
        {
            $set:{
                'config.lr.static_fields':{
                    "bank_account_number" : "",
                    "bank_ifsc" : "",
                    "company_address" : "PLOT NO. PFS-1, Shree Shyam Road Carrier, KUNDAI, Kundaim Industrial Estate, South Goa, Goa, 403115",
                    "company_name" : "SSRC LOGISTICS PRIVATE LIMITED",
                    "email_id" : "goa@ssrc.co",
                    "landline_number" : "0832-2395558",
                    "logo" : "https://sct-uploaded-files.s3.ap-south-1.amazonaws.com/in.ssrc-logo-SSRC_SUB.jpg",
                    "phone_number" : "0832-2395183",
                    "signature" : "https://sct-uploaded-files.s3.ap-south-1.amazonaws.com/in.ssrc-signature-SSRC_SUB.jpg",
                    "vendor_gstin" : "30ABFCS1472H1ZM",
                    "city" : "Goa",
                    "state" : "Goa",
                    "pan_number" : "",
                    "remark_one" : "",
                    "remark_three" : "",
                    "remark_two" : ""
                }
            }
        })