
    //To restart trip first run below query with correct _id
     db.getCollection("trips").updateOne(
   { _id: ObjectId("65409f0927b64f46d7d6d480") },
   {
     $set: {
       expiresAt: null 
     },
   }
 );
  //In Postman "Trip Restart" and put _id in URL and Send