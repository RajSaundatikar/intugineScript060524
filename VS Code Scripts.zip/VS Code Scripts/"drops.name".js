
    

db.getCollection("users").find({username: {$in: ["singh.amardeep@flipkart.com"]   }}).forEach((k) => {
    let new_config = k.config;
    new_config["drops.name"] = k.config.srcname;
    //new_config["filter_trips_by"].push("drops.customer_code");
    print(new_config)
    /*
    db.getCollection('users').updateOne(
    {_id: k._id, },  
        {
        $set: {
            config: new_config
        }
    })
    */
})