 
        db.getCollection("users").updateOne(
        {username:"rudralogisticskanagala@gmail.com"},
        {
                $set:{
                    "config.filter_trips_by":["vendor"],
                    "config.vendor":["Rudra Logistics"]
                }
        })

        db.getCollection("users").updateOne(
            {username:"bsfm.kanagala@gmail.com"},
            {
                    $set:{
                        "config.filter_trips_by":["vendor"],
                        "config.vendor":["Bombay South Freight Movers"]
                    }
            })

            db.getCollection("users").updateOne(
                {username:"ctonipani@gmail.com"},
                {
                        $set:{
                            "config.filter_trips_by":["vendor"],
                            "config.vendor":["Commercial Transporter"]
                        }
                })

                db.getCollection("users").updateOne(
                    {username:"mahesh.patil@cjdarcl.com"},
                    {
                            $set:{
                                "config.filter_trips_by":["vendor"],
                                "config.vendor":["CJ - DARCEL"]
                            }
                    })

                db.getCollection("users").updateOne(
            {username:"eastwest.sudhirkngla@rediffmail.com"},
            {
                    $set:{
                        "config.filter_trips_by":["vendor"],
                        "config.vendor":["East West Roadline Transport"]
                    }
            })

            db.getCollection("users").updateOne(
                {username:"sandeep.sagu@gmail.com"},
                {
                        $set:{
                            "config.filter_trips_by":["vendor"],
                            "config.vendor":["Maa Bhagwati Transport"]
                        }
                })

                db.getCollection("users").updateOne(
                    {username:"khushiramlogisticskngla@gmail.com"},
                    {
                            $set:{
                                "config.filter_trips_by":["vendor"],
                                "config.vendor":["Khushi Ram"]
                            }
                    })    