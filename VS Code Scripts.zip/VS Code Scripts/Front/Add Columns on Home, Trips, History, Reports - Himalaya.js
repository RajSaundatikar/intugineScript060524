



    db.getCollection("users").updateMany(
        {"config.client":"Himalaya Test"},
        {
            $push:{
               
                "config.home.triplistheaders":{
                    $each:[
                        {
                            "key":"src_name",
                            "value":"Source Name"
                        },
                        {
                            "key": "dest_name",
                            "value": "Destname"
                        }
                    ]
                },

                "config.trips.extra_triplistheaders":{
                    $each:[
                        {
                            "key":"src_name",
                            "value":"Source Name"
                        },
                        {
                            "key": "dest_name",
                            "value": "Destname"
                        }
                    ]
                },

                "config.history.extra_triplistheaders":{
                    $each:[
                        {
                            "key":"src_name",
                            "value":"Source Name"
                        },
                        {
                            "key": "dest_name",
                            "value": "Destname"
                        }
                    ]
                },

                "config.reports.extra_triplistheaders":{
                     $each:[
                        {
                            "key":"src_name",
                            "value":"Source Name"
                        },
                        {
                            "key": "dest_name",
                            "value": "Destname"
                        }
                    ]
                }


            }
        })



    



    db.getCollection("users").updateMany(
        {"config.client":"Himalaya Production"},
        {
            $push:{
               
                "config.home.triplistheaders":{
                    $each:[
                        {
                            "key":"src_name",
                            "value":"Source Name"
                        },
                        {
                            "key": "dest_name",
                            "value": "Destname"
                        }
                    ]
                },

                "config.trips.extra_triplistheaders":{
                    $each:[
                        {
                            "key":"src_name",
                            "value":"Source Name"
                        },
                        {
                            "key": "dest_name",
                            "value": "Destname"
                        }
                    ]
                },

                "config.history.extra_triplistheaders":{
                    $each:[
                        {
                            "key":"src_name",
                            "value":"Source Name"
                        },
                        {
                            "key": "dest_name",
                            "value": "Destname"
                        }
                    ]
                },

                "config.reports.extra_triplistheaders":{
                     $each:[
                        {
                            "key":"src_name",
                            "value":"Source Name"
                        },
                        {
                            "key": "dest_name",
                            "value": "Destname"
                        }
                    ]
                }


            }
        })


