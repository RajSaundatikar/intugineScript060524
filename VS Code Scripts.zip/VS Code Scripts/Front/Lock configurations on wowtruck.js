
       // ["2031", "2018", "2026", "2042"]

        

    // Set below

        "config.trips" : {
            
            "otheroption" : {
                "facilities" : true,  
                "device_unlock_access" : true,
                "devices" : true,
                
            } 
        }

           "config.trips.submittedtripoptions": 
           {
            "to_be_receive_device" : true 
         } //dropdown in trip form with dest name



           // device management
           1. extra_headers
           2. devices: true


           ranjanid@wowtruck.in
    vasanthakumarm@wowtruck.in