



//home
    db.getCollection("users").updateMany(
        {"config.client": "VEGROW"},
        {
            $push:{
                "config.home.triplistheaders":{
                    
                        "key":"custom_velynk_tripid",
                        "value":"velynk tripid"
                }
            }
        })


//Trips
db.getCollection("users").updateMany(
    {"config.client":"VEGROW"},
    {
        $set:{
            "config.trips.extra_triplistheaders":[{
                
                     "key":"custom_velynk_tripid",
                     "value":"velynk tripid"
            }]
        }
    })

    
 
    
    //reports
    db.getCollection("users").updateMany(
        {"config.client":"VEGROW"},
        {
            $push:{
                "config.reports.extra_triplistheaders":{
                    
                         "key":"custom_velynk_tripid",
                         "value":"velynk tripid"      
                }
            }
        })



         db.getCollection("users").updateMany(
        {"config.client":"VEGROW"},
        {
            $push:{
                "config.reports.report_extra_columns":{
                    
                         "key":"custom_velynk_tripid",
                         "placeholder":"velynk tripid"      
                }
            }
        })



         db.getCollection("users").updateMany(
        {"config.client":"VEGROW"},
        {
            $pull:{
                "config.reports.report_extra_columns":{
                    
                         "key":"custom_velynk_tripid" 
                }
            }
        })