
    db.getCollection("users").updateMany(
    {"config.client":"Himalaya Test"},
    {
        $addToSet:{
            "config.trips.extra_triplistheaders":{
                "key" : "gate_in",
                "value" : "Gate In"
            }
        }
                
    })

   // himalaya_test

    db.getCollection("users").updateOne(
        {"username":"himalaya_test"},
        {
            $push:{
                "config.trips.extra_triplistheaders":{
                    "key" : "gate_in",
                    "value" : "Gate In"
                }
            }
                    
        })