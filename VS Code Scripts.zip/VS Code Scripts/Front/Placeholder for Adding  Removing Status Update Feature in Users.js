
    db.getCollection("users").updateMany(
    {username: {$in:["himalaya_production", "haneesh@himalayawellness.com", "girishkumar.k@himalayawellness.com", "yogaraju.ar@himalayawellness.com", "madhusudhan.br@himalayawellness.com", "bharadhan.v@himalayawellness.com", "akshaykumar.s@himalayawellness.com", "ambala.mwh1@himalayawellness.com", "hyd.mw@himalayawellness.com", "bgl.wh@himalayawellness.com", "indore.mwh@himalayawellness.com", "kolkata.mwh1@himalayawellness.com", "cfa.ahm.kbshah@himalayawellness.com", "cfa.bhiw.ramdas@himalayawellness.com", "cfa.bhubaneswar@himalayawellness.com", "cfa.chennai@himalayawellness.com", "cfa.delhi@himalayawellness.com", "cfa.ernakulam@himalayawellness.com", "cfa.sahibabad@himalayawellness.com", "cfa.guwahati@himalayawellness.com", "cfa.hyderabad@himalayawellness.com", "cfa.sudhir.indore@himalayawellness.com", "cfa.jaipur@himalayawellness.com", "cfa.kolkata@himalayawellness.com", "cfa.lucknow@himalayawellness.com", "cfa.madurai@himalayawellness.com", "cfa.nagpur@himalayawellness.com", "cfa.patna@himalayawellness.com", "cfa.pune.pharma@himalayawellness.com", "cfa.raipur@himalayawellness.com", "cfa.ranchi@himalayawellness.com", "cfa.zirakpur@himalayawellness.com", "cfa.jabalpur@himalayawellness.com", "cfa.dehradun@himalayawellness.com", "Cfa.hubli@himalayawellness.com", "cfa.bangalore@himalayawellness.com", "cfa.vijayawada@himalayawellness.com", "cfa.goa@himalayawellness.com", "cfa.siliguri@himalayawellness.com", "ahmedabadcfasec", "bhiwandicfasec", "bhubaneswarcfasec", "chennaicfasec", "delhicfasec", "ernakulamcfasec", "ghaziabadcfasec", "guwahaticfasec", "hyderabadcfasec", "indorecfasec", "jaipurcfasec", "kolkatacfasec", "lucknowcfasec", "maduraicfasec", "nagpurcfasec", "patnacfasec", "punecfasec", "raipurcfasec", "ranchicfasec", "zirakpurcfasec", "jabalpurcfasec", "dehraduncfasec", "hublicfasec", "bangalorenewsec", "vijayawadacfasec", "goacfasec", "siliguricfasec", "tumkurplantsec", "ambalamwhsec", "hyderabadmwhsec", "bangaloremwhsec", "indoremwhsec", "kolkatamwhsec", "pramosh@himalayawellness.com"]}},
    {
        $set:{
            "config.app_navigation_lethan" : [
                {
                    "key" : "NAV_LETHAN",
                    "text" : "Status Updates",
                    "desc" : "Status Updates",
                    "url" : "https://d8ni6op2f8qee.cloudfront.net/app_assets/form.png",
                    "introduced" : {
                        "version" : "1.0.14",
                        "nav_message" : {
                            "outline_color" : NumberInt(1),
                            "text" : "New!"
                        }
                    },
                    "web_url" : "https://sct.intutrack.com/?#!/app-trips"
                }
            ],

            "config.apptrips": {
                "otheroption" : {
                    "update_status" : true
                }
            },

            "config.trips.submittedtripoptions.status_update": true

        }
    })


    db.getCollection("users").updateMany(
        {username:{$in:["bangalore@balurghat.co.in", "ho@goelfreightcarriers.com", "accts.bng@mahaveeratransport.com", "nagaraj@omlogistics.co.in", "rahultransportorganisation01@gmail.com", "rajcontainerservice@yahoo.com", "roadlinks.khan@live.com", "syed.mahboob@safexpress.com", "premasunilp@gmail.com", "govindsvc@gmail.com", "corporate.pickup@tciexpress.in", "prabu.rajendran@varuna.net", "vijaycargomovers@yahoo.co.in", "naveen.kumar57@delhivery.com", "nirakar@cti.in", "ngfcbaroda@yahoo.co.in", "operations@krlmrl.net", "cr.blr@coldrushlogistics.com", "skln9162@gmail.com", "skbt027@gmail.com", "girish.hn198@gmail.com", "srikempammadevi@gmail.com", "pradeep.s.m.t61@gmail.com", "logistics@srstravels.net", "utrans.inc@gmail.com"]}},
        {
            $unset:{
                "config.app_navigation_lethan": "",
                "config.apptrips": "",
                "config.trips.submittedtripoptions.status_update": ""
            }
        })