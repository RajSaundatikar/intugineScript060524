
    db.getCollection("users").updateMany(
    {username: { $in: ["tarun.upadhyay@flipkart.com", "amitosh.sinha@flipkart.com", "girish.s1@flipkart.com", "priyanka.s3@flipkart.com", "sudhanshu.jha@flipkart.com", "deviprasad.k@flipkart.com", "nishanth.s1@flipkart.com", "chandanacs.vc@flipkart.com", "nimith.shivadas@flipkart.com"] } },
    {
        $set:{
            "config.filter_trips_by":"client_client" ,
            "config.client_client": ["FKT","Flipkart - Myntra"]
        }
    })