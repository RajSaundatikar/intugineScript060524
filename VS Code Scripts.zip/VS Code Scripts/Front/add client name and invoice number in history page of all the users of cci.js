
    db.getCollection("users").updateMany(
    {"config.client": "CCI Logistics"},
    {
        $push:{
            
            "config.history.extra_triplistheaders": {
                $each: [
                    {
                        "key":"client_name",
                        "value":"Client Name"
                    },
                    {
                        "key":"invoice",
                        "value": "Invoice No."
                    }
                    
                ]
            }
                   
            
            }
    }
    )




    