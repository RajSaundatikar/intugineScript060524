

// {
//     "key" : "base_ETA",
//     "value" : "Planned ETA"
// }

    //home
    db.getCollection("users").updateMany(
        {"config.client":"IOCL"},
        {
            $push:{
                "config.home.triplistheaders":{
                    $each:[
                        {
                            "key" : "base_ETA",
                            "value" : "Planned ETA"
                        }
                    ]
                }
            }
        })


//Trips
db.getCollection("users").updateMany(
    {"config.client":"IOCL"},
    {
        $push:{
            "config.trips.extra_triplistheaders":{
                $each:[
                    {
                        "key" : "base_ETA",
                        "value" : "Planned ETA"
                    }
                ]

            }
        }
    })


     //reports
     db.getCollection("users").updateMany(
        {"config.client":"IOCL"},
        {
            $pull:{
                "config.reports.report_extra_columns":
                 
                        
                       {"key":"base_ETA"}  
                
            }
        })


         //reports
     db.getCollection("users").updateMany(
        {"config.client":"IOCL"},
        {
            $push:{
                "config.reports.report_extra_columns":{
                    $each:[
                        {
                        "key":"base_ETA",
                        "placeholder":"Planned ETA"
                        }
                    ]
                }
            }
        })