
    db.getCollection("users").updateMany(
  { "username": 
                    {$in:["bangalore@balurghat.co.in", "ho@goelfreightcarriers.com", "accts.bng@mahaveeratransport.com", "nagaraj@omlogistics.co.in", "rahultransportorganisation01@gmail.com", "rajcontainerservice@yahoo.com", "roadlinks.khan@live.com", "syed.mahboob@safexpress.com", "premasunilp@gmail.com", "govindsvc@gmail.com", "corporate.pickup@tciexpress.in", "prabu.rajendran@varuna.net", "vijaycargomovers@yahoo.co.in", "naveen.kumar57@delhivery.com", "blr@cti.in", "dhwanish@ngfc.in", "branchreportskrlmrl@gmail.com", "cr.blr@coldrushlogistics.com", "skln9162@gmail.com", "skbt027@gmail.com", "girish.hn198@gmail.com", "srikempammadevi@gmail.com", "pradeep.s.m.t61@gmail.com", "logistics@srstravels.net", "utrans.inc@gmail.com"]} 
  },
  {
    $set:{
        "config.trips.submittedtripoptions.hide_end_trip":true,
        "config.trips.otheroption.fields_to_edit":["tel","truck_number"] 
    }
  })