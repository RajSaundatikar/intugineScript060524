
    // db.getCollection("users").updateMany(
    // {"config.client":"BAYER"},
    // {
    //     $set:{
    //         "config.marker_on_hover": ["load_id","tel","truck_number","invoice","commodity_entity","lr_number","","last_tracked",""]
    //     }

    // })


        db.getCollection("users").updateOne(
            {"username": "bayer_admin"},
            {
                $set:{
                    "config.marker_on_hover": [
                        {
                            key:"load_id", 
                            value:"Load ID"
                        },
                        {
                            key:"tel",
                            value:"tel"
                        },
                        {
                            key:"truck_number",
                            value:"Truck Number"
                        },
                        {   
                            key:"invoice",
                            value:"SAP Delivery Number"
                        },
                        {
                            key:"commodity_entity",
                            value:"Commodity Entity"
                        },     
                        {
                            key:"lr_number",
                            value:"LR Number"
                        },
                        {
                            key:"last_address",
                            value:"Address"
                        },
                        {
                            key:"last_tracked",
                            value:"Last Track"
                        }
                    ]
                }
        
            })







            db.getCollection("users").updateMany(
            {"config.client": "BAYER"},
            {
                $set:{
                    "config.marker_on_hover": [
                        {
                            key:"load_id", 
                            value:"Load ID"
                        },
                        {
                            key:"tel",
                            value:"Tel"
                        },
                        {
                            key:"truck_number",
                            value:"Truck Number"
                        },
                        {   
                            key:"invoice",
                            value:"SAP Delivery Number"
                        },
                        {
                            key:"commodity_entity",
                            value:"Commodity Entity"
                        },     
                        {
                            key:"lr_number",
                            value:"LR Number"
                        },
                        {
                            key:"last_address",
                            value:"Address"
                        },
                        {
                            key:"last_tracked",
                            value:"Last Track"
                        }
                    ]
                }
        
            })