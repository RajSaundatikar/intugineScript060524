
    db.getCollection("users").updateMany(
            {'config.client': {$in: ['FKT','FKT-Large','Flipkart - Myntra']}, 'config.srcname': {$ne: null}},
            {
                $addToSet:{
                    "config.filter_trips_by": "drops.name"
                }
            })


        

            




              db.getCollection("users").find({'config.client': {$in: ['FKT','FKT-Large','Flipkart - Myntra']}, 'config.srcname': {$ne: null}}).forEach(e => {
                //print(e)
                let abc = e.config;
                print(abc)
                abc["drops.name"] = abc.srcname;
                // print(abc)
                 db.users.updateOne({_id: e._id}, {$set : {config : abc}})
                
              })



























db.users.find(
    {'config.client': {$in: ['FKT']}, 'config.srcname': {$ne: null}}, 
    {username: 1, 'config.filter_trips_by': 1, 'config.srcname': 1, 'config.destname': 1, 'config.drops.name': 1, 'config.client':1})
        







     db.getCollection("users").updateOne(
                { username:"flipkart_durgapurtchub_dgp" },
                { $set: { "config.drops.name": "DurgapurTcHub_DGP" } }
             )