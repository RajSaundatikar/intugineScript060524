
    db.getCollection("users").updateOne(
        { username:"ritcomangalore@ritcologistics.com" },
        {
            $set:{
                
                "config.trips.submittedtripoptions.hide_end_trip": false,
                "config.trips.otheroption.hide_newtrip_button":false,
                "config.trips.submittedtripoptions.hide_start_trip": false,
                
            }
        })