
    db.getCollection("users").updateMany(
                    {"config.client": "Himalaya Production"},
                    {
                        $set:{
                            "config.reports.report_header":[
                                {
                                    "key" : "tel",
                                    "value" : "Driver No."
                                },
                                {
                                    "key" : "operator",
                                    "value" : "Operator"
                                },
                                {
                                    "key" : "truck_number",
                                    "value" : "Vehicle"
                                },
                                {
                                    "key" : "vendor",
                                    "value" : "Transporter"
                                },
                                {
                                    "key" : "srcname",
                                    "value" : "Source"
                                },
                                {
                                    "key" : "destname",
                                    "value" : "Destination"
                                },
                                {
                                    "key" : "actual_start_date_time",
                                    "value" : "Start Date"
                                },
                                {
                                    "key" : "start_time",
                                    "value" : "Start Time"
                                },
                                {
                                    "key" : "source_in_time",
                                    "value" : "Source In Time"
                                },
                                {
                                    "key" : "source_out_time",
                                    "value" : "Source Out Time"
                                },
                                {
                                    "key" : "destination_reached_time",
                                    "value" : "Destination Reached Time"
                                },
                                {
                                    "key" : "dest_out_time",
                                    "value" : "Destination Out Time"
                                },
                                {
                                    "key" : "tripEndDate",
                                    "value" : "End Date"
                                },
                                {
                                    "key" : "tripEndTime",
                                    "value" : "End Time"
                                },
                                {
                                    "key" : "travel_time",
                                    "value" : "Travel Time"
                                },
                                {
                                    "key" : "trip_status",
                                    "value" : "Status"
                                },
                                {
                                    "key" : "track_status",
                                    "value" : "Tracked Status"
                                },
                                {
                                    "key" : "distance_travelled",
                                    "value" : "Distance Travelled (km)"
                                },
                                {
                                    "key" : "distance_remained",
                                    "value" : "Distance Remaining (km)"
                                },
                                {
                                    "key" : "drops",
                                    "value" : "Drops"
                                },
                                {
                                    "key" : "src_gate_in",
                                    "value" : "Source Gate In"
                                },
                                {
                                    "key" : "src_doc_in",
                                    "value" : "Source Doc In"
                                },
                                {
                                    "key" : "src_doc_out",
                                    "value" : "Source Doc Out"
                                },
                                {
                                    "key" : "src_gate_out",
                                    "value" : "Source Gate Out"
                                },
                                {
                                    "key" : "dest_gate_in",
                                    "value" : "Destination Gate In"
                                },
                                {
                                    "key" : "dest_doc_in",
                                    "value" : "Destination Doc In"
                                },
                                {
                                    "key" : "dest_doc_out",
                                    "value" : "Destination Doc Out"
                                },
                                {
                                    "key" : "dest_gate_out",
                                    "value" : "Destination Gate Out"
                                }


                            ]
                        }
                    })