


        db.getCollection("users").updateOne(
            {"username": "yusen_samsonite"},
            {
                $set:{
                    "config.trips.submittedtripoptions.status_update": false,
                    "config.trips.submittedtripoptions.hide_start_trip": true,
                    "config.trips.submittedtripoptions.hide_end_trip": true,
                    "config.trips.submittedtripoptions.hide_update_location": true,
                    "config.trips.otheroption.hide.consent_btn": true
                    
                }
            })