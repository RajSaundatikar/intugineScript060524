
     db.getCollection("users").updateMany(
            {'config.client': "GMMCO INDIA"},
            {
    
    
                $set:{
                    "config.trips.newtripinputfields.$[elem].action_name" : "set_dropdown_data"
                }
            },
            {
                arrayFilters: [
                                { "elem.key": "division" }
                ]
            }
            )



            db.getCollection("users").updateMany(
            {'config.client': "GMMCO INDIA"},
            {
                $addToSet:{
                    "config.trips.newtripinputfields":{
                    "key" : "division_type",
                    "placeholder" : "Division Type",
                    "type" : "list",
                    "values" : [

                    ]
             }
                }
            })


    db.getCollection("users").updateMany(
            {'config.client': "GMMCO INDIA"},
            {
                $set:{

                    "config.trips.data.action_data": [
            {
                "key" : "division",
                "value" : "Equipments",
                "data" : [
                    {
                        "key" : "division_type",
                        "values" : [
                            {
                                "name" : "313D3"
                            },
                            {
                                "name" : "320D3"
                            },
                            {
                                "name" : "323D3"
                            },
                            {
                                "name" : "120 MG"
                            },
                            {
                                "name" : "915 MG"
                            },
                            {
                                "name" : "216 SSL"
                            },
                            {
                                "name" : "636 WL"
                            },
                            {
                                "name" : "656 WL"
                            }
                        ]
                    }
                ]
            },

            {
                 "key" : "division",
                "value" : "Parts",
                "data" : [
                    {
                        "key" : "division_type",
                        "values" : [
                            {
                                "name" : "ADC Parts"
                            },
                            {
                                "name" : "Reman Parts"
                            }
                        ]
                    }
                ]

            }

        ]
                }
            })







