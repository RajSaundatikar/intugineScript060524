
db.getCollection("users").updateMany(
    {"config.client":"ELGI"},
    {
        $push:{
            "config.reports.report_extra_columns":{
                "key" : "eta_days",
                "placeholder" : "SLA"
            }
        }
                
    })



   