



//set

"facilities" : {
    "inclusive_filters" : {
        "trip_location_type" : [
            "SOURCE"
        ],
        "name" : [
            "Pune WH"
        ]
    }
},


//set

    "config.extra_headers" : [
            {
                "title" : "Device managment",
                "path" : "/device_mgmt",
                "show" : true
            }
        ],

        //set
        "config.gps_device" : true,


        //set
        "config.devicemanagment" : {
            "otheroption" : {
                "send_device" : true,
                "check_address" : true,
                "battery_limit" : NumberInt(30),
                "time_limit" : NumberInt(1800000),
                "message_type" : true,
                "check_device_status" : true
            }
        },

        //push

        "config.trips.otheroption" : {
            "devices" : true,
           
        },

        //push

        "config.trips.submittedtripoptions":{
            "to_be_receive_device" : true,
        }



