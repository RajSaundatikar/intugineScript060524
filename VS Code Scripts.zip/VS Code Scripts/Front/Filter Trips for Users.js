db.getCollection("users").updateOne(
  { username: "prasad@lozenpharma.com" },
  {
    $set: {
      "config.filter_trips_by": ["srcname", "destname", "drops.name"],

      "config.srcname": ["Lozen Pharma Pvt Ltd Unit 1"],
      "config.destname": ["Lozen Pharma Pvt Ltd Unit 1"],
    },
  }
);

db.getCollection("users").updateOne(
  { username: "krishanaji.vb@lozenpharma.com" },
  {
    $set: {
      "config.filter_trips_by": ["srcname", "destname", "drops.name"],

      "config.srcname": ["Lozen Pharma Pvt Ltd Unit 2"],
      "config.destname": ["Lozen Pharma Pvt Ltd Unit 2"],
    },
  }
);

db.getCollection("users").updateOne(
  { username: "ram@lozenpharma.com" },
  {
    $set: {
      "config.filter_trips_by": ["srcname", "destname", "drops.name"],

      "config.srcname": [
        "Lozen Pharma Pvt Ltd Unit 1",
        "Lozen Pharma Pvt Ltd Unit 2",
      ],
      "config.destname": [
        "Lozen Pharma Pvt Ltd Unit 1",
        "Lozen Pharma Pvt Ltd Unit 2",
      ],
    },
  }
);

db.getCollection("users").updateOne(
  { username: "globemarketing1@yahoo.com" },
  {
    $set: {
      "config.filter_trips_by": ["srcname", "destname", "drops.name"],

      "config.srcname": ["MS Globe Marketing Enterprise"],
      "config.destname": ["MS Globe Marketing Enterprise"],
    },
  }
);
