
     db.getCollection("users").updateOne(
    {username: "shashank.khare@flipkart.com" },
    {  
        $set:{
           
            "config.filter_trips_by": ["client_client", "srcname", "destname", "drops.name"],
            "config.client_client": ["FKT","Flipkart - Myntra"],
            "config.srcname": ["Motherhub_STV", "Motherhub_STV_BTS"],
            "config.destname": ["Motherhub_STV", "Motherhub_STV_BTS"]
        }
    })


    Filter the login "shashank.khare@flipkart.com" for subclient NL and Myntra
    Filter the login "shashank.khare@flipkart.com" for following facilities at src, hop and dest