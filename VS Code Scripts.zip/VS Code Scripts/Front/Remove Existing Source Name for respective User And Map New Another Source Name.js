
    Set "config.facilities.inclusive_filters.name" in "users" collection to "Bhoomi Seeds And Agritech" from "Smart Chem".
    Also confirm in "facilities" collection that "Bhoomi Seeds And Agritech" exists