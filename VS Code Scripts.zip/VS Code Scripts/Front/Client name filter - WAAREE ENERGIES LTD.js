 db.getCollection("users").updateOne(
        {username:"waaree_energies_limited"},
        {
                $set:{
                    "config.filter_trips_by":["client_name"],
                    "config.client_name":["WAAREE ENERGIES LTD"]
                }
        })