
     
    db.getCollection("users").updateMany(
    {
        "config.client": "RADURE HANDLING"
    },
    {
        $set:{
            "config.logo" : {
                "url" : "https://assetsstatic.s3.ap-south-1.amazonaws.com/vfryt_logo.png",
                "direction" : "left"
            }
        }
    })