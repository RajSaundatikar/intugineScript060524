
        db.getCollection("users").updateMany(
    {username: { $in: ["sophia.s@flipkart.com", "saud.n@flipkart.com", "pankaj.c1@flipkart.com", "subbaredddygari.m@flipkart.com", "nithinkumar.s@flipkart.com", "syed.saddam@flipkart.com"] } },
    {
        $set:{
            "config.filter_trips_by":"client_client" ,
            "config.client_client": ["FKT","Flipkart - Myntra"]
        }
    })