
    db.getCollection("users").updateMany(
    {
        "config.client": "BAYER"
    },
    {
        $push: {
            
            "config.home.report_header":{
                "key":"base_total_distance",
                "value":"Total Distance Between Source and Dest(Km)"
            },

            "config.reports.report_header":{
                "key":"base_total_distance",
               "value" :"Total Distance Between Source and Dest(Km)"
            },

            "config.trips.triplistheaders":{
                "key":"base_total_distance",
                "value":"Total Distance Between Source and Dest(Km)"
            }

        }

    })




    // db.getCollection("users").updateMany(
    //     {
    //         "config.client": "BAYER"
    //     },
    //     {
    //         $pull: {
                
    //             "config.home.report_header":{
    //                 "key":"base_google_distance"
    //             },
    
    //             "config.reports.report_header":{
    //                 "key":"base_google_distance"
    //             },
    
    //             "config.trips.triplistheaders":{
    //                 "key":"base_google_distance"
    //             }
    
    //         }
    
    //     })