
    db.getCollection("facilities").updateMany(
        {client:"DCM SHRIRAM AGRO", "other_details.ro_name":/agra/i},
    {
        $set:{
            "other_details.src_code":"U045"
        }
    })

    // Ran script RoName.js