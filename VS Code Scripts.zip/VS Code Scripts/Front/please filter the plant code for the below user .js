
         db.getCollection("users").updateOne(
    {username:"chayapathi.r@hil.in"},
    {
        $set:{
            "config.filter_trips_by":["location_code"],
            "config.location_code": ["2020"]
        }
    })