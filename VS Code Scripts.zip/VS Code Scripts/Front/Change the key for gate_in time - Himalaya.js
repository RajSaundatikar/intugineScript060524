


      db.getCollection("users").updateMany(
        {  "config.client":"Himalaya Test" },
        { $set: 
                { 
                    "config.trips.extra_triplistheaders.$[elem].key": "src_gate_in",
                    "config.trips.extra_triplistheaders.$[elem].value": "Source Gate In"
                }
         },
        { 
            arrayFilters: [{ "elem.key": "gate_in" }] 
        }
      )
      

      config.trips.extra_triplistheaders