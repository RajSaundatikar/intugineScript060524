
           // "config.trips.newtripinputfields.8.key"
     



   
        db.getCollection("users").updateMany(
            { 'config.client': "MRC India" }, 
            { $pull: { 
                "config.trips.newtripinputfields": { key: "ping_freq" } 
            } }
        );