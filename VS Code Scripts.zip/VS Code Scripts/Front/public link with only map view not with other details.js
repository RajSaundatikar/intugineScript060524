
    db.getCollection("users").updateMany(
            {"config.client":"VEGROW"},
            {
                $set:{
                    "config.public.otheroption.show_only_map": true
            }
        })