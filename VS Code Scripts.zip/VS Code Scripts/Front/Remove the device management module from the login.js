
    db.getCollection("users").updateMany(
        {"config.client": "BHARTI AIRTEL"},
        {
            $pull:{
                
                "config.extra_headers": { "title": "Device managment"}
            }   
        })
    
    
    
    
    
    