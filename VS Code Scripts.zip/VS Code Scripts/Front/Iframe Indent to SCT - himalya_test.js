//iframe indent
//if show pages exist we need to push path : "/indent" and all url should contain https


    db.getCollection("users").updateOne(
        {username:"himalaya_test"},
        {

            $set:{

                "config.modules" : {
                    "OPTED_FOR" : [
                        "INDENT_MANAGEMENT"
                        
                        
                    ],
                    "INDENT_MANAGEMENT" : {
                        "FRONTEND" : {
                            "NAV" : {
                                "title" : "Indent",
                                "path" : "/indent"
                            },
                            "BASE_URL" : "https://demo2.superprocure.com",
                            "creds" : {
                                "URL_KEY" : "token",
                                "token" : "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzX2lkIjoiNjQ3ODM0ZDZkZjliNmJjYjMzN2I0ZjYzIiwidV9pZCI6NzMxNjMsImJfaWQiOjEwNTczNywidHlwZSI6ImZyZWlnaHRlciIsImlhdCI6MTY4NTU5OTQ0NiwiZXhwIjoxNzE3MTM1NDQ2LCJpc3MiOiJzdXBlcnByb2N1cmUtc3NvIn0.e7GKFilJMJiIegBchBjuOC0301o_mo9s29k5HZUZS2AnJh6ocC1_zaAWCgCYwtz3iSuxzjgYIVERZaQ8RxUE1rtVBLuiTrtnFjG2akUXCPSjl8_t1zpDZHm4nQ3WSuJkKEY9OnRyB8UKv6XXPYwyzTkhCjEn6M82yPDLT875J5U"
                            }
                        }
                    }
        
                }

            }
            

        })

        // Should be added to config.modules 


        "config.modules" : {
            "OPTED_FOR" : [
                "INDENT_MANAGEMENT"
                
                
            ],
            "INDENT_MANAGEMENT" : {
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Indent",
                        "path" : "/indent"
                    },
                    "BASE_URL" : "https://demo2.superprocure.com/",
                    "creds" : {
                        "URL_KEY" : "token",
                        "token" : "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzX2lkIjoiNjQ3ODM0ZDZkZjliNmJjYjMzN2I0ZjYzIiwidV9pZCI6NzMxNjMsImJfaWQiOjEwNTczNywidHlwZSI6ImZyZWlnaHRlciIsImlhdCI6MTY4NTU5OTQ0NiwiZXhwIjoxNzE3MTM1NDQ2LCJpc3MiOiJzdXBlcnByb2N1cmUtc3NvIn0.e7GKFilJMJiIegBchBjuOC0301o_mo9s29k5HZUZS2AnJh6ocC1_zaAWCgCYwtz3iSuxzjgYIVERZaQ8RxUE1rtVBLuiTrtnFjG2akUXCPSjl8_t1zpDZHm4nQ3WSuJkKEY9OnRyB8UKv6XXPYwyzTkhCjEn6M82yPDLT875J5U"
                    }
                }
            }

        }