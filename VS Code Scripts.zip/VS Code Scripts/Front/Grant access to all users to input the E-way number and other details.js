
// db.getCollection("users").updateMany(
//     { "config.client": "PBL Transport" },
//     {
//       $addToSet: {
//         "config.trips.newtripinputfields.$[elem].params": {
//           $each: [
//             {
//               key: "ewb_number",
//               placeholder: "Fetch Ewb number",
//             },
//           ],
//         },
//       },
//     },
//     {
//       arrayFilters: [{ "elem.key": "drops" }],
//     }
//   );


  db.getCollection("users").updateMany(
    { "config.client": "PBL Transport",  "config.ewaybillParams":{$exists:false} },
    { 
        $set:{
            "config.ewaybillParams": {
                "username" : "pbltctd_95_API_pbl",
                "password" : "Intutrack@Pbl",
                "gstin" : "37AABCP3169R2ZP"
            }
        },

        $pull:{
            "config.trips.newtripinputfields": {"key" : "drops" }
        }
    })







  db.getCollection("users").updateMany(
    { "config.client": "PBL Transport",  "config.ewaybillParams":{$exists:true} },
    { 
       

        $pull:{
            "config.trips.newtripinputfields": {"key" : "drops" }
        }
    })





    db.getCollection("users").updateMany(
        { "config.client": "PBL Transport",  "config.ewaybillParams":{$exists:true} },
        { 
            $push:{
                "config.trips.newtripinputfields": {
                    "key" : "drops",
                    "type" : "array",
                    "max_length" : 1,
                    "params" : [
                        {
                            "key" : "ewb_number",
                            "placeholder" : "Fetch Ewb number"
                        },
                        {
                            "key" : "invoice",
                            "placeholder" : "Invoice"
                        },
                        {
                            "key" : "loc",
                            "placeholder" : "Location"
                        }
                    ]
                }
            }
    
           
        })















    ,

       

        // {
        //     "key" : "drops",
        //     "type" : "array",
        //     "max_length" : NumberInt(1),
        //     "params" : [
        //         {
        //             "key" : "ewb_number",
        //             "placeholder" : "Fetch Ewb number"
        //         },
        //         {
        //             "key" : "invoice",
        //             "placeholder" : "Invoice"
        //         },
        //         {
        //             "key" : "loc",
        //             "placeholder" : "Location"
        //         }
        //     ]
        // }