
     db.getCollection("users").updateOne(
        {username:"previn.t@wiztracks.com"},
        {
                $set:{
                    "config.filter_trips_by":["submitted_by"],
                    "config.submitted_by":["previn.t@wiztracks.com"]
                }
        })

        db.getCollection("users").updateOne(
            {username:"gopinath.krishnasamy@wiztracks.com"},
            {
                    $set:{
                        "config.filter_trips_by":["submitted_by"],
                        "config.submitted_by":["gopinath.krishnasamy@wiztracks.com"]
                    }
            })