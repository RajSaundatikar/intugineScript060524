
    // "facilities" : {
    //         "inclusive_filters" : {
    //             "trip_location_type" : [
    //                 "SOURCE"
    //             ],
    //             "name" : [
    //                 "Sahyadhri Logistics"
    //             ]
    //         }
    //     }


        db.getCollection("users").updateOne(
    {
        "username": "harjit.singh@expeditors.com"
    },
    {
            $set:{
            "config.facilities": {
                "inclusive_filters" : {
                    "trip_location_type" : [
                        "SOURCE"
                    ],
                    "name" : [
                        "Sahyadhri Logistics"
                    ]
                }
            }
            }
    })