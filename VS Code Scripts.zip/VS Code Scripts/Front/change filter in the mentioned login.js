
     db.getCollection("users").updateOne(
        {username:"carestream"},
        {
                $set:{
                    "config.filter_trips_by":["client_name"],
                    "config.client_name":["CARESTREAM HEALTH INDIA PVT LTD"]
                }
        })