
db.getCollection("users").updateMany(
    {
        username: {
            $in:["rudralogisticskanagala@gmail.com","bsfm.kanagala@gmail.com","ctonipani@gmail.com","mahesh.patil@cjdarcl.com",
                    "eastwest.sudhirkngla@rediffmail.com","sandeep.sagu@gmail.com","khushiramlogisticskngla@gmail.com"]
        }
    },
    {
        $unset:{"config.extra_headers": ""},

        $set:{
            "config.show_pages" : [
                "/home",
                "/history",
                "/reports"
            ]
        }
    })

   // config.extra_headers

 
   db.getCollection("users").updateOne(
    {username:"rudralogisticskanagala@gmail.com"},
    {
            $set:{
                "config.filter_trips_by":["vendor"],
                "config.vendor":["RUDRA LOGISTICS"]
            }
    })
    //

    db.getCollection("users").updateOne(
        {username:"bsfm.kanagala@gmail.com"},
        {
                $set:{
                    "config.filter_trips_by":["vendor"],
                    "config.vendor":["Bombay South Freight Movers"]
                }
        })
    //
        db.getCollection("users").updateOne(
            {username:"ctonipani@gmail.com"},
            {
                    $set:{
                        "config.filter_trips_by":["vendor"],
                        "config.vendor":["Commercial Transport Organisation"]
                    }
            })

            db.getCollection("users").updateOne(
                {username:"mahesh.patil@cjdarcl.com"},
                {
                        $set:{
                            "config.filter_trips_by":["vendor"],
                            "config.vendor":["DARCL Logistics Limited"]
                        }
                })

            db.getCollection("users").updateOne(
        {username:"eastwest.sudhirkngla@rediffmail.com"},
        {
                $set:{
                    "config.filter_trips_by":["vendor"],
                    "config.vendor":["EAST WEST ROADLINES"]
                }
        })

        db.getCollection("users").updateOne(
            {username:"sandeep.sagu@gmail.com"},
            {
                    $set:{
                        "config.filter_trips_by":["vendor"],
                        "config.vendor":["MAA BHAGWATI TRANSPORT"]
                    }
            })

            db.getCollection("users").updateOne(
                {username:"khushiramlogisticskngla@gmail.com"},
                {
                        $set:{
                            "config.filter_trips_by":["vendor"],
                            "config.vendor":["KHUSHI RAM LOGISTICS"]
                        }
                })    