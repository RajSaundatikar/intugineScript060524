
    db.getCollection("users").updateMany(
        {"config.client":"CAPTAIN FRESH"},
        {
            $set:{
                "config.trips.end_trip_form":[
                    {
                        "key":"delivery_date_time",
                        "placeholder": "Delivery Date and Time",
                        "type":"datetime"
                    }
                ]
            }
        })