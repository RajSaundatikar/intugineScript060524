



    db.getCollection("users").updateOne(
            {"username":"ritcohyderabad@ritcologistics.com"},
            {
                $set:{
                    "config.trips.otheroption.hide_newtrip_button":true
                }
            })


            