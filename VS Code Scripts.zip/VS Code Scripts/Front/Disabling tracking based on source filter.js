
db.getCollection("users").updateMany(
    {"config.client":"goex"},
    {
        $set:{
            "config.trips.master_fetch_enabled": true,
            "config.trips.master_data": [
                {
                "key" : "srcname",
                "trip_start_fields" : [
                "noTrack", "expiresAt", "expiryNote"
                                    ]
                }
                ]
        }
    })



    db.getCollection("trips").updateMany(
        {
            "user":"goex", "running":true, "srcname":{$in:["Amboli", "Amta", "Bavliari", "Daman", "Dharwad", "Gummidipundi", "Hyderabad", "Jambusar", "Mahad", "Malur", "Pen", "Ratlam", "Sanand", "Sānpkathāni Khatta", "Umargām", "Velugam"]}
        },
        {
            $set:{
                "expiresAt": new Date(),
                "expiryNote": "INVALID TRIP"
            }
        })