config.home.otheroption.hide.pending_trip_counter,
config.home.otheroption.hide.delayed_trip_counter


    db.getCollection("users").updateOne(
        {username:"waaree_energies_limited"},
        {
            $set:{
                "config.home.otheroption.hide.pending_trip_counter":true,
                "config.home.otheroption.hide.delayed_trip_counter":true,
                "config.home.otheroption.hide.download_report_btn":true

            }
        })

        
        //pending trip counter
        //delayed trip counter
        //mis report button