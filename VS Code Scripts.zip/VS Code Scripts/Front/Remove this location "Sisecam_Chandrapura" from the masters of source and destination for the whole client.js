
   // Removed from facilities


    db.getCollection("facilities").find({"client":"SISECAM"})

     db.getCollection("facilities").deleteOne({"_id" : ObjectId("63fca540dc74ce0008343725")})