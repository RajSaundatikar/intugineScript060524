// OTP Addition and Removal
// To set
// "config.otp_auth": true and create email:"give emailid" outside config

// To remove
// remove "config.otp_auth": true


    db.getCollection("users").updateOne(
        {
            "username":"girish.kumar@flipkart.com"
        },
        {
            $set:{
                "config.otp_auth": true,
                "email":"girish.kumar@flipkart.com"
            }
        })