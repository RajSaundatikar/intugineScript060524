
      //ETA Breach and Geofence Alerts
    
        
      db.getCollection("geofence_alerts_temp").insertOne(
            {
            "user" : "ASAHI GLASS",
            "geofenceAlertData" : {
            "src": 5000,
            "dest": 5000,
            "disableMailAlerts" : false,
            "displayName" : "ASAHI GLASS",
            "alert_emails" : ["rrk.customerqueries@aisglass.com", "kanika.mittal@aisglass.com", "brijpal.singh@aisglass.com"]
            }
            })