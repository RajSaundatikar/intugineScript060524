
    db.getCollection("users").updateMany(
        {"username":{
            $in:["daimlertvspune","daimlertvs_gurugram"]
            }
        },
        {
            $set:{
                "config.home.otheroption.hide.map_markers":true
            }
        })