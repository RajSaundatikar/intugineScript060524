
    db.getCollection("users").updateMany(
            {
                "config.client": "RK Roadways"
            },{
                $set:{
                    "config.reports.report_extra_columns":[{
                        key:"trip_changes",
                        placeholder:"Trip Changes"
                    }]
                }
            })