
    db.getCollection("users").updateOne(
        {username: "monsantoholding@yatayat.com"},
        
        {
            $set:{
                "config.filter_trips_by":["client_name"],
                "config.client_name":["Monsanto holding private limited"]
            }
        })


         //Added client name  in customer_master_data through admin