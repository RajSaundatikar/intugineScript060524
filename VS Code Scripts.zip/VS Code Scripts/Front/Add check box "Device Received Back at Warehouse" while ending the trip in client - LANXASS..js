

            db.getCollection("users").updateMany(
                {"config.client": "LANXASS"},
                {
                    $addToSet:{
                        "config.trips.end_trip_form" :  
                            {
                                "key" : "device_recieved_at_warehouse",
                                "placeholder" : "Device Received Back at Warehouse",
                                "type" : "checkbox",
                                
                            }
                        
                    }
                })