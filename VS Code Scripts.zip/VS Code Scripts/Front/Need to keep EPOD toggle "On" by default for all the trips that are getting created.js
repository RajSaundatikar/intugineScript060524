
     db.getCollection("users").updateMany(
        {"config.client":"Starline Express"},
        {
            $set:{
                "config.trips.otheroption.default_epod_select":true,
                "config.trips.otheroption.edit_epod_select":true
            }
        })