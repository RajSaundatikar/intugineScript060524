
     db.getCollection("users").updateOne(
        {username:"honeywellautomation@yatayat.com"},
        {
            $set:{
                "config.filter_trips_by":["client_name"],
                "config.client_name":["Honeywell Automation India Ltd"]
            }
        })

        //Added client name  in customer_master_data through admin