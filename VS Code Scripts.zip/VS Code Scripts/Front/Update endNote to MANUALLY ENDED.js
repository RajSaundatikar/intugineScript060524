
    db.getCollection("trips").updateMany(
        {"user":"Lets Transport", "running":false, "endNote":{$in:["", null]}},
        {
            $set:{
                "endNote": "MANUALLY ENDED"
            }
        })