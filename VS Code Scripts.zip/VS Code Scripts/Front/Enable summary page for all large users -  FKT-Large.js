
    // where show_pages exist 64 


     db.getCollection("users").updateMany(
    { "config.client": "FKT-Large"
    },
    {
        $set:{
    
            "config.modules.SUMMARY":{
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Summary",
                        "path" : "/summary"
                    },
                    "BASE_URL" : "https://master.dmhqlqdb3g66s.amplifyapp.com/summary"
                }
            },
    
            "config.navbar_headers" : true,  //1  
    
            "config.home_path" : "/summary", //2 landing page
            
    
            "config.navbar_headers_field" : [ //3 headbar sequence
                {
                    "title" : "SUMMARY",
                    "path" : "/summary",
                    "show" : true
                },
                {
                    "title" : "HOME",
                    "path" : "/home",
                    "show" : true
                },
                {
                    "title" : "TRIPS",
                    "path" : "/trips",
                    "show" : true
                },
                {
                    "title" : "TIMELINE",
                    "path" : "/timeline",
                    "show" : true
                },
                {
                    "title" : "HISTORY",
                    "path" : "/history",
                    "show" : true
                },
               
                {
                    "title" : "Live View",
                    "path" : "/all-tracker",
                    "show" : true
                },
                {
                    "title" : "INDENT",
                    "path" : "/indent",
                    "show" : true
                }
                
            ]
    
    
        }
        
    })


    db.getCollection("users").updateMany(
        {"config.client":"FKT-Large"},
        {
            $addToSet:{
                "config.modules.OPTED_FOR": "SUMMARY"
            }
        })

        db.getCollection("users").updateMany(
            {"config.client":"FKT-Large","config.show_pages":{$exists:true}},
            {
                $addToSet:{
                    "config.show_pages": "/summary"
                }
            })

