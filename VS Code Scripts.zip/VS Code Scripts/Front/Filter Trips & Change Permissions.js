
      db.getCollection("users").updateMany(
    {username: { $in: ["mateen@eliteroadways.com", "lingrajpatil@shivanicarriers.com", "globemarketing1@yahoo.com", "sgldelhi15@gmail.com", "sredelhi15@gmail.com"] } },
    {
        $set:{
            "config.filter_trips_by":["transporter_code"],
            "config.transporter_code": ["3005583"]
        }
    })


    db.getCollection("users").updateMany(
        {username: { $in: ["mateen@eliteroadways.com", "lingrajpatil@shivanicarriers.com", "globemarketing1@yahoo.com", "sgldelhi15@gmail.com", "sredelhi15@gmail.com"] } },
        {
            $set:{
                "config.trips.submittedtripoptions.hide_end_trip": true,
                "config.trips.submittedtripoptions.edit":false,
                "config.trips.submittedtripoptions.status_update": false
            }
        })