
    https://sct.intutrack.com/?#!/all-tracker?basic_cred=ek9zVWp0WWdiVXByTm1MQVdhdXp4Y3FDRGc3WFI3ekdoSFBzWWVybTREMFl0N2tmZDZkV3Jma1BkTVNKbWJ5cjpSUjA2cUJ1bWlSZmNXaGlOelNnN3N6ZndVaGc1NWN6Tkd4cGZXa1ZCODdrOGV0YkxkRmpHRWxYTkhzeWwxb25m&hideNavbar=true


    https://sct.intutrack.com/?#!/all-tracker?basic_cred=QjhvZ1NFZ3BIdWRzMGNvV2ZGdzFZSUI1NEFBUVRrakp4czdoZUJXaVJEWWJxMU5RUWFFWEltUFVMRk9iZnJWSTpzaHBmT2J5S1RSeTNDNHhUbzJNR0tvMjJRM0p3ejI2ZE14MmQyb3p1WUNSam8yelFRRXRkRVJlbmo4TVl0V1VZ&hideNavbar=true

    base url - https://sct.intutrack.com/?#!/all-tracker?basic_cred=
get token from user config user  = btoa(apisecret.username: apisecret.password)
and set &hideNavbar=true to hide navigation bar 





    https://sct.intutrack.com/?#!/all-tracker?basic_cred=(here btoa(apisecret.username : apisecret.password))&hideNavbar=true