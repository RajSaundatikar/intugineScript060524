 //config.home.otheroption.show_fastag_tracked_counter
    

    db.getCollection("users").updateMany(
                {"config.client": "Lakshmi Cargo Company"},
                {
                    $set:{
                        "config.home.otheroption": {
                        
                                "show_fastag_tracked_counter" : true
                            
                        }
                    
                    }
                })


               



               