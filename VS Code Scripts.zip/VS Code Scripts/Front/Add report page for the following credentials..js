
     db.collectionName.find({
                "config.navbar_headers_field": {
                  $elemMatch: { "path": "/control-tower" }
                }
              })



              db.getCollection("users").find({username:{$in:["vineesh.r@flipkart.com", "rohan.verghese@flipkart.com", "bhargav.pratim@flipkart.com", "asish.chacko@flipkart.com", 
              "hemanshu.dhangar@flipkart.com", "sujay.pb@flipkart.com"]}, "config.navbar_headers_field":{$elemMatch: { "path": "/summary" }}}).count()



            //   {
            //     "title" : "REPORTS",
            //     "path" : "/reports",
            //     "show" : true
            // }

            db.getCollection("users").updateMany(
                { 
                    username:  
                    {   
                        $in:["vineesh.r@flipkart.com", "rohan.verghese@flipkart.com", "bhargav.pratim@flipkart.com", "asish.chacko@flipkart.com", 
                                "hemanshu.dhangar@flipkart.com", "sujay.pb@flipkart.com"]
                    }
            },
            {   
                        $push:{
                            "config.navbar_headers_field":{
                                "title" : "REPORTS",
                                "path" : "/reports",
                                "show" : true
                            },

                            "config.show_pages": "/reports"
                                
                            
                        }       
            }

            )