
      db.getCollection("users").updateMany(
    {
        "config.client": "krisll Logistics"
    },
    {
        $set:{
            "config.logo" : {
                "url" : "https://assetsstatic.s3.ap-south-1.amazonaws.com/krisll_logo.jpg",
                "direction" : "left"
            }
        }
    })