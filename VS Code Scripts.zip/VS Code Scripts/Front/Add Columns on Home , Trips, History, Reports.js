


//home
    db.getCollection("users").updateMany(
        {"config.client":"Himalaya Test"},
        {
            $push:{
                "config.home.triplistheaders":{
                    $each:[
                        {"key":"spRequistionId",
                        "value":"Requisition ID"
                        },
                        {
                            "key": "vendor",
                            "value": "Transporter"
                        }
                    ]
                }
            }
        })


//Trips
db.getCollection("users").updateMany(
    {"config.client":"Himalaya Test"},
    {
        $set:{
            "config.trips.extra_triplistheaders":[
                       {
                            "key":"spRequistionId",
                            "value":"Requisition ID"
                        },
                        {
                            "key": "vendor",
                            "value": "Transporter"
                        }
            ]
        }
    })

    
    
    //history
    db.getCollection("users").updateMany(
    {"config.client":"Himalaya Test"},
    {
        $set:{
            "config.history":{
                "extra_triplistheaders":[
                    {
                         "key":"spRequistionId",
                         "value":"Requisition ID"
                     },
                     {
                         "key": "vendor",
                         "value": "Transporter"
                     }
            ]
            }
        }
    })
    
    //reports
    db.getCollection("users").updateMany(
        {"config.client":"Himalaya Test"},
        {
            $set:{
                "config.reports.extra_triplistheaders":[
                           {
                                "key":"spRequistionId",
                                "value":"Requisition ID"
                            },
                            {
                                "key": "vendor",
                                "value": "Transporter"
                            }
                ]
            }
        })