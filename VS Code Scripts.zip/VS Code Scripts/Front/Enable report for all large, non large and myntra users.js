
    db.getCollection("users").updateMany(
                { 
                    "config.client":"FKT_Main", "config.navbar_headers_field":{$exists:true}, "config.show_pages":{$exists:true}
            },
            {   
                        $addToSet:{
                            "config.navbar_headers_field":{
                                "title" : "REPORTS",
                                "path" : "/reports",
                                "show" : true
                            },

                            "config.show_pages": "/reports"
                                
                            
                        }       
            })