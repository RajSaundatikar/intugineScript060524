
    //filterDrops.js reference hops

    db.getCollection("users").updateMany(
    {username:{$in:["deepalisharma_vc", "sachinsingh_vc"]}},
    {
        $set:{
            "config.filter_trips_by": ["srcname", "destname", "drops.name"],

            "config.srcname": ["Motherhub_FRK", "Motherhub_GGN", "Motherhub_JAI", "GroceryMH_RWR", "GroceryMH_DEL", "Motherhub_JKS", "LKO_Flex", "GroceryMH_LKO", "Motherhub_LKO", "Motherhub_LUH", "Motherhub_BAM", "Motherhub_BNO", "Motherhub_DIC", "MotherHub_BAM", "BLP_ML", "BLP1_ML", "BNL_ML", "CND_ML", "MotherHub_JAI_BTS", "MotherHub_LKO", "Motherhub_VNI", "Motherhub_YKB", "Motherhub_DEL", "Motherhub_JJH"],

            "config.destname": ["Motherhub_FRK", "Motherhub_GGN", "Motherhub_JAI", "GroceryMH_RWR", "GroceryMH_DEL", "Motherhub_JKS", "LKO_Flex", "GroceryMH_LKO", "Motherhub_LKO", "Motherhub_LUH", "Motherhub_BAM", "Motherhub_BNO", "Motherhub_DIC", "MotherHub_BAM", "BLP_ML", "BLP1_ML", "BNL_ML", "CND_ML", "MotherHub_JAI_BTS", "MotherHub_LKO", "Motherhub_VNI", "Motherhub_YKB", "Motherhub_DEL", "Motherhub_JJH"] ,

        }
    })



    db.getCollection("users").find({username: {$in: ["deepalisharma_vc", "sachinsingh_vc"]   }}).forEach((k) => {
        let new_config = k.config;
        new_config["drops.name"] = k.config.srcname;
        //new_config["filter_trips_by"].push("drops.customer_code");
        print(new_config)
        
        db.getCollection('users').updateOne(
        {_id: k._id, },  
            {
            $set: {
                config: new_config
            }
        })
        
    })



    deepalisharma_vc   https://app2.superprocure.com/loadBoard?token=MTg3NTU2OkQ5NDYwNTQzODExODhDRkFGNDEwNURBRTJGNkY4RkNE

    sachinsingh_vc     https://app2.superprocure.com/loadBoard?token=MTg3NTU3OjM1MzYyOTI3N0I5Q0QzM0I4RDM0MEZBQkNDRDU4RjFG


    