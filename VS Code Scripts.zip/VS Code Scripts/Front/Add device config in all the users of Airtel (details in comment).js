
db.getCollection("users").updateMany(
{
    username:{
        $in:["ramesh.singh@airtel.com", "a_amar.salve@airtel.com", "a_appaso.s.katakar@airtel.com", "pramod.panchwag@kuehne-nagel.com", "koregaon.operation@airtel.com", "vasant.jadhav@kuehne-nagel.com", "satish.alhat@kuehne-nagel.com", "ganesh.shivale@kuehne-nagel.com"]
    }
},
{
    $set:{

        "config.facilities" : {
            "inclusive_filters" : {
                "trip_location_type" : [
                    "SOURCE"
                ],
                "name" : [
                    "Pune WH"
                ]
            }
        },
        
        "config.extra_headers" : [
            {
                "title" : "Device managment",
                "path" : "/device_mgmt",
                "show" : true
            }
        ],

        "config.gps_device" : true,

        "config.devicemanagment" : {
            "otheroption" : {
                "send_device" : true,
                "check_address" : true,
                "battery_limit" : 30,
                "time_limit" : 1800000,
                "message_type" : true,
                "check_device_status" : true
            }
        },


        "config.trips.otheroption.devices" : true,

        "config.trips.submittedtripoptions.to_be_receive_device": true

    }
})
