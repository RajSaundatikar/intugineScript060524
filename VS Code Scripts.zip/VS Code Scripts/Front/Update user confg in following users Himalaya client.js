
//     update following data inside config.trips.otheroption

// "sequence_update_status" : [
// "GATE_IN",
// "DOC_IN",
// "DOC_OUT",
// "GATE_OUT"
// ]

    db.getCollection("users").updateMany(
        {username: { $in: ["akshaykumar.s@himalayawellness.com", "ambala.mwh1@himalayawellness.com", "hyd.mw@himalayawellness.com", "bgl.wh@himalayawellness.com", "indore.mwh@himalayawellness.com", "kolkata.mwh1@himalayawellness.com", "cfa.ahm.kbshah@himalayawellness.com", "cfa.bhiw.ramdas@himalayawellness.com", "cfa.bhubaneswar@himalayawellness.com", "cfa.chennai@himalayawellness.com", "cfa.delhi@himalayawellness.com", "cfa.ernakulam@himalayawellness.com", "cfa.sahibabad@himalayawellness.com", "cfa.guwahati@himalayawellness.com", "cfa.hyderabad@himalayawellness.com", "cfa.sudhir.indore@himalayawellness.com", "cfa.jaipur@himalayawellness.com", "cfa.kolkata@himalayawellness.com", "cfa.lucknow@himalayawellness.com", "cfa.madurai@himalayawellness.com", "cfa.nagpur@himalayawellness.com", "cfa.patna@himalayawellness.com", "cfa.pune.pharma@himalayawellness.com", "cfa.raipur@himalayawellness.com", "cfa.ranchi@himalayawellness.com", "cfa.zirakpur@himalayawellness.com", "cfa.jabalpur@himalayawellness.com", "cfa.dehradun@himalayawellness.com", "cfa.hubli@himalayawellness.com", "cfa.bangalore@himalayawellness.com", "cfa.vijayawada@himalayawellness.com", "cfa.goa@himalayawellness.com", "cfa.siliguri@himalayawellness.com", "ahmedabadcfasec", "bhiwandicfasec", "bhubaneswarcfasec", "chennaicfasec", "delhicfasec", "ernakulamcfasec", "ghaziabadcfasec", "guwahaticfasec", "hyderabadcfasec", "indorecfasec", "jaipurcfasec", "kolkatacfasec", "lucknowcfasec", "maduraicfasec", "nagpurcfasec", "patnacfasec", "punecfasec", "raipurcfasec", "ranchicfasec", "zirakpurcfasec", "jabalpurcfasec", "dehraduncfasec", "hublicfasec", "bangalorenewsec", "vijayawadacfasec", "goacfasec", "siliguricfasec", "tumkurplantsec", "ambalamwhsec", "hyderabadmwhsec", "bangaloremwhsec", "indoremwhsec", "kolkatamwhsec"] } },
        {
            $set:{
                "config.trips.otheroption.sequence_update_status": [
                    "GATE_IN",
                    "DOC_IN",
                    "DOC_OUT",
                    "GATE_OUT"
                    ]
            }
        })