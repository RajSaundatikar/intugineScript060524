



    db.getCollection("users").updateMany(
        {'config.client': "GHCL"},
        {
            $addToSet: {
                "config.reports.report_extra_columns": {
                    "key": "src_name",
                    "placeholder": "Standardize Source Name"
                }
            }
        })