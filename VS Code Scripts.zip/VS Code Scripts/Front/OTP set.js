
    db.getCollection("users").updateOne(
        {
            "username":"vijaykumarvtc@yahoo.com"
        },
        {
            $set:{
                "config.otp_auth": true,
                "email":"vijaykumarvtc@yahoo.com"
            }
        })