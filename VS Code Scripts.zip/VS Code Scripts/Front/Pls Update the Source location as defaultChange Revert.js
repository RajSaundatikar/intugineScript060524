
    db.getCollection("users").find({username:"vivekkhonde1@dcmshriram.com"})

//Removed facilities object from document which was at the bottom