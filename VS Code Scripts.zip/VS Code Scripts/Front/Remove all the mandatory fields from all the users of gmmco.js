
    db.getCollection("users").updateMany(
    { "config.client":"GMMCO INDIA" },
    {
        $set:{
            "config.trips.mandatorinputfields": ["srcname", "dest", "tel"]
        }
    })