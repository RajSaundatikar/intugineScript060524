
    //  db.getCollection("facilities").updateMany({"client" : "", "name":{$in:["BANGALORE", "HOSUR", "NELLORE", "KANCHIPURAM", "CHENNAI","PERUNDURAI"]}},
    // {
    //     $set:{
    //         "eta_data" : {
    //             "Chakan" : 1
    //         }
    //     }
    // })
    db.getCollection("facilities").insertMany(
        [
            {
    
                "name" : "Jogeshwari Station",
                "client" : "mahindra",
                "client_client" : "Mahindra Logistics Bussiness Unit 1",
                "trip_location_type" : [
                    "Destination"
                ],
                "location" : [
                    19.150556,72.851356
                ],
                "eta_data" : {
                                 "Chakan" : 0.15
                           },
                "extra_info" : {
            
                }
            },
            {
    
                "name" : "Chinchwad Station",
                "client" : "mahindra",
                "client_client" : "Mahindra Logistics Bussiness Unit 1",
                "trip_location_type" : [
                    "Destination"
                ],
                "location" : [
                    18.637464,73.793785
                ],
                "eta_data" : {
                    "Chakan" : 0.04
              },
                "extra_info" : {
            
                }
            },
            {
    
                "name" : "Khadki Station",
                "client" : "mahindra",
                "client_client" : "Mahindra Logistics Bussiness Unit 1",
                "trip_location_type" : [
                    "Destination"
                ],
                "location" : [
                    18.560470,73.842094
                ],
                "eta_data" : {
                    "Chakan" : 0.04
              },
                "extra_info" : {
            
                }
            },
            {
    
                "name" : "Loni Station",
                "client" : "mahindra",
                "client_client" : "Mahindra Logistics Bussiness Unit 1",
                "trip_location_type" : [
                    "Destination"
                ],
                "location" : [
                    18.494573,74.012229
                ],
                "eta_data" : {
                    "Chakan" : 0.05
              },
                "extra_info" : {
            
                }
            },
            {
    
                "name" : "Nashik Station",
                "client" : "mahindra",
                "client_client" : "Mahindra Logistics Bussiness Unit 1",
                "trip_location_type" : [
                    "Destination"
                ],
                "location" : [
                    19.940334100000015,73.8385992
                ],
                "eta_data" : {
                    "Chakan" : 0.18
              },
                "extra_info" : {
            
                }
            }
        ])

