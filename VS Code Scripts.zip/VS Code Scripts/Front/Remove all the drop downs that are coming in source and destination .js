Removed all the facilities documents of client "BHARTI AIRTEL"
