
    


                    db.getCollection("users").updateMany(
                        {"username": "intuginemrc@intugine.com"},
                        {
                            $set:{
                                "config.home.otheroption.share_link": true
                            }
                        })