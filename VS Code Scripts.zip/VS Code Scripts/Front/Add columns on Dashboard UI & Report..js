
    //home
    db.getCollection("users").updateMany(
        {"config.client":"IOCL"},
        {
            $push:{
                "config.home.triplistheaders":{
                    $each:[
                        {
                            "key":"src_code",
                            "value":"Plant Code"
                        },
                        {
                            "key": "dest_code",
                            "value": "Customer Code"
                        },
                        {
                            "key": "vendor",
                            "value": "Transporter"
                        }
                    ]
                }
            }
        })


//Trips
db.getCollection("users").updateMany(
    {"config.client":"IOCL"},
    {
        $set:{
            "config.trips.extra_triplistheaders":[
                {
                    "key":"src_code",
                    "value":"Plant Code"
                },
                {
                    "key": "dest_code",
                    "value": "Customer Code"
                },
                {
                    "key": "vendor",
                    "value": "Transporter"
                }
            ]
        }
    })

    
    
    //history
    db.getCollection("users").updateMany(
    {"config.client":"IOCL"},
    {
        $set:{        
                "config.history.extra_triplistheaders":[
                    {
                        "key":"src_code",
                        "value":"Plant Code"
                    },
                    {
                        "key": "dest_code",
                        "value": "Customer Code"
                    },
                    {
                        "key": "vendor",
                        "value": "Transporter"
                    }
                ]
            
        }
    })


    db.getCollection("users").updateMany(
        {"config.client":"IOCL"},
        {
            $set:{
                
                "config.reports.report_extra_columns":[
                    {
                        "key":"src_code",
                        "placeholder":"Plant Code"
                    },
                    {
                        "key": "dest_code",
                        "placeholder": "Customer Code"
                    },
                    {
                        "key": "vendor",
                        "placeholder": "Transporter"
                    }
                ]
            }
        })


  