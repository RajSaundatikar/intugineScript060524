
    db.getCollection("users").updateMany(
        {"config.client":"Lets Transport"},
        {
            $set:{
                "config.trips.uniq_trip_key": "truck_number"
            }   
        })

        