
    db.getCollection("users").updateOne(
        {
            "username":"tvpbilling@mohanindia.co.in"
        },
        {
            $set:{
                "config.otp_auth": true,
                "email":"tvpbilling@mohanindia.co.in"
            }
        })