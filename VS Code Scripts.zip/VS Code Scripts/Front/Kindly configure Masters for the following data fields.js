
//     master_data = [
// {
//     "action_data": [
//     {
//         "key": "contracted_lsp",
//         "value": "Maha Shakti Tanker"
//     }],
//     "data":
//     {
//         "contracted_lsp": "Maha Shakti Tanker"
//     },
//     "key": "contracted_lsp",
//     "value": "Maha Shakti Tanker"
// }]

    // Push

db.getCollection("users").updateMany(
    {"config.client": "LANXASS"},
    {
        $push:{
            "config.trips.otheroption.master_data_list" : 
                {
                    "key" : "contracted_lsp",
                    "parameter" : "contracted_lsp_list",
                    "form_keys" : [
                        "contracted_lsp"
                    ]
                }
        }
    })


    "config.trips.master_upload" : [ 
        {
            "key" : "contracted_lsp",
            "value" : "Contracted LSP",
            "headers" : [ 
                {
                    "key" : "contracted_lsp",
                    "value" : "Contracted LSP"
                }
            ]
        }
    ]