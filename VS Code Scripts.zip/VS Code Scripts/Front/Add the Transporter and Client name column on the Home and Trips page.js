//vendor,  client_name
    db.getCollection("users").updateMany(
    {"config.client":"SISECAM"},
    {
        $push:{
            
            "config.home.triplistheaders": {
                $each:[
                    {
                        "key": "vendor",
                        "value": "Transporter"
                    },
                    {
                        "key":"client_name",
                        "value":"Client Name"
                    }
                    
                ]
            },

            "config.trips.extra_triplistheaders": {
                $each:[
                    {
                        "key": "vendor",
                        "value": "Transporter"
                    },
                    {
                        "key":"client_name",
                        "value":"Client Name"
                    }
                    
                ]
            }

        }

        
    })
