db.getCollection("users").updateMany(
  {
    "config.client": "LEGRAND GROUP",
  },
  {
    $push: {
      "config.trips.mandatorinputfields": "lr_number",
    },
  }
);
