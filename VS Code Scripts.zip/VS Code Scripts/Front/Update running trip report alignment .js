        
        db.getCollection("users").updateMany(
            {'config.client': "FKT_Main"},
            {
                $set:{
                    "config.reports.report_header": [
                        {
                            "key" : "invoice",
                            "value" : "Invoice"
                        },
                        {
                            "key" : "tel",
                            "value" : "Driver No."
                        },
                        {
                            "key" : "operator",
                            "value" : "Operator"
                        },
                        {
                            "key" : "truck_number",
                            "value" : "Vehicle"
                        },
                        {
                            "key" : "vendor",
                            "value" : "Transporter"
                        },
                        {
                            "key" : "shipmentNumber",
                            "value" : "FK Shipment Number"
                        },
                        {
                            "key" : "spLoadId",
                            "value" : "Indent Load ID"
                        },
                        {
                            "key" : "srcname",
                            "value" : "Source"
                        },
                        {
                            "key" : "destname",
                            "value" : "Destination"
                        },
                        {
                            "key" : "trip_route",
                            "value" : "Route"
                        },
                        {
                            "key" : "actual_start_date_time",
                            "value" : "Start Date"
                        },
                        {
                            "key" : "source_in_time",
                            "value" : "Source In Time"
                        },
                        {
                            "key" : "source_out_time",
                            "value" : "Source Out Time"
                        },
                        {
                            "key" : "last_tracked",
                            "value" : "Last Tracked"
                        },
                        {
                            "key" : "last_address",
                            "value" : "Last Known Location"
                        },
                        {
                            "key" : "trip_status",
                            "value" : "Status"
                        },
                        {
                            "key" : "delay_formatted",
                            "value" : "SLA Status"
                        },
                        {
                            "key" : "f_base_ETA",
                            "value" : "design SLA"
                        },
                        {
                            "key" : "trip_eta",
                            "value" : "ETA"
                        },
                        {
                            "key" : "track_status",
                            "value" : "Tracked Status"
                        },
                        {
                            "key" : "distance_travelled",
                            "value" : "Distance Travelled (km)"
                        },
                        {
                            "key" : "distance_remained",
                            "value" : "Distance Remaining (km)"
                        },
                        {
                            "key" : "latest_event_status",
                            "value" : "Latest Event"
                        },
                        {
                            "key" : "latest_event_status_time",
                            "value" : "Latest Event Time"
                        },
                        {
                            "key" : "latest_event_status_name",
                            "value" : "Event Location Name"
                        },
                        {
                            "key" : "latest_event_status_type",
                            "value" : "Event Location Type"
                        },
                        {
                            "key" : "destination_reached_time",
                            "value" : "Destination Reached Time"
                        },
                        {
                            "key" : "dest_out_time",
                            "value" : "Destination Out Time"
                        },
                        {
                            "key" : "trip_end_time",
                            "value" : "Trip End Time"
                        },
                        {
                            "key" : "last_city",
                            "value" : "Latest City"
                        },
                        {
                            "key" : "loading_delay",
                            "value" : "Loading Delay"
                        },
                        {
                            "key" : "unloading_delay",
                            "value" : "Unloading Delay"
                        },
                        {
                            "key" : "spSubBranchName",
                            "value" : "Movement Type"
                        },
                        {
                            "key" : "latest_lock_event_time",
                            "value" : "Latest Lock Event Time"
                        },
                        {
                            "key" : "latest_lock_event_location",
                            "value" : "Latest Lock Event Location"
                        },
                        {
                            "key" : "latest_tamper_alert_time",
                            "value" : "Latest Tamper Alert Time"
                        },
                        {
                            "key" : "latest_tamper_alert_location",
                            "value" : "Latest Tamper Alert Location"
                        },
                        {
                            "key" : "source_eta",
                            "value" : "Source ETA"
                        },
                        {
                            "key" : "drop_eta",
                            "value" : "Drop ETA"
                        },
                        
                        {
                            "key" : "device_lock_status",
                            "value" : "Device Status"
                        },
                        {
                            "key" : "tracking_type",
                            "value" : "Tracking Type"
                        },
                        {
                            "key" : "endNote",
                            "value" : "End Note"
                        },
                        {
                            "key" : "spLoadingDate",
                            "value" : "Expected Loading Date",
                            "type" : "date"
                        },
                        {
                            "key" : "lock_vendor_name",
                            "value" : "Lock vendor name"
                        },
                        {
                            "key" : "indentCreationDateTime",
                            "value" : "Indent Creation Date",
                            "type" : "date"
                        },
                        {
                            "key" : "indentAcceptanceDateTime",
                            "value" : "Indent Acceptance Date",
                            "type" : "date"
                        },
                        {
                            "key" : "plannedDistance",
                            "value" : "Planned Distance as per Indent"
                        },
                        {
                            "key" : "drops",
                            "value" : "Drops"
                        }
        
                    ]
                }
            })

  









