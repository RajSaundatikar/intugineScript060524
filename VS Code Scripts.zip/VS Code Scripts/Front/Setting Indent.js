
      db.getCollection("users").updateOne(
        {username:"balveer.kumhar@flipkart.com"},
        {

            $set:{

                "config.modules" : {
                    "OPTED_FOR" : [
                        "INDENT_MANAGEMENT"
                        
                        
                    ],
                    "INDENT_MANAGEMENT" : {
                        "FRONTEND" : {
                            "NAV" : {
                                "title" : "Indent",
                                "path" : "/indent"
                            },
                            "BASE_URL" : "https://app2.superprocure.com/loadBoard",
                            "creds" : {
                                "URL_KEY" : "token",
                                "token" : "MTI2MDQyOjE4RUJGNkM1QTdCMzBBNkIxMzlCRjFBNTA5MTRBNTg3"
                            }
                        }
                    }
        
                }

            }
            

        })