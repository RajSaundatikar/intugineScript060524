
    db.getCollection("users").updateOne(
        { username:"pblgajuwaka" },
        {
            $set:{
                
                "config.trips.otheroption.hide_newtrip_button":false
            }
        })