db.getCollection("users").updateMany(
  { "config.client": "yatayat" },
  {
    $push: {
      "config.home.triplistheaders": {
        key: "location_types_fetched",
        value: "Mode of tracking",
      },
    },
  }
);

db.getCollection("users").updateMany(
  { "config.client": "yatayat" },
  {
    $push: {
      "config.reports.report_extra_columns": {
        key: "location_types_fetched",
        placeholder: "Mode of tracking",
      },
    },
  }
);
