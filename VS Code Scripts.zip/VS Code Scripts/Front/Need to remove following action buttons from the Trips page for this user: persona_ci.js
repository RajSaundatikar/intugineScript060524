
    db.getCollection("users").updateOne(
        { username:"persona_ci" },
        {
            $set:{
                "config.trips.submittedtripoptions.edit": false,
                "config.trips.submittedtripoptions.hide_end_trip": true,
                "config.trips.submittedtripoptions.hide_update_location": true,
                "config.trips.otheroption.hide.consent_btn": true
            }
        })