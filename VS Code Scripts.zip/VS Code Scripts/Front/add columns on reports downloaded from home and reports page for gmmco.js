
      db.getCollection("users").updateMany(
        {"config.client": "GMMCO INDIA"},
        {
            $push:{
                "config.reports.report_header": {
                    $each:[
                        {
                            "key": "be_number",
                            "value": "BE Number"
                        },
                        {
                            "key": "be_date",
                            "value": "BE Date",
                            "type": "date"
                        },
                        {
                            "key": "bl_number",
                            "value": "BL NO / AirWay Bill NO"
                        },
                        {
                            "key": "bl_date",
                            "value": "BL Date / AirWay Bill Date",
                            "type": "date"
                        }
                    ]
                }
                    
            }
        })





        db.getCollection("users").updateMany(
            {"config.client": "GMMCO INDIA"},
            {
                $set:{
                        "config.reports.report_extra_columns": [
                            
                                {
                                    "key": "be_number",
                                    "placeholder": "BE Number"
                                },
                                {
                                    "key": "be_date",
                                    "placeholder": "BE Date",
                                    "type": "date"
                                },
                                {
                                    "key": "bl_number",
                                    "placeholder": "BL NO / AirWay Bill NO"
                                },
                                {
                                    "key": "bl_date",
                                    "placeholder": "BL Date / AirWay Bill Date",
                                    "type": "date"
                                }
                            
                            ]
                }
            })










       