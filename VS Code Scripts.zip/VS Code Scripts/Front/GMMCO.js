
    db.getCollection("users").updateMany(
        {"config.client":"GMMCO INDIA"},
        {
            $addToSet:{
                "config.trips.newtripinputfields":{
                    $each:[
                        {
                            "key" : "vehicle_type",
                            "placeholder" : "Vehicle Type",
                            "type" : "list",
                            "values": [
                                {"name": "LBT"},
                                {"name": "SLBT"},
                                {"name": "HBT"},
                                {"name": "19 Feet Truck"},
                                {"name": "20 Feet Truck"},
                                {"name": "20 Taurus"},
                                {"name": "Through Service Provider - Delhivery"},
                                {"name": "Through Service Provider - Xpressbees"},
                                {"name": "Others"}
                            ]
                        },
                        {
                            "key" : "eway_date",
                            "placeholder" : "EWAY Bill Date",
                            "type" : "date"
                        }
                    ]
                }
            }
        })




        db.getCollection("users").updateMany(
            {'config.client': "GMMCO INDIA"},
            {
    
    
                $push:{
                    "config.trips.newtripinputfields.$[elem].values" : {
                        $each:[
                            {"name":"JLG"},
                            {"name":"Engines"},
                            {"name":"Gensets"},
                            {"name":"Others"}
                        ]
                    }
                }
            },
            {
                arrayFilters: [
                                { "elem.key": "division" }
                ]
            }
            )


            db.getCollection("users").updateMany(
                {'config.client': "GMMCO INDIA"},
                {
                    $push:{
                        "config.trips.newtripinputfields.$[elem].params" : {
                            $each:[
                        {
                            "key" : "be_number",
                            "placeholder" : "BE Number"
                        },
                        {
                            "key" : "be_date",
                            "placeholder" : "BE Date",
                            "type" : "date"
                        },
                        {
                            "key" : "bl_number",
                            "placeholder" : "BL NO / AirWay Bill NO"
                            
                        },
                        {
                            "key" : "bl_date",
                            "placeholder" : "BL Date / AirWay Bill Date",
                            "type" : "date"
                        },
                        {
                            "key" : "invoice_date",
                            "placeholder" : "Invoice Date",
                            "type" : "date"
                        },
                        {
                            "key" : "lr_date",
                            "placeholder" : "LR Date",
                            "type" : "date"
                        }
                            ]
                        }
                    }
                },
                {
                    arrayFilters: [
                                    { "elem.key": "drops" }
                    ]
                }
                )


            
                       