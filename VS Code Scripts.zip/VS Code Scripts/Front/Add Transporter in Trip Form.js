
    db.getCollection("users").updateMany(
   {"config.client":"Shree Cements"},
   { $push: { "config.trips.newtripinputfields.$[elem].values": { "name": "NATIONAL TRANSPORT" } } },
   {
    arrayFilters: [
        { "elem.key": "vendor" }
    ]  
}
)




//config.trips.newtripinputfields.1.values.0.name