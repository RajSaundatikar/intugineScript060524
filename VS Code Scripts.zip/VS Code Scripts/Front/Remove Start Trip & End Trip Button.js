
     db.getCollection("users").updateMany(
        {"config.client": "Himalaya Production" },
        {
            $set:{
                "config.trips.submittedtripoptions.hide_end_trip": true,
                "config.trips.submittedtripoptions.edit":false
            }
        })


        db.getCollection("users").updateMany(
            {"config.client": "Himalaya Production" },
            {
                $set:{
                    "config.trips.submittedtripoptions.hide_end_trip": true,
                    "config.trips.submittedtripoptions.hide_start_trip": true
                }
            })