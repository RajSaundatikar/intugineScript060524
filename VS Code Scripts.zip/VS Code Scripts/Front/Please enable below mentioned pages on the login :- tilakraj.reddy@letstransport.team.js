
    // $push in "config.show_pages" and $set extra_headers

    "/trips", "/timeline", "/history", "/reports", "/all-tracker", "/epod", "device_mgmt"



        "extra_headers" : [
            {
                "title" : "Device managment",
                "path" : "/device_mgmt",
                "show" : true
            }]
