
    db.getCollection("users").updateOne(
    {"username":"venkatesh.k@hil.in"},
    {
        $set:{
            "config.filter_trips_by":["location_code"],
            "config.location_code": ["2010", "2013", "2022", "2006", "2008", "2039", "2017", "2018", "2026", "2040", "2020"]
        }
    })