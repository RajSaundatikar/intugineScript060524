
    db.getCollection("users").updateMany(
    { "username": {$in:["bsfm.kanagala@gmail.com", "ctonipani@gmail.com", "mahesh.patil@cjdarcl.com", "eastwest.sudhirkngla@rediffmail.com", "sandeep.sagu@gmail.com", "khushiramlogisticskngla@gmail.com"] }},
    {
        $set:{
            "config.home.triplistheaders":[
                {
                    "key" : "truck_number",
                    "value" : "Vehicle"
                },
                {
                    "key" : "tel",
                    "value" : "Tel"
                },
                {
                    "key" : "srcname",
                    "value" : "Source"
                },
                {
                    "key" : "destname",
                    "value" : "Destination"
                },
                {
                    "key" : "invoice",
                    "value" : "Invoice"
                },
                {
                    "key" : "start_time",
                    "value" : "Start Time"
                },
                {
                    "key" : "reached",
                    "value" : "E.T.A."
                },
                {
                    "key" : "last_tracked",
                    "value" : "Last Tracked"
                }
            ]
        }

    })