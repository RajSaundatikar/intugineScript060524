//in user "config.modues"

    db.getCollection("users").updateOne(
        {username:"goldplus_kanagla"},
        {
            $set:{
                "config.modules.INPLANT_TRIPS.FRONTEND.creds.token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDc5OTk4Yzg2OTJkNDFjYWNiZmYyYzYiLCJ1c2VybmFtZSI6ImdvbGRwbHVzX2thbmFnbGEiLCJ3YXJlaG91c2UiOlsiV2FyZWhvdXNlIDEiXSwiY2xpZW50IjoiZ29sZHBsdXNfa2FuYWdsYSIsImlhdCI6MTY4NTY5MTMyNn0.iWV-XSWAGQozhd22m6X1DrigP3jdx5Py_cMxvgMOJMA"
            }
    
        })


        