
     db.getCollection("users").updateOne(
        {username:"ser.kolkata@gmail.com"},
        {
                $set:{
                    "config.filter_trips_by":["submitted_by"],
                    "config.submitted_by":["ser.kolkata@gmail.com"]
                }
        })