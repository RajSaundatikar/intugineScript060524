db.getCollection("users").updateMany(
{"config.client" : "BAYER"},
{
    $set:{
        "config.reports.report_header":
                [{
                    "key" : "tel",
                    "value" : "Driver Mobile Number"
                },
                {
                    "key" : "operator",
                    "value" : "Operator"
                },
                {
                    "key" : "truck_number",
                    "value" : "Truck Number"
                },
                {
                    "key" : "status",
                    "value" : "Status"
                },
                {
                    "key" : "last_tracked",
                    "value" : "Last Track"
                },
                {
                    "key" : "delay_interval",
                    "value" : "Delivery Status"
                },
                {
                    "key" : "srcname",
                    "value" : "Source"
                },
                {
                    "key" : "src_wh_code",
                    "value" : "Source WH Code"
                },
                {
                    "key" : "src_city",
                    "value" : "Source City"
                },
                {
                    "key" : "src_pincode",
                    "value" : "Source Pincode"
                },
                {
                    "key" : "destname",
                    "value" : "Destination"
                },
                {
                    "key" : "dest_city",
                    "value" : "Destination City"
                },
                {
                    "key" : "dest_pincode",
                    "value" : "Destination Pincode"
                },
                {
                    "key" : "dest_zone",
                    "value" : "Destination Zone"
                },
                {
                    "key" : "startTime",
                    "value" : "Start Time"
                },
                {
                    "key" : "endTime",
                    "value" : "End Time"
                },
                {
                    "key" : "reached",
                    "value" : "E.T.A."
                },
                {
                    "key" : "base_ETA",
                    "value" : "Expected Date of Delivery"
                },
                {
                    "key" : "customer_code",
                    "value" : "Customer Code"
                },
                {
                    "key" : "transporter_code",
                    "value" : "Transporter Code"
                },
                {
                    "key" : "vendor",
                    "value" : "Transporter Name"
                },
                {
                    "key" : "load_id",
                    "value" : "Load ID/ SAP Shipment Number"
                },
                {
                    "key" : "src_ETA",
                    "value" : "Load ID Date/ SAP Shipment Date"
                },
                {
                    "key" : "invoice",
                    "value" : "SAP Delivery Number"
                },
                {
                    "key" : "lr_number",
                    "value" : "LR Number"
                }]
            }
})


db.getCollection("users").updateMany(
    {"config.client" : "BAYER"},
    {
        $set:{
            "config.home.report_header":
                    [{
                        "key" : "tel",
                        "value" : "Driver Mobile Number"
                    },
                    {
                        "key" : "operator",
                        "value" : "Operator"
                    },
                    {
                        "key" : "truck_number",
                        "value" : "Truck Number"
                    },
                    {
                        "key" : "status",
                        "value" : "Status"
                    },
                    {
                        "key" : "last_tracked",
                        "value" : "Last Track"
                    },
                    {
                        "key" : "delay_interval",
                        "value" : "Delivery Status"
                    },
                    {
                        "key" : "srcname",
                        "value" : "Source"
                    },
                    {
                        "key" : "src_wh_code",
                        "value" : "Source WH Code"
                    },
                    {
                        "key" : "src_city",
                        "value" : "Source City"
                    },
                    {
                        "key" : "src_pincode",
                        "value" : "Source Pincode"
                    },
                    {
                        "key" : "destname",
                        "value" : "Destination"
                    },
                    {
                        "key" : "dest_city",
                        "value" : "Destination City"
                    },
                    {
                        "key" : "dest_pincode",
                        "value" : "Destination Pincode"
                    },
                    {
                        "key" : "dest_zone",
                        "value" : "Destination Zone"
                    },
                    {
                        "key" : "startTime",
                        "value" : "Start Time"
                    },
                    {
                        "key" : "endTime",
                        "value" : "End Time"
                    },
                    {
                        "key" : "reached",
                        "value" : "E.T.A."
                    },
                    {
                        "key" : "base_ETA",
                        "value" : "Expected Date of Delivery"
                    },
                    {
                        "key" : "customer_code",
                        "value" : "Customer Code"
                    },
                    {
                        "key" : "transporter_code",
                        "value" : "Transporter Code"
                    },
                    {
                        "key" : "vendor",
                        "value" : "Transporter Name"
                    },
                    {
                        "key" : "load_id",
                        "value" : "Load ID/ SAP Shipment Number"
                    },
                    {
                        "key" : "src_ETA",
                        "value" : "Load ID Date/ SAP Shipment Date"
                    },
                    {
                        "key" : "invoice",
                        "value" : "SAP Delivery Number"
                    },
                    {
                        "key" : "lr_number",
                        "value" : "LR Number"
                    }]
                }
    })