
    db.getCollection("users").updateMany(
        {"config.client": "Himalaya Production"},
        {
            $set:{
                'config.trips.allowDuplicateTelTrips': true
            }
        })