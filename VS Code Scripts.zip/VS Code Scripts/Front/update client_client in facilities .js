

        db.getCollection("facilities").updateMany(
        {client: "mahindra", "createdAt" : { $gte: ISODate("2023-07-27T12:20:40.734+0000")}},
        {
            $set:{
                "client_client": "swaraj"
            }
        })