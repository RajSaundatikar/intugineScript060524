
    db.getCollection("users").updateOne(
    {username:"anand.maa@flyjac.com"},
    {
        $set:{
            
            "config.client_name": ["HARMAN INTERNATIONAL INDIA PVT LTD-CHENNAI"]
        },

        $push:{
            "config.filter_trips_by": "client_name"
        }
    })