
    db.getCollection("users").updateMany(
        {"config.client":"Shipsy"},
        {
            $set:{
                
                "config.reports.report_extra_columns":[{
                    key: "location_types_fetched",
                    placeholder: "Tracking Mode"
                    }]
            }
        })