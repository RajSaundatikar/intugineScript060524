
     db.getCollection("users").updateMany(
        {"config.client" : "Haier"},
        {
            
            $set:{

                "config.reports.report_header":[
                    {
                        "key" : "o_start_date",
                        "value" : "Dispatch Date",
                        "type" : "date_only"
                    },
                    {
                        "key" : "o_start_time",
                        "value" : "Dispatch Time",
                        "type": "time"
                    },
                    {
                        "key" : "srcname",
                        "value" : "Source"
                    },
                    {
                        "key" : "dest_name_input",
                        "value" : "Destination"
                    },
                    {
                        "key" : "vendor",
                        "value" : "Transporters"
                    },
                    {
                        "key" : "truck_number",
                        "value" : "Vehicle Number"
                    },
                    {
                        "key" : "tel",
                        "value" : "Driver Number"
                    },
                    {
                        "key" : "reached",
                        "value" : "E.T.A."
                    },
                    {
                        "key" : "last_city",
                        "value" : "Current Location"
                    },
                    {
                        "key" : "last_tracked",
                        "value" : "Last Track"
                    },
                    {
                        "key" : "start_time",
                        "value" : "In-Transit Date & Time"
                    },
                    {
                        "key" : "last_remark_time",
                        "value" : "Waiting for Unloading Date & Time"
                    },
                    {
                        "key" : "reached_set_time",
                        "value" : "Reporting date",
                        "type" : "date_only"
                    },
                    {
                        "key" : "distance_travelled",
                        "value" : "Distance Travelled (Km)"
                    },
                    {
                        "key" : "distance_remained",
                        "value" : "Distance Remaining (Km)"
                    },
                    {
                        "key" : "track_status",
                        "value" : "Tracking Status"
                    },
                    {
                        "key" : "current_halt_duration",
                        "value" : "Current Halt"
                    },
                    {
                        "key" : "moving_type",
                        "value" : "Movement"
                    },
                    {
                        "key" : "last_address",
                        "value" : "Last Known Location"
                    },
                    {
                        "key" : "invoice",
                        "value" : "Invoice"
                    },
                    {
                        "key" : "operator",
                        "value" : "Operator"
                    },
                    {
                        "key" : "trip_status",
                        "value" : "Status"
                    }
                

                ]

            }
            

        })



    //Remaining