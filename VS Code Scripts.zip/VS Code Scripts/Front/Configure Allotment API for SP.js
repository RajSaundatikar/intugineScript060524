//Insert this in customer_master_data

db.getCollection("customer_master_data").insertOne(
        {
            "_id" : "superprocuretest|partnerClientId#partnerBranchId|HMLA#BLRW",
            "user" : "superprocuretest",
            "client_client" : null,
            "key" : "partnerClientId#partnerBranchId",
            "value" : "HMLA#BLRW",
            "data" : {
                "username" : "himalaya_test"
            },
            "updatedAt" : new Date()
        })