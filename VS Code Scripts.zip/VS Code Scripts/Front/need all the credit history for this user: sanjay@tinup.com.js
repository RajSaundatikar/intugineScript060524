
    


  db.getCollection("transactions").find({userId:ObjectId("61d2d0782210a8363fda6664"), type:"credit"})

//   db.getCollection("transactions").find(
//     {
//         userId: ObjectId("61d2d0782210a8363fda6664"), 
//         "createdAt" :  {
//             $gte: ISODate("2021-11-17")
//           }
// })
