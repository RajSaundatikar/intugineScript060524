db.getCollection("users").updateMany(
  { "config.client": "Haier" },
  {
    $set: {
      "config.trips.bulk_upload": {
        show: true,
        google: true,
        fixed_headers: true,
        triplistheaders: [
          {
            key: "tel",
            value: "Driver Number",
          },
          {
            key: "srcname",
            value: "Source",
          },
          {
            key: "truck_number",
            value: "Truck number",
          },
          {
            key: "vendor",
            value: "Transporter",
          },
          {
            key: "destname",
            value: "Dealer Name",
          },
        ],
      },
    },
  }
);

// db.getCollection("users").updateMany(
//     {'config.client': "ASAHI GLASS"},
//     {
//         $set:{
//             "config.trips.bulk_upload" : {
//                 "show" : true,
//                 "google" : true,
//                 "fixed_headers" : true
//             }
//         }
//     })
