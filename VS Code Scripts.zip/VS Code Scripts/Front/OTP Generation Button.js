
     db.getCollection("users").updateMany(
            {"config.client":"Wowtruck Technologies"},
            {
                $set:{
                    "config.trips.otheroption.otp_lock":true
            }
        })






           
            