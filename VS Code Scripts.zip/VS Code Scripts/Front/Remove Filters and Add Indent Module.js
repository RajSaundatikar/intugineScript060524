
          db.getCollection("users").updateOne(
        {username:"anup.bhardwaj@in.yusen-logistics.com"},
        {

            $set:{

                "config.modules" : {
                    "OPTED_FOR" : [
                        "INDENT_MANAGEMENT"
                        
                        
                    ],
                    "INDENT_MANAGEMENT" : {
                        "FRONTEND" : {
                            "NAV" : {
                                "title" : "Indent",
                                "path" : "/indent"
                            },
                            "BASE_URL" : "https://app2.superprocure.com",
                            "creds" : {
                                "URL_KEY" : "token",
                                "token" : "MzAyMDk4OjI2QkE0MDg0ODQ0RUM4OUQyQkExMzY4RTk4MURDNDZC"
                            }
                        }
                    }
        
                }

            }
            

        })

        db.getCollection("users").updateOne(
            {username:"yuvaraj.d@in.yusen-logistics.com"},
            {
    
                $set:{
    
                    "config.modules" : {
                        "OPTED_FOR" : [
                            "INDENT_MANAGEMENT"
                            
                            
                        ],
                        "INDENT_MANAGEMENT" : {
                            "FRONTEND" : {
                                "NAV" : {
                                    "title" : "Indent",
                                    "path" : "/indent"
                                },
                                "BASE_URL" : "https://app2.superprocure.com",
                                "creds" : {
                                    "URL_KEY" : "token",
                                    "token" : "MzAyMTAxOjlDMzY0OEE3RkRGODBEQkYxMzhBRjQxNzM5NjQ3MTQ5"
                                }
                            }
                        }
            
                    }
    
                }
                
    
            })