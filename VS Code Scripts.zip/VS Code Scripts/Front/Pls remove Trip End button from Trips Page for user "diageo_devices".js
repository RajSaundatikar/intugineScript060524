//set this to true
//"config.trips.submittedtripoptions.hide_end_trip"


    db.getCollection("users").updateOne(
    {"username":"diageo_devices"},
    {
        $set:{
            "config.trips.submittedtripoptions.hide_end_trip":true
        }
    }) 