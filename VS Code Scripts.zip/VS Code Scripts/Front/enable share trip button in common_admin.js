
    db.getCollection("users").updateOne(
        { username:"common_admin" },
        {
            $set:{
                
                "config.trips.otheroption.hide.share_trip": false
                   
            }
        })