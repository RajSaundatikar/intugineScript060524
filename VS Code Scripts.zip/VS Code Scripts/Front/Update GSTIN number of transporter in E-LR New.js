
     db.getCollection("users").updateMany(
        {"config.client" : "bridgestone", "config.vendor":"MVT"},
        {
            $set:{
                "config.lr.static_fields.vendor_gstin": "88AAACM5917F1ZO"
            }
        })