
     db.getCollection("users").updateOne(
    {username: "amsaveni.b@flipkart.com" },
    {
        $set:{
            "config.filter_trips_by":["client_client"],
            "config.client_client": ["FKT","Flipkart - Myntra"]
        }
    })