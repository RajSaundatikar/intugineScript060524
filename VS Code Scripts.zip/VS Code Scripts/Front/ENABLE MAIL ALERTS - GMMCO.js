
    db.getCollection("users").updateMany(
    { "config.client":"GMMCO INDIA", "config.alerts.halt":{$exists:true} },
    {
        $set:{

            "config.alerts.halt.haltParams": [
                {
                    "durationThreshold" : 21600000, 
                    "sendOncePerHalt" : true,
                    "recipients" : [
                        "appavuraja.b@gmmcoindia.com",
                        "hidayathullah.m@gmmcoindia.com"
                    ]
                },
                {
                    "durationThreshold" : 43200000, 
                    "sendOncePerHalt" : true,
                    "recipients" : [
                        "muthukumar.m@gmmcoindia.com"
                    ]
                },
                {
                    "durationThreshold" : 86400000, 
                    "sendOncePerHalt" : true,
                    "recipients" : [
                        "muthukumar.m@gmmcoindia.com"
                    ]
                }
            ],

            "config.alerts.halt.recipients.client" : []


        }

    })