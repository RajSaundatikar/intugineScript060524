//newtripinputfields
    db.getCollection("users").updateMany(
            {'config.client': "Starline Express"},
            {
                $push:{
                    "config.trips.newtripinputfields":{
                                "key" : "custom_trip_id",
                                "placeholder" : "Trip ID",
                                "type" : "text"
                    }
                }
            })