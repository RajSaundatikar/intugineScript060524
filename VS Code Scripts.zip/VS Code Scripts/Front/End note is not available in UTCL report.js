
    
    db.getCollection("users").updateMany(
    {
        "config.client": "ultratech"

    },
    {
        $push: {
            "config.reports.report_extra_columns":{
                key:"endNote",
                placeholder:"End Note"
            }
        }
    })

