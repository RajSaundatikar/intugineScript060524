
     db.getCollection("users").updateMany(
    {
        "config.client": "FKT_Main"

    },
    {
        $push: {
            
            "config.reports.report_extra_columns":{
                $each:
                [
                    {
                        "key":"indentCreationDateTime",
                        "placeholder" :"Indent Creation Date",
                        "type": "date"
                    },
                    {
                        "key":"indentAcceptanceDateTime",
                        "placeholder" :"Indent Acceptance Date",
                        "type": "date"
                    },
                    {
                        "key":"plannedDistance",
                        "placeholder" :"Planned Distance as per Indent"
                    }
                ]
                
            },

            "config.reports.report_header":{
               $each:[
                    {
                        "key":"indentCreationDateTime",
                        "value" :"Indent Creation Date",
                        "type": "date"
                    },
                    {
                        "key":"indentAcceptanceDateTime",
                        "value" :"Indent Acceptance Date",
                        "type": "date"
                    },
                    {
                        "key":"plannedDistance",
                        "value" :"Planned Distance as per Indent"
                    }
                ]
            }
        }
    })




    db.getCollection("users").updateOne(
    {
        "username": "large"

    },
    {
        $push: {
            
            "config.reports.report_extra_columns":{
                $each:
                [
                    {
                        "key":"indentCreationDateTime",
                        "placeholder" :"Indent Creation Date",
                        "type": "date"
                    },
                    {
                        "key":"indentAcceptanceDateTime",
                        "placeholder" :"Indent Acceptance Date",
                        "type": "date"
                    },
                    {
                        "key":"plannedDistance",
                        "placeholder" :"Planned Distance as per Indent"
                    }
                ]
                
            },

            "config.reports.report_header":{
               $each:[
                    {
                        "key":"indentCreationDateTime",
                        "value" :"Indent Creation Date",
                        "type": "date"
                    },
                    {
                        "key":"indentAcceptanceDateTime",
                        "value" :"Indent Acceptance Date",
                        "type": "date"
                    },
                    {
                        "key":"plannedDistance",
                        "value" :"Planned Distance as per Indent"
                    }
                ]
            }
        }
    })