//"LEAP INDIA"
//ashish.yadav@leapindia.net : UP05
//sushil.shrivastava@leapindia.net : UP06

// Set 'config.filter_trips_by' : ['wh_code']
// Set 'config.wh_code' : value e.g. UP05

db.getCollection("users").updateOne(
    {username:"ashish.yadav@leapindia.net"},
    {
        $set:{
            
            "config.wh_code": "UP05",
            "config.customer_code": "UP05"
            
        }
    })


    db.getCollection("users").updateOne(
        {username:"sushil.shrivastava@leapindia.net"},
        {
            $set:{
                
                "config.wh_code": "UP06",
                "config.customer_code": "UP06"
            }
        })