
     db.getCollection("users").updateMany(
            {"username": { $in: ["yusen_nexg", "yusen_cbc", "yusen_sharp", "yusen_toray", "yusen_lumileds", "yusen_fisher", "yusen_technova", "yusen_adeka", "yusen_konica", "yusen_lexmark", "yusen_asics", "yusen_brother", "yusen_samsonite"] } },
            {
                $set:{
                    
                    "config.home.otheroption.hide_filter" : false
                    
                }
            })



// To remove transporter field from side filter
            db.getCollection("users").updateMany(
                {"username": { $in: ["yusen_nexg", "yusen_cbc", "yusen_sharp", "yusen_toray", "yusen_lumileds", "yusen_fisher", "yusen_technova", "yusen_adeka", "yusen_konica", "yusen_lexmark", "yusen_asics", "yusen_brother", "yusen_samsonite"] } },
                {
                    $push:{
                        'config.home.options.disabled_filter_keys' : "vendor"
                    }
                })