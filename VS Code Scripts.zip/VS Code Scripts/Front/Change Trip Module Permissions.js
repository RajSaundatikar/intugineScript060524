
    db.getCollection("users").updateMany(
        {"username": { $in:["quickersupplychainsolutions@gmail.com", "operations@trackmytrucks.in"] } },
        {
            $set:{
                "config.trips.submittedtripoptions.hide_end_trip": true,
                "config.trips.submittedtripoptions.edit":false,
                "config.trips.submittedtripoptions.status_update": false
            }
        })