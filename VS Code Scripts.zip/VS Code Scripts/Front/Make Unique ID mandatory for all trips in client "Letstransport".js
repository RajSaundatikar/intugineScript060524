    db.getCollection("users").updateMany(
    {
        "config.client": "Lets Transport"
    },
    {
        $addToSet:{
            "config.trips.mandatorinputfields": "unique_id"
        }
    })
