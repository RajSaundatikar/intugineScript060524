
    db.getCollection("users").updateMany(
        {'config.client': 'bridgestone', 'config.vendor': "DIPTAB"},
        {
            $set:{
                "config.lr.static_fields.phone_number": 8178519402
            }
        }
        )