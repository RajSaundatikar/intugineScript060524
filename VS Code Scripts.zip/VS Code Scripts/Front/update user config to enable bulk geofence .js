
db.getCollection("users").updateMany(
        {username:{$in:["p_copy", "parixitsinh.kosada@flipkart.com", "barath.kumar@flipkart.com", "b_copy", "common_admin"]} },
        {
            $set:{

                "config.trips.otheroption.bulk_geofence_upload": true
            }
        })





     