
    db.getCollection("users").updateMany(
    {
        "config.client": "FKT_Main"

    },
    {
        $push: {
            
            "config.reports.report_extra_columns":{
                "key":"lock_vendor_name",
                "placeholder":"Lock vendor name"
            },

            "config.reports.report_header":{
                "key":"lock_vendor_name",
               "value" :"Lock vendor name"
            }
        }
    })