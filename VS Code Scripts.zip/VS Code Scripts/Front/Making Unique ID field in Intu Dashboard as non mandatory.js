
    db.getCollection("users").updateMany(
    {
        "config.client": "Lets Transport"
    },
    {
        $pull:{
            "config.trips.mandatorinputfields": "unique_id"
        }
    })