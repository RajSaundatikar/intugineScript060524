 // $push below object in navbar_headers_field

        {
            "title" : "REPORTS",
            "path" : "/reports",
            "show" : true
        },