
    //config.trips.newtripinputfields.5.params


    db.getCollection("users").updateMany(
    {"config.client":"BAYER"},
    {
        $push:{
            "config.trips.newtripinputfields.$[elem].params":{
                            "key" : "lr_number",
                            "placeholder" : "LR Number"
            }
        }
    },
    {
        arrayFilters: [
                            { "elem.key": "drops" }]
    }
    )


    db.getCollection("users").updateMany(
        {
            "config.client":"BAYER"
        },
        { $pull: { "config.trips.newtripinputfields": { "key": "lr_number" } } }
     )






               