
    db.getCollection("users").updateMany(
        {"config.client": "HMEL"},
        {
            $set:{
                "config.alerts.halt.haltParams.durationThreshold": 64800000
            }
        })


        // db.getCollection("users").updateMany(
        //     {   "config.client": "HMEL"  },
        //     {
        //        $set: {
        //           "config.alerts.halt.haltParams.$[element].durationThreshold": 64800000
        //        }
        //     },
        //     {
        //        arrayFilters: [
        //         { "element.durationThreshold": 432000000 }
        //     ]
        //     }
        //  )
         


         db.getCollection("users").updateMany(
            { "config.client": "HMEL", "config.alerts.halt.haltParams.durationThreshold": 43200000 },
            {
                $set: {
                    "config.alerts.halt.haltParams.$[element].durationThreshold": 64800000
                }
            },
            {
                arrayFilters: [
                    { "element.durationThreshold": 43200000 }
                ]
            }
        )