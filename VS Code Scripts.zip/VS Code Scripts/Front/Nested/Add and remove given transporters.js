
    db.getCollection("users").updateMany(
        {'config.client': "Shree Cements"},
        {


            $push:{
                "config.trips.newtripinputfields.$[elem].values" : {
                    $each:[
                        {"name":"Kutch Logistics"},
                        {"name":"Shree Saraswati Roadways Transport"}
                    ]
                }
            }
        },
        {
            arrayFilters: [
                            { "elem.key": "vendor" }
            ]
        }
        )














        

        db.getCollection("users").updateMany(
            {'config.client': "Shree Cements"},
            {
    
    
                $pull:{
                    "config.trips.newtripinputfields.$[elem].values" : {
                       "name": "Kataria Logistics"
                    }
                }
            },
            {
                arrayFilters: [
                                { "elem.key": "vendor" }
                ]
            }
            )

        