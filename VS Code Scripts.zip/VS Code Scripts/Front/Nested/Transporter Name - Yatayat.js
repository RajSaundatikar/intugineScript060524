db.getCollection("users").updateMany(
  { "config.client": "yatayat" },
  {
    $set: {
      "config.trips.newtripinputfields.$[elem].type": "list",
      "config.trips.newtripinputfields.$[elem].values": [
        {
          name: "Yatayat Corporation India Pvt. Ltd",
        },
      ],
    },
  },
  {
    arrayFilters: [{ "elem.key": "vendor" }],
  }
);
