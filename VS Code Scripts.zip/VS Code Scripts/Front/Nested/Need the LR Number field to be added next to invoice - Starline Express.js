



        db.getCollection("users").updateMany(
            {'config.client': "Starline Express"},
            {
                $pull:{
                    "config.trips.newtripinputfields" :  { "key" : "lr_number"}
                }
            }
            )


         

    db.getCollection("users").updateMany(
            {'config.client': "Starline Express"},
            {
              $push:{
                "config.trips.newtripinputfields.$[elem].params" : {

                     $each:[
                            {
                                "key" : "lr_number",
                                "placeholder" : "LR Number",
                                "type" : "text"
                            }
                           ],$position: 1

                                
                            }
                    }
            },
                    {
                        arrayFilters: [
                                        { "elem.key": "drops" }
                        ]
                    }
                    )




db.getCollection("users").updateMany(
    {
      'config.client': "Starline Express"
    },
    {
      $unset: {
        "config.trips.newtripinputfields.$[elem].params.$[innerElem].type": ""
      }
    },
    {
      arrayFilters: [
        {
          "elem.key": "drops"
        },
        {
          "innerElem.key": "lr_number"
        }
      ]
    }
  )


  