
    db.getCollection("users").updateMany(
        {'config.client': "LEGRAND GROUP"},
        {
            $push:{
                "config.trips.newtripinputfields.$[elem].values" : {
                    "name":"Cogoport Private Limited"
                }
            }
        },
        {
            arrayFilters: [
                            { "elem.key": "vendor" }
            ]
        }
        )






        