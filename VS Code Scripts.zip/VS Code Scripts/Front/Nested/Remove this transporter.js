
        db.getCollection("users").updateMany(
            {'config.client': "Shree Cements"},
            {
    
    
                $pull:{
                    "config.trips.newtripinputfields.$[elem].values" : {
                       "name": "Mahesh Transport Co"
                    }
                }
            },
            {
                arrayFilters: [
                                { "elem.key": "vendor" }
                ]
            }
            )