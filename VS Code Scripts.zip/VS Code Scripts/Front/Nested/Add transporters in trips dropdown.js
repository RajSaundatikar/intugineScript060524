db.getCollection("users").updateMany(
  { "config.client": "Haier" },
  {
    $push: {
      "config.trips.newtripinputfields.$[elem].values": {
        $each: [
          { name: "S.A.Roadlines" },
          { name: "Bhagawati" },
          { name: "Shelke Roadlines" },
          { name: "Mahaveera Transport" },
          { name: "GRTC" },
          { name: "Shree Shyam" },
          { name: "Keshav Roadlines" },
          { name: "Maa Vasihno Roadlines" },
          { name: "Mahindra Logistics" },
          { name: "Dosti Road carrier pvt ltd" },
        ],
      },
    },
  },
  {
    arrayFilters: [{ "elem.key": "vendor" }],
  }
);
