
    db.getCollection("users").updateMany(
   {"config.client":"yatayat"},
   { $push: { "config.trips.newtripinputfields.$[elem].values": { "name": "BHARAT CERTIS AGRISCIENCE LIMITED" } } },
   {
    arrayFilters: [
        { "elem.key": "client_name" }
    ]  
}
)