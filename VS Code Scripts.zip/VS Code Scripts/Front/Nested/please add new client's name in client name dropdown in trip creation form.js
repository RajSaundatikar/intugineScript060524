
db.getCollection("users").updateMany(
   {"config.client":"proconnect"},
   { $push: { "config.trips.newtripinputfields.$[elem].values": { "name": "CARESTREAM HEALTH INDIA PVT LTD" } } },
   {
    arrayFilters: [
        { "elem.key": "client_name" }
    ]  
}
)






// db.getCollection("users").updateOne(
//     {"username":"proconnect"},
//     { $push: { "config.trips.newtripinputfields.$[elem].values": { "name": "CARESTREAM HEALTH INDIA PVT LTD" } } },
//     {
//      arrayFilters: [
//          { "elem.key": "client_name" }
//      ]  
//  }
//  )