
db.getCollection("users").updateMany(
    {'config.client': "Shree Cements"},
    {
        $push:{
            "config.trips.newtripinputfields.$[elem].values" : {
                "name":"Mahesh Transport Co"
            }
        }
    },
    {
        arrayFilters: [
                        { "elem.key": "vendor" }
        ]
    }
    )