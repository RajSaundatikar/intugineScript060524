
       db.collectionName.find({
                "config.navbar_headers_field": {
                  $elemMatch: { "path": "/control-tower" }
                }
              })