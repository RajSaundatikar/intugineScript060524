
    


    db.getCollection("users").updateMany(
    {"config.client":"BAYER"},
    {
        $push:{
            "config.trips.newtripinputfields.$[elem].params":{
                            "key" : "spoc_email",
                            "placeholder" : "Spoc Email"
            }
        }
    },
    {
        arrayFilters: [
                            { "elem.key": "drops" }]
    }
    )