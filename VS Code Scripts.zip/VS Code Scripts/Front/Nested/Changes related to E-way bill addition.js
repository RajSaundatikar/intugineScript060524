
                     {
                            "key" : "ewb_number",
                            "placeholder" : "Fetch Ewb number"
                        }


                        

                        // db.students.updateOne(
                        //     { _id: 2 },
                        //     {
                        //       $push: {
                        //          scores: {
                        //             $each: [ 20, 30 ],
                        //             $position: 2
                        //          }
                        //       }
                        //     }
                        //  )



                         //config.trips.newtripinputfields.7.params.0.key



                    


//      db.getCollection("users").updateMany(
//    {"config.client":"Prozo"},
//    { $push: { "config.trips.newtripinputfields.$[elem].params": { 
//                             "key" : "ewb_number",
//                             "placeholder" : "Fetch Ewb number"
//                          } 
//             } 
//     },
//    {
//     arrayFilters: [
//         { "elem.key": "drops" }
//     ]  
// }
// )


//First way

db.getCollection("users").updateMany(
   {"config.client": "Prozo"},
   {
      $set: {
         "config.trips.newtripinputfields.$[elem].params": [
            {
               "key": "ewb_number",
               "placeholder": "Fetch Ewb number"
            },
            {
               "key": "invoice",
               "placeholder": "Invoice No."
            },
            {
               "key": "loc",
               "placeholder": "Destination"
            }
         ]
      }
   },
   {
      arrayFilters: [
         { "elem.key": "drops" }
      ]
   }
)



//Second way

db.getCollection("users").updateMany(
   {"config.client": "Prozo"},
   {
      $push: {
         "config.trips.newtripinputfields.$[elem].params": {
            $each:[
            {
               "key": "ewb_number",
               "placeholder": "Fetch Ewb number"
            }
          
         ],$position:0
         }
      }
   },
   {
      arrayFilters: [
         { "elem.key": "drops" }
      ]
   }
)




 db.getCollection("users").updateMany(
  { "config.client": "Prozo" },
  {
    $set:{
        "config.trips.otheroption.hide_eway_in_input_box":true
    }
  })
