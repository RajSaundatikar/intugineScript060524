//1 Business Unit Details coming up from SP
    db.getCollection("users").updateMany(
        {"config.client":"HIL Limited"},
        {
            $push:{
                "config.home.triplistheaders": { 
                    "key": "spPartnerBranchId", 
                    value: "Business unit"
                },
                "config.trips.triplistheaders":{ 
                    "key": "spPartnerBranchId", 
                    value: "Business unit"
                }, 
                "config.reports.extra_triplistheaders": { 
                    "key": "spPartnerBranchId", 
                    value: "Business unit"
                }
            }
        })

//2a
        db.getCollection("users").updateMany(
            {"config.client":"HIL Limited"},
            {
                $set:{
                    "config.home.triplistheaders.$[elem].key":"destname",
                    "config.trips.triplistheaders.$[elem].key":"destname"
                }
            },{
                arrayFilters: [
                    { "elem.key": "dest_name_input"
                }]
            })

//2b

            db.getCollection("users").updateMany(
                {"config.client":"HIL Limited"},
                {
                    $set:{
                        "config.home.triplistheaders.$[elem].key":"srcname",
                        "config.trips.triplistheaders.$[elem].key":"srcname"
                    }
                },{
                    arrayFilters: [
                        { "elem.key": "src_name_input"
                    }]
                })


            /*
            db.getCollection("users").updateMany(
                    {"config.client": "RK Roadways"},
                    {
                        $set: {
                            "config.trips.newtripinputfields.$[elem].action_name": "check_vahan_data"
                        }
                    },
                    {
                        arrayFilters: [
                            { "elem.key": "truck_number" }]
                        
                    })
            */