db.getCollection("users").updateMany(
        {"config.client":"BAYER"},
        {
            $push:{

                "config.home.triplistheaders":{
                    $each:[    
                                {
                                    "key" : "commodity_code",
                                    "value" : "Commodity Code"
                                },
                                {
                                    "key" : "commodity_entity",
                                    "value" : "Commodity Entity"
                                }
                    ],
                    $position: 22
                },

                "config.trips.triplistheaders":{
                    $each:[    
                                {
                                    "key" : "commodity_code",
                                    "value" : "Commodity Code"
                                },
                                {
                                    "key" : "commodity_entity",
                                    "value" : "Commodity Entity"
                                }
                    ],
                    $position: 23
                },

                "config.reports.triplistheaders":{
                    $each:[    
                                {
                                    "key" : "commodity_code",
                                    "value" : "Commodity Code"
                                },
                                {
                                    "key" : "commodity_entity",
                                    "value" : "Commodity Entity"
                                }
                    ],
                    $position: 24
                },

                "config.history.triplistheaders":{
                    $each:[    
                                {
                                    "key" : "commodity_code",
                                    "value" : "Commodity Code"
                                },
                                {
                                    "key" : "commodity_entity",
                                    "value" : "Commodity Entity"
                                }
                    ],
                    $position: 24
                }

            }
        })