
     db.getCollection("users").updateMany(
            { 'config.client': "Himalaya Production" }, 
            { $pull: { 
                "config.trips.extra_triplistheaders": { "key": "src_gate_in" } 
            } }
        );


        db.getCollection("users").updateMany(
            {"config.client": "Himalaya Production" },
            {
                $push:{
    
                    "config.trips.extra_triplistheaders":{
                        $each:[    
                                {
                                    "key" : "src_gate_in",
                                    "value" : "Source Gate In"
                                }
                        ],
                        $position: 6
                    }
    
                  
    
                }
            })