db.getCollection("users").updateMany(
  { "config.client": "Haier" },
  {
    $push: {
      "config.trips.newtripinputfields.$[elem].values": {
        name: "Lubana",
      },
    },
  },
  {
    arrayFilters: [{ "elem.key": "vendor" }],
  }
);
