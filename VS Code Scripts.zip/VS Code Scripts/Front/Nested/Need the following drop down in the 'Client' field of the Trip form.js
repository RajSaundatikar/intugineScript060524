

        db.getCollection("users").updateMany(
            {'config.client': "Ripplr"},
            {
                    $set:{
                        "config.trips.newtripinputfields.$[element].type": "list", 
                        "config.trips.newtripinputfields.$[element].values": [
                            {
                                "name" : "Solv"
                            },
                            {
                                "name" : "Fasal"
                            }
                        ]
                        }
                
            },
            {
                arrayFilters: [
                                { "element.key": "client_name" }
                ]
            }
        )