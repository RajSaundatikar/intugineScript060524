
    db.getCollection("users").updateMany(
    {'config.client': "Shree Cements"},
    {
        $push:{
            "config.trips.newtripinputfields.$[elem].values" : {
                "name":"Amar Transport Company"
            }
        }
    },
    {
        arrayFilters: [
                        { "elem.key": "vendor" }
        ]
    }
    )