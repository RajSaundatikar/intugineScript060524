
   


 //config.trips.newtripinputfields.2.params

    //Task 1


    db.getCollection("users").updateMany(
        {"config.client": "CAPTAIN FRESH"},
        {
        
            $push:{
                "config.trips.newtripinputfields": {
                    $each:[
                    {
                        key:"source_location_info",
                        placeholder:"Source Location Info",
                        type:"text"
                    },
                    {
                        key:"destination_location_info",
                        placeholder:"Destination Location Info",
                        type:"text"
                    }]
                },
                "config.reports.report_extra_columns":{
                    $each:[
                    {
                        key:"source_location_info",
                        placeholder:"Source Location Info"
                    },
                    {
                        key:"destination_location_info",
                        placeholder:"Destination Location Info"
                    }]
                }
            }
        })



    //Task 2 reports.report_extra_columns

    

        //Task 3

        db.getCollection("users").updateMany(
            {"config.client": "CAPTAIN FRESH"},
            {
                $pull:{
                    "config.trips.newtripinputfields" :{"key": "client_name"}
                }
            })


        