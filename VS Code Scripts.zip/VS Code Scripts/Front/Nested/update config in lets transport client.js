
     db.getCollection("users").updateMany(
    {
        "config.client": "Lets Transport"
    },
    {
        $addToSet:{
            "config.trips.mandatorinputfields": "unique_id"
        }
    })




    db.getCollection("users").updateMany(
        {"config.client": "Lets Transport"},
        {
            $set: {
                "config.trips.newtripinputfields.$[elem].exact_length": 16
            }
        },
        {
            arrayFilters: [
                { "elem.key": "unique_id" }]
            
        })