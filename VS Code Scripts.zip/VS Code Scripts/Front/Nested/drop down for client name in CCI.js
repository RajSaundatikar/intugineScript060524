
    db.getCollection("users").updateMany(
            {'config.client': "CCI Logistics"},
            {
                    $set:{
                        "config.trips.newtripinputfields.$[element].type": "list", 
                        "config.trips.newtripinputfields.$[element].values": [
                            {
                                "name" : "Eastman Solutia"
                            },
                            {
                                "name" : "Evonik"
                            },
                            {
                                "name" : "DOW Chemicals"
                            },
                            {
                                "name" : "Huntsman"
                            },
                            {
                                "name" : "Microbial"
                            },
                            {
                                "name" : "Biostat"
                            },
                            {
                                "name" : "Piditlite"
                            },
                            {
                                "name" : "BASF"
                            },
                            {
                                "name" : "Raj Petro"
                            }
                        ]
                        }
                
            },
            {
                arrayFilters: [
                                { "element.key": "client_name" }
                ]
            }
        )


        