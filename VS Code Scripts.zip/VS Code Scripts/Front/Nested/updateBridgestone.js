const mongo = require("@intugine-technologies/mongodb");
const _ = require('lodash');
const inspect = require('util').inspect;
const Promise = require('bluebird');
let db = null;

const get_db = () => {
    if (db && db.is_connected()) resolve(db);
    else {
        return mongo(
                "mongodb+srv://intugine:NkVPR6VQUEXhyUwYHgQg4hjHspDH5k9a@cluster0.zhjde.mongodb.net/?readPreference=secondaryPreferred",
                "telenitytracking", {
                }
            )
            .then((DB) => {
                db = DB;
                return Promise.resolve(db);
            })
            .catch((e) => {
                return Promise.reject(e);
            });
    }
};

const fs = require('fs');
const data = JSON.parse(fs.readFileSync('./bridgestone.json', 'utf-8'));
// console.log(typeof(data), data['MasterData Destination'])

// const master_users = ['hardik-soni@bridgestone.co.in', 'sachin-modi@bridgestone.co.in', 'ashish-patil@bridgestone.co.in', 'amit-verma@bridgestone.co.in', 'vaibhav-karadiya.ext@bridgestone.co.in', 'madhav-more.ext@bridgestone.co.in', 'akash-nandha@bridgestone.co.in', 'sanket-dangar@bridgestone.co.in', 'pulkitsrivastava@intugine.com'];
const master_users = [];

const update_facilities = (data) => {
    // console.log(data);
    return Promise.map(data, (k, kdx) => {
        const _id = `bridgestone|customerCodeKey|${k.customer_code}`
        console.log(_id);
        const obj = {
            user: 'bridgestone',
            client_client: null,
            key: 'customerCodeKey',
            value: k.customer_code,
            data: {
                orderType: k.orderType,
                facilityName: k.facilityName,
                pincode: k.pincode,
                address: k.address,
                recipientsBy: {
                    quantityType: {
                        PSR: k['PSR'],
                        TBR: k['TBR'],
                        'PSR-TBR MIX': k['PSR-TBR MIX']
                    }
                }
            }
        };
        console.log(inspect(obj, {depth: Infinity}));
        return db.update('customer_master_data', {
            _id
        }, obj, {
            upsert: true
        })
        return Promise.resolve()
    }, {
        concurrency: 1
    });
};

const get_customer_code_data = (data) => {
    return {
        email_recipient_data: {
            'customer_code#quantity_type': data.reduce((acc, curr) => {
                // console.log(curr);
                acc[`${curr['customer_code']}#PSR`] = curr['PSR'];
                acc[`${curr['customer_code']}#TBR`] = curr['TBR'];
                acc[`${curr['customer_code']}#PSR-TBR MIX`] = curr['PSR-TBR MIX'];
                return acc;
            }, {}),
            'customer_code': data.reduce((acc, curr) => {
                // console.log('whatup')
                acc[`${curr['customer_code']}`] = curr['PSR-TBR MIX'].filter(k => curr.exclude_emails.indexOf(k) === -1);
                // console.log(curr.exclude_emails, curr['PSR-TBR MIX'], acc[`${curr['customer_code']}`])
                return acc;
            }, {})
        }
    };
}

const update_notification_emails = (data) => {
    // const obj = data.reduce((acc, curr) => {
    //     // console.log(curr);
    //     acc[`${curr['customer_code']}#PSR`] = curr['PSR'];
    //     acc[`${curr['customer_code']}#TBR`] = curr['TBR'];
    //     acc[`${curr['customer_code']}#PSR-TBR MIX`] = curr['PSR-TBR MIX'];
    //     return acc;
    // }, {})
    const obj = data.reduce((acc, curr) => {
        // console.log(curr);
        // acc[`${curr['customer_code']}#PSR`] = curr['PSR'];
        // acc[`${curr['customer_code']}#TBR`] = curr['TBR'];
        acc[`${curr['customer_code']}`] = curr['PSR-TBR MIX'];
        return acc;
    }, {})
    console.log(obj);
    return db.update('geofence_alerts_temp', {
    	user: 'bridgestone'
    }, {
    	$set: {
            'geofenceAlertData.search_by_key': "customer_code,vendor",
    		'geofenceAlertData.email_recipient_data.customer_code': obj
    	}
    })
    return Promise.resolve();
};

const get_vendor_data = (vendors) => {
    return {
        email_recipient_data: {
            'vendor': vendors.filter(k => k.Column5 && k.Column5 !== 'Short name').reduce((acc, k) => {
                acc[`${k.Column5}`] = _.uniq([].concat(
                    (k.Column12 || "").replace(/\s/g, '').replace(/;/g, ',').split(','),
                    master_users
                )).filter(m => m);
                return acc;
            }, {})
        }
    };
};

const update_vendor_emails = (vendors) => {
    // console.log(vendors)
    const return_data = get_vendor_data(vendors);
    console.log(inspect(return_data, {depth: Infinity}));
    return db.update('geofence_alerts_temp', {
        user: 'bridgestone'
    }, {
        $set: {
            'geofenceAlertData.search_by_key': "customer_code,vendor",
            'geofenceAlertData.email_recipient_data.vendor': return_data['email_recipient_data']['vendor']
        }
    })
    return Promise.resolve();
};

const get_reports_email = (data) => {
    // console.log(data);
    const output = {
        'Indore': data[1]['BS team'].split(',').map(k => k.trim()).filter(k => k),
        'Pune': data[1]['Column5'].split(',').map(k => k.trim()).filter(k => k),
    };
    return output;
    // console.log(output)
};

const update_users = async (data1, data2, data3) => {
    const customer_code_data = get_customer_code_data(data1);
    const vendor_data = get_vendor_data(data2);
    const e_lr_emails = get_reports_email(data3);
    // console.log(customer_code_data.email_recipient_data['customer_code']);
    // console.log(vendor_data.email_recipient_data.vendor);
    // console.log(e_lr_emails['Indore'], e_lr_emails['Pune'])
    // return Promise.resolve()
    await db.update('users', {
        'config.client': 'bridgestone',
        'config.srcname': "Indore",
        'config.lr.lrDownload.prod.emails': {$ne: null}
    }, {
        $addToSet: {
            'config.lr.lrDownload.prod.emails': {
                $each: e_lr_emails['Indore']
            }
        }
    })
    await db.update('users', {
        'config.client': 'bridgestone',
        'config.srcname': "Pune",
        'config.lr.lrDownload.prod.emails': {$ne: null}
    }, {
        $addToSet: {
            'config.lr.lrDownload.prod.emails': {
                $each: e_lr_emails['Pune']
            }
        }
    })
    await db.update('users', {
        'config.client': "bridgestone",
        'config.alerts.alerts_info.search_by': {
            $exists: true
        }
    }, {
        $set: {
            'config.alerts.alerts_info.search_by': {
                'vendor': vendor_data.email_recipient_data.vendor,
                'customer_code': customer_code_data.email_recipient_data['customer_code']
            },
            'config.alerts.halt.recipients.search_by': [
                        "customer_code",
                        "vendor"
                    ],
            'config.alerts.delay.recipients.search_by': [
                        "customer_code",
                        "vendor"
                    ]
        }
    })
};


const get_Destination_master_data = (data) => {
    return data.filter(k => k[' '] && k[' '] !== 'Ship to party').map(k => {
        // console.log(k);
        const obj = {
            customer_code: (isNaN(k[' '].toString()) ? k[' '].toString() : "00" + (k[' '].toString())).trim(),
            orderType: k.Column2.trim(),
            facilityName: k.Column3.replace(/&amp;/g, '&').trim(),
            pincode: k.Column4.toString().trim(),
            address: k.Column7.replace(/\n/g, ',').trim(),
            exclude_emails: _.uniq([].concat(
                (k.Column13 || "").replace(/\s/g, '').replace('ramkumar-k@bridgestone.co.inn-chandrasekaran@bridgestone.co.in', 'ramkumar-k@bridgestone.co.in, n-chandrasekaran@bridgestone.co.in').replace(/;/g, ',').split(','),
                (k.Column16 || "").replace(/\s/g, '').replace('ramkumar-k@bridgestone.co.inn-chandrasekaran@bridgestone.co.in', 'ramkumar-k@bridgestone.co.in, n-chandrasekaran@bridgestone.co.in').replace(/;/g, ',').split(','),
            )).filter(l => l),
            PSR: _.uniq([].concat(
                (k["For all"] || "").replace(/\s/g, '').replace(/;/g, ',').split(','),
                (k["Column9"] || "").replace(/\s/g, '').replace(/;/g, ',').split(','),
                (k['PSR+ TBR'] || "").replace(/\s/g, '').replace(/;/g, ',').split(','),
                (k.Column12 || "").replace(/\s/g, '').replace(/;/g, ',').split(','),
                (k.Column13 || "").replace(/\s/g, '').replace('ramkumar-k@bridgestone.co.inn-chandrasekaran@bridgestone.co.in', 'ramkumar-k@bridgestone.co.in, n-chandrasekaran@bridgestone.co.in').replace(/;/g, ',').split(','),
                master_users
            )).filter(l => l),
            TBR: _.uniq([].concat(
                (k["For all"] || "").replace(/\s/g, '').replace(/;/g, ',').split(','),
                (k["Column9"] || "").replace(/\s/g, '').replace(/;/g, ',').split(','),
                (k.Column14 || "").replace(/\s/g, '').replace(/;/g, ',').split(','),
                (k.Column15 || "").replace(/\s/g, '').replace(/;/g, ',').split(','),
                (k.Column16 || "").replace(/\s/g, '').replace('ramkumar-k@bridgestone.co.inn-chandrasekaran@bridgestone.co.in', 'ramkumar-k@bridgestone.co.in, n-chandrasekaran@bridgestone.co.in').replace(/;/g, ',').split(','),
                master_users
            )).filter(l => l),
        };
        obj['PSR-TBR MIX'] = _.uniq([].concat(
            obj['PSR'],
            obj['TBR']
        )).filter(l => l);
        // console.log(obj);
        return obj;
    });
};

// const get_vendor_master = (data) => {
//     return data.map(k => {
//         // console.log(k);
//         const obj = {
//             vendor_code: k['Column5'].trim()
//         };
//         return obj;
//     }).filter(l => l && l.vendor_code && l.vendor_code !== 'Short name');
// };

(() => {
    get_db()
        .then(async () => {
            const dest_master = get_Destination_master_data(data['MasterData Destination']);
            console.log(dest_master)
           // await update_facilities(dest_master);
            
            // await update_notification_emails(dest_master);
            // await update_vendor_emails(data['TPT master']);
            // await update_users(dest_master, data['TPT master'], data['Reports'])
        })
        .then((r) => {
            console.log(r);
        })
        .catch((e) => {
            console.error(e);
        })
        .finally(async () => {
            await db.close();
        });
})();