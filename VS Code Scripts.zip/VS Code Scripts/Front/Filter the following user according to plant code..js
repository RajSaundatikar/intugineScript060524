

    db.getCollection("users").updateOne(
    {username:"krishan_kumar"},
    {
        $set:{
            "config.filter_trips_by_and":["location_code"],
            "config.location_code":["2022", "2008"]
        }
    })











    
    db.getCollection("users").updateOne(
        {username:"nagendra_singh"},
        {
            $set:{
                "config.filter_trips_by_and":["location_code"],
                "config.location_code":["2022"]       
            }
        })