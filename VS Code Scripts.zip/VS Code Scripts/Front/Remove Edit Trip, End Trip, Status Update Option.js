
    db.getCollection("users").updateMany(
        {username: { $in: ["bannari.logistics@gmail.com", "krishnappakkt@gmail.com", "sreesaitemposervice@gmail.com", "nandhithatransport@gmail.com", "accounts@calibrecarriers.com", "babatransport", "accounts@solaitrans.com", "sumeer3063@gmail.com", "stcourier.singanallur@gmail.com", "rmg.sanjeev@gmail.com", "sagartpt", "pmsreddy7399@gmail.com", "triplektransnew@gmail.com", "srichtpt", "akshay.cp@letstransport.team", "project@teamtrans.in", "rakeshmech13@gmail.com", "anithaviji8@gmail.com", "ceo@sanchetha.com", "mohan@terrago.asia", "greendrivetpt", "smexptpt", "efclogtpt", "premtpt"] } },
        {
            $set:{
                "config.trips.submittedtripoptions.hide_end_trip": true,
                "config.trips.submittedtripoptions.edit":false,
                "config.trips.submittedtripoptions.status_update": false
            }
        })