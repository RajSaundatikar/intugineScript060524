db.getCollection("users").updateMany(
  { "config.client": "John Distelleries" },
  {
    $set: {
      "config.devicemanagment.otheroption.battery_limit": 1,
      "config.devicemanagment.otheroption.time_limit": 2592000000,
    },
  }
);
