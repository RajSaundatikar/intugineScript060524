


//home
    db.getCollection("users").updateMany(
        {"config.client":"Himalaya Test"},
        {
            $push:{
                "config.home.triplistheaders":{
                    $each:[
                        {
                        "key":"spTripId",
                        "value":"Indent Trip ID"
                        }
                    ]
                }
            }
        })


//Trips
db.getCollection("users").updateMany(
    {"config.client":"Himalaya Test"},
    {
        $push:{
            "config.trips.extra_triplistheaders":{
                $each:[
                    {
                    "key":"spTripId",
                    "value":"Indent Trip ID"
                    }
                ]

            }
        }
    })

    
 
    
    //reports
    db.getCollection("users").updateMany(
        {"config.client":"Himalaya Test"},
        {
            $push:{
                "config.reports.extra_triplistheaders":{
                    $each:[
                        {
                        "key":"spTripId",
                        "value":"Indent Trip ID"
                        }
                    ]
                }
            }
        })