// Full navbar

    "navbar_headers_field" :  [
            {
                "title" : "SUMMARY",
                "path" : "/summary",
                "show" : true
            },
            {
                "title" : "HOME",
                "path" : "/home",
                "show" : true
            },
            {
                "title" : "TRIPS",
                "path" : "/trips",
                "show" : true
            },
            {
                "title" : "TIMELINE",
                "path" : "/timeline",
                "show" : true
            },
            {
                "title" : "HISTORY",
                "path" : "/history",
                "show" : true
            },
            {
                "title" : "REPORTS",
                "path" : "/reports",
                "show" : true
            },
            {
                "title" : "Live View",
                "path" : "/all-tracker",
                "show" : true
            },
            {
                "title" : "INDENT",
                "path" : "/indent",
                "show" : true
            },
            {
                "title" : "CONTROL TOWER",
                "path" : "/control-tower",
                "show" : true
            },
            {
                "title" : "Analytics",
                "path" : "/analytics",
                "show" : true
            }
        ]














