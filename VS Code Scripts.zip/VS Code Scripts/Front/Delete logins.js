db.getCollection("users").deleteMany({
  username: {
    $in: [
      "vipin.kumar2@flipkart.com",
      "kishlay.lal@flipkart.com",
      "shailesh.rai@flipkart.com",
      "ashish.gawade@flipkart.com",
      "anjan.banerjee@flipkart.com",
      "saivignesh.s@flipkart.com",
    ],
  },
});
