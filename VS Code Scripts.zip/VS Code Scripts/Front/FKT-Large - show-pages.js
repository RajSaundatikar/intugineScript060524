
   // where show_pages exist 64 
   
   
    db.getCollection("users").updateMany( 
        {"config.client":"FKT-Large", "config.show_pages":["/indent"]},
        {
            $set:{
    
                "config.modules.SUMMARY":{
                    "FRONTEND" : {
                        "NAV" : {
                            "title" : "Summary",
                            "path" : "/summary"
                        },
                        "BASE_URL" : "https://master.dmhqlqdb3g66s.amplifyapp.com/summary"
                    }
                },
        
                "config.navbar_headers" : true,  //1  
        
                "config.home_path" : "/summary", //2 landing page
                
        
                "config.navbar_headers_field" : [ //3 headbar sequence
                    {
                        "title" : "SUMMARY",
                        "path" : "/summary",
                        "show" : true
                    },
                    {
                        "title" : "INDENT",
                        "path" : "/indent",
                        "show" : true
                    }
                    
                ]
        
            },
            $addToSet:{
                "config.modules.OPTED_FOR": "SUMMARY",
                "config.show_pages": "/summary"
            }

        })



        db.getCollection("users").updateMany(
            {"config.client":"FKT-Large", "config.show_pages":["/indent"]},
            {
               
            })
    
            db.getCollection("users").updateMany(
                {"config.client":"FKT-Large", "config.show_pages":["/indent"]},
                {
                    $addToSet:{
                       
                    }
                })
    