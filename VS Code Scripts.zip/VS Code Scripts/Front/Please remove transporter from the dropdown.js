
      db.getCollection("users").updateMany(
            {'config.client': "bridgestone"},
            {
    
    
                $pull:{
                    "config.trips.newtripinputfields.$[elem].values" : {
                       "name": "NSR"
                    }
                }
            },
            {
                arrayFilters: [
                                { "elem.key": "vendor" }
                ]
            }
            )


            db.getCollection("users").updateMany(
                {'config.client': "bridgestone"},
                {
        
        
                    $pull:{
                        "config.trips.newtripinputfields.$[elem].values" : {
                           "name": "PFC"
                        }
                    }
                },
                {
                    arrayFilters: [
                                    { "elem.key": "vendor" }
                    ]
                }
                )






            [
                {
                    "name" : "ACL"
                },
                {
                    "name" : "AGC"
                },
                {
                    "name" : "AHMRL"
                },
                {
                    "name" : "AMC"
                },
                {
                    "name" : "BGRL"
                },
                {
                    "name" : "BRPL"
                },
                {
                    "name" : "CHOUBEY"
                },
                {
                    "name" : "CJDARCL"
                },
                {
                    "name" : "CTC"
                },
                {
                    "name" : "DIPTAB"
                },
                {
                    "name" : "DPFC"
                },
                {
                    "name" : "DPL"
                },
                {
                    "name" : "EXPR"
                },
                {
                    "name" : "FORTIGO"
                },
                {
                    "name" : "GAN"
                },
                {
                    "name" : "MANO"
                },
                {
                    "name" : "MED"
                },
                {
                    "name" : "MEGA"
                },
                {
                    "name" : "MINT"
                },
                {
                    "name" : "MVT"
                },
                {
                    "name" : "NOMT"
                },
                {
                    "name" : "NSR"
                },
                {
                    "name" : "OMKLOG"
                },
                {
                    "name" : "OMT"
                },
                {
                    "name" : "PARN"
                },
                {
                    "name" : "PFC"
                },
                {
                    "name" : "PRCM"
                },
                {
                    "name" : "RANV"
                },
                {
                    "name" : "RITCO"
                },
                {
                    "name" : "SKTL"
                },
                {
                    "name" : "SNDT"
                },
                {
                    "name" : "SSRC"
                },
                {
                    "name" : "STI"
                },
                {
                    "name" : "SVTC"
                },
                {
                    "name" : "VDRC"
                },
                {
                    "name" : "VENT"
                },
                {
                    "name" : "VIL"
                },
                {
                    "name" : "PARK"
                },
                {
                    "name" : "DGFC"
                },
                {
                    "name" : "PARK"
                },
                {
                    "name" : "DGFC"
                },
                {
                    "name" : "NST"
                },
                {
                    "name" : "KLOG"
                },
                {
                    "name" : "SSKT"
                }
            ]
