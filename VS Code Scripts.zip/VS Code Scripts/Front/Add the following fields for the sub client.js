
    db.getCollection("users").updateOne(
        {"config.client":"SRF", "config.client_client":"SRF Outbound"},
        {
            $push:{
                "config.trips.newtripinputfields":{
                    $each:[
                        {
                            "key" : "movement_type",
                            "placeholder" : "Movement Type",
                            "type" : "text"
                        },
                        {
                            "key" : "dispatch_date",
                            "placeholder" : "Dispatch Date",
                            "type" : "date"
                        },
                        {
                            "key" : "source_address",
                            "placeholder" : "Source Address",
                            "type" : "text"
                        },
                        {
                            "key" : "destination_address",
                            "placeholder" : "Ship-To Destination Address",
                            "type" : "text"
                        },
                        {
                            "key" : "destination_email",
                            "placeholder" : "Ship-To Destination Email",
                            "type" : "text"
                        },
                        {
                            "key" : "destination_number",
                            "placeholder" : "Ship-To Destination Contact",
                            "type" : "text"
                        },
                        {
                            "key" : "bill_to_destination_email",
                            "placeholder" : "Bill-To Destination Email",
                            "type" : "text"
                        },
                        {
                            "key" : "bill_to_destination_number",
                            "placeholder" : "Bill-To Destination Contact",
                            "type" : "text"
                        },
                        {
                            "key" : "item_code",
                            "placeholder" : "Item Code",
                            "type" : "text"
                        },
                        {
                            "key" : "customer_type",
                            "placeholder" : "Customer Type",
                            "type" : "text"
                        }
                    ]
                }
            }
        })
