
     db.getCollection("users").updateOne(
        { username:"ritcovapi@ritcologistics.com" },
        {
            $set:{
                
                "config.trips.submittedtripoptions.hide_end_trip": true,
               
                "config.trips.submittedtripoptions.hide_start_trip": true
                
            }
        })




         //hide new trip
        //"config.trips.otheroption.hide_newtrip_button":true

        //hide start trip button
        //config.trips.submittedtripoptions.hide_start_trip