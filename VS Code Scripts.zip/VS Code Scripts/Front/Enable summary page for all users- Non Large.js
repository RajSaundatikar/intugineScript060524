
db.getCollection("users").updateMany(
    { "username": {
        $in:[
        "flipkart_rajkot_tc_fk",
        "flipkart_flipkart nl iwit",
        "flipkart_maharashtra_fc",
        "flipkart_vijayawada_fc",
        "flipkart_hubli_fc",
        "flipkart_anjaneya_fc",
        "flipkart_malur_fc"] }
    },
    {
        $set:{
    
            "config.modules.SUMMARY":{
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Summary",
                        "path" : "/summary"
                    },
                    "BASE_URL" : "https://master.dmhqlqdb3g66s.amplifyapp.com/summary"
                }
            },
    
            "config.navbar_headers" : true,  //1
    
            "config.home_path" : "/summary", //2
            
    
            "config.navbar_headers_field" : [ //3
                {
                    "title" : "SUMMARY",
                    "path" : "/summary",
                    "show" : true
                },
                {
                    "title" : "HOME",
                    "path" : "/home",
                    "show" : true
                },
                {
                    "title" : "TRIPS",
                    "path" : "/trips",
                    "show" : true
                },
                {
                    "title" : "TIMELINE",
                    "path" : "/timeline",
                    "show" : true
                },
                {
                    "title" : "HISTORY",
                    "path" : "/history",
                    "show" : true
                },
               
                {
                    "title" : "Live View",
                    "path" : "/all-tracker",
                    "show" : true
                },
                {
                    "title" : "INDENT",
                    "path" : "/indent",
                    "show" : true
                }
                
            ]
    
    
        },
        
            $push:{
                "config.modules.OPTED_FOR": "SUMMARY",
                "config.show_pages": "/summary"
            }
        
    })






    

    db.getCollection("users").find({ 
        "username": {
            $in:["flipkart_durgapurtchub_dgp",
            "flipkart_rajkot_tc_fk",
            "flipkart_flipkart nl iwit",
            "flipkart_maharashtra_fc",
            "flipkart_vijayawada_fc",
            "flipkart_hubli_fc",
            "flipkart_anjaneya_fc",
            "flipkart_malur_fc"] },

        "config.modules.SUMMARY":{$exists:true}
    })


    //
    "show_pages" : [
        "/home",
        "/trips",
        "/timeline",
        "/history",
        "/indent",
        "/all-tracker"
    ]

    //
    //config.show_pages