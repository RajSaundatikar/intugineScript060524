
    db.getCollection("users").updateOne(
        {username:"himalaya_btl"},
        {
            $set:{
                "config.modules.INDENT_MANAGEMENT.FRONTEND.creds.token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzX2lkIjoiNjQ3ODQ5NzBkZjliNmJjYjMzN2I1MzRjIiwidV9pZCI6MzY0NzgsImJfaWQiOjM1OTkwLCJ0eXBlIjoiY2FycmllciIsImlhdCI6MTY4NTYwNDcyMCwiZXhwIjoxNzE3MTQwNzIwLCJpc3MiOiJzdXBlcnByb2N1cmUtc3NvIn0.FghD49kp_FuyVa37rFs7mXxZTEx9k2JXNq5-Kdi3dbZg9jZevZbrRtZqcrvH4pqQNDehQTTeRXwKDJQ2O9o4juOmJmqhYKai3177YMCfV9Si7UI8opnsyBZWhbzGErM6dWkmBHuEMNOG2ICtcUJmr_27z1SVi-YAiEYNwCovSjo"
            }
        })


        

        db.getCollection("users").updateOne(
            {username:"himalaya_uma"},
            {
                $set:{
                    "config.modules.INDENT_MANAGEMENT.FRONTEND.creds.token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzX2lkIjoiNjQ3OWU4YmNkZjliNmJjYjMzN2I4MGVjIiwidV9pZCI6MzY1MDIsImJfaWQiOjM2MDE0LCJ0eXBlIjoiY2FycmllciIsImlhdCI6MTY4NTcxMTAzNiwiZXhwIjoxNzE3MjQ3MDM2LCJpc3MiOiJzdXBlcnByb2N1cmUtc3NvIn0.XXxSkOyxYSXEjIO4-yhKXtwY0hMwKkxXxFqgqWtucpniFUCTCEivE6hV_fjdGpg58EXdzd3BU5G3p8sS55CG5SO-UClfX44AtNZpfviySXQpb6JTJvnzfjvsoG8JKjAdyUrzhzPiXfymn_ldbfmUMFcnS1yjc8d23zVv3hh6Vuo"
                }
            })



            