
      db.getCollection("users").updateOne(
        {username: "sisecam_gate" },
        {
            $set:{
                "config.trips.submittedtripoptions.hide_end_trip": true,
                "config.trips.submittedtripoptions.edit":false
            }
        })