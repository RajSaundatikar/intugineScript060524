//config.trips.otheroption.bulk_part_b:true


//Bulk upload for e-way bill update - config task



db.getCollection("users").updateMany(
    {"config.client": "FKT EWAYBILL"},
{
    $set:{
        "config.trips.otheroption.bulk_part_b": true
    }
})