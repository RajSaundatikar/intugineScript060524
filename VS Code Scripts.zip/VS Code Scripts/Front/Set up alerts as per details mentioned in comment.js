  

        //Halt Alerts

        db.getCollection("users").updateMany(
            {"config.client" : "RAPID TRANSPORT CORPORATION"},
            {
                $set:
                {
                    "config.alerts.halt": {
                        "recipients": {
                            "internal": [
                                "support@intugine.com"
                            ],
                            "client": ["rehan@rapidtransport.net"]
            
                        },
                        "haltParams": [{
                            "durationThreshold": 7200000, 
                            "sendOncePerHalt": true,
                            "recipients": [
            
                            ]
                        }]
                    }
                }
            
            })
        
        
            //ETA Breach and Geofence Alerts
        
            db.getCollection("geofence_alerts_temp").insertOne(
                {
                "user" : "RAPID TRANSPORT CORPORATION",
                "geofenceAlertData" : {
                "src": 5000,
                "dest": 5000,
                "disableMailAlerts" : false,
                "displayName" : "RAPID TRANSPORT CORPORATION",
                "alert_emails" : ["rehan@rapidtransport.net"]
                }
        
                })
    
    
    
                // db.getCollection("users").updateMany(
                //     { "config.client": "Wowtruck Technologies"},
                //     {
                //       $set: {
                //         "config.reachParams.geofence": 5000,
                //         "config.tracking.geofence_radius.drop": 5000,
                //       },
                //     }
                //   );
    
    
    
    
    
                  //mis
    
    {
        "action": "TRIGGER_MIS_REPORT",
        "user": "RAPID TRANSPORT CORPORATION",
        "query": {
          "client_client": null
        },
        "cron_expression": "30 4 * * *",
        "config": {
          "recipients": {"to" : ["rehan@rapidtransport.net"] }
        }
      }
    
    
      
    
    //   //compliance
    
    //   {
    //     "action": "TRIGGER_COMPLIANCE_REPORT",
    //     "user": "ARRIVAE",
    //     "query": {
    //       "client_client": null
    //     },
    //     "cron_expression": "30 4 * * *",
    //     "config": {
    //       "displayNames": {
    //         "client": "ARRIVAE"
    //       },
    //       "recipients": ["sujitdey@arrivae.com", "manalishirke@arrivae.com", "sumittambe@arrivae.com", "sumittambe@arrivae.com"]
    //     }
    //   }