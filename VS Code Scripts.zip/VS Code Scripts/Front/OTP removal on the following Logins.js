
//     For my reference 
// To set
// "config.otp_auth": true and create  email:"give emailid" outside config

// To remove 
// remove "config.otp_auth": true 

    
    db.getCollection("users").updateMany(
        {
            "username":{ $in:["lh_bamnoli@flipkart.com", "flipkart_durgapurtchub_dgp", "flipkart_asansoltchub_asl", "flipkart_rajkot_tc_fk", "flipkart_flipkart nl iwit", "flipkart_maharashtra_fc", "flipkart_vijayawada_fc", "flipkart_hubli_fc", "flipkart_anjaneya_fc", "flipkart_malur_fc", "flipkart_bhiwandi_fc", "flipkart_ahmedabad_fc", "flipkart_mumbai_fc", "flipkart_patna_fc", "flipkart_raipur_fc", "flipkart_haringhata_fc", "flipkart_hyderabad_fc", "flipkart_coimbatore_fc", "flipkart_chennai_fc", "flipkart_indore_fc", "flipkart_bhuneshwar_fc", "flipkart_uluberia_fc", "flipkart_ludhiana_fc", "flipkart_binola_fc", "flipkart_siliguri_fc", "flipkart_kolkata_fc", "flipkart_jaipur_fc", "flipkart_sanpka_fc", "flipkart_lucknow_fc", "flipkart_farrukhnagar_fc", "flipkart_hassan", "flipkart_vtc", "flipkart_anj", "flipkart_blr", "flipkart_dlx", "flipkart_bnl", "flipkart_vni", "flipkart_luh", "flipkart_sil", "flipkart_vij", "flipkart_hub", "flipkart_cok", "flipkart_pnq", "flipkart_pat_bts", "flipkart_jkd", "flipkart_ind", "flipkart_cut", "flipkart_cjb", "flipkart_chg", "flipkart_abd", "flipkart_guw", "flipkart_csk", "flipkart_lko", "flipkart_med", "flipkart_hyp", "flipkart_jai", "flipkart_stv", "flipkart_ykb", "flipkart_jks", "flipkart_frk", "flipkart_ggn", "flipkart_sai", "flipkart_hrn", "flipkart_snk", "flipkart_ulb", "flipkart_sid", "flipkart_myntra_wtf_ml", "flipkart_myntra_pat_ml", "flipkart_myntra_ngp_ml", "flipkart_myntra_myq_ml", "flipkart_myntra_mum_ml", "flipkart_myntra_map_ml", "flipkart_myntra_lko_ml", "flipkart_myntra_kok_ml", "flipkart_myntra_kol-st_ml", "flipkart_myntra_jai_ml", "flipkart_myntra_idr_ml", "flipkart_myntra_hyd_ml", "flipkart_myntra_gau_ml", "flipkart_myntra_kpsth_ml", "flipkart_myntra_pnq_ml", "flipkart_myntra_ggn_ml", "flipkart_myntra_rai_ml", "flipkart_myntra_rnc_ml", "flipkart_myntra_bpr_ml", "flipkart_myntra_sil_ml", "flipkart_myntra_srt_ml", "flipkart_myntra_bbn_ml", "flipkart_myntra_cjb_ml", "flipkart_myntra_cok_ml", "flipkart_myntra_chn_ml", "flipkart_myntra_cnd_ml", "flipkart_myntra_nwwth_ml", "flipkart_myntra_napth_ml", "flipkart_myntra_ahd_ml"] }
        },
        {
            $unset:{
                "config.otp_auth": ""
                
            }
        })


       