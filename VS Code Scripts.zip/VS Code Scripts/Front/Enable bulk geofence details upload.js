
    db.getCollection("users").updateOne(
        {username: "nikhil.singh2" },
        {
            $set:{

                "config.trips.otheroption.bulk_geofence_upload": true
            }
        })
