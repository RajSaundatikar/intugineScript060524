
    db.getCollection("users").updateMany(
    {"username":"ghcl_pilot"},
    {
        $set:{
            "config.reports.report_extra_columns":[{
                "key" : "eta_days",
                "placeholder" : "SLA"
            }]
        },

        $push:{
            "config.reports.extra_triplistheaders":{
                "key" : "eta_days",
                "value" : "SLA"
            }
        }
                
    })


    db.getCollection("users").updateMany(
        {"config.client":"GHCL"},
        {
            $set:{
                "config.reports.report_extra_columns":[{
                    "key" : "eta_days",
                    "placeholder" : "SLA"
                }]
            },
    
            $addToSet:{
                "config.reports.extra_triplistheaders":{
                    "key" : "eta_days",
                    "value" : "SLA"
                }
            }
                    
        })