
         db.getCollection("users").updateOne(
    {username:"borse.mayur@mahindra.com"},
    {
        $set:{
            "config.filter_trips_by_and":["leg", "srcname"],
            "config.leg": ["Leg 1"],
            "config.srcname": ["Nashik Plant", "Mihirvani Yard"]
        }
    })


    db.getCollection("users").updateOne(
        {username:"daware.dhiraj@mahindra.com"},
        {
            $set:{
                "config.filter_trips_by_and":["leg", "srcname"],
                "config.leg": ["Leg 1"],
                "config.srcname": ["Chakan Plant"]
            }
        })

        db.getCollection("users").updateOne(
            {username:"singh.upendra2@mahindra.com"},
            {
                $set:{
                    "config.filter_trips_by_and":["leg", "srcname"],
                    "config.leg": ["Leg 1"],
                    "config.srcname": ["Kandivali Plant"]
                }
            })

            db.getCollection("users").updateOne(
                {username:"kumar.vijay1@mahindra.com"},
                {
                    $set:{
                        "config.filter_trips_by_and":["leg", "srcname"],
                        "config.leg": ["Leg 1"],
                        "config.srcname": ["Haridwar Plant", "Haridwar Yard"]
                    }
                })