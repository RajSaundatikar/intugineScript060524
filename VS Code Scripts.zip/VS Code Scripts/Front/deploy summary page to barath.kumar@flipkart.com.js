
db.getCollection("users").updateOne(
{ "username": {
    $in:["barath.kumar@flipkart.com"] }
},
{
    $set:{

        "config.modules.SUMMARY":{
            "FRONTEND" : {
                "NAV" : {
                    "title" : "Summary",
                    "path" : "/summary"
                },
                "BASE_URL" : "https://master.dmhqlqdb3g66s.amplifyapp.com/summary"
            }
        },

        "config.navbar_headers" : true,  //1

        "config.home_path" : "/summary", //2
        

        "config.navbar_headers_field" : [ //3
            {
                "title" : "SUMMARY",
                "path" : "/summary",
                "show" : true
            },
            {
                "title" : "HOME",
                "path" : "/home",
                "show" : true
            },
            {
                "title" : "TRIPS",
                "path" : "/trips",
                "show" : true
            },
            {
                "title" : "TIMELINE",
                "path" : "/timeline",
                "show" : true
            },
            {
                "title" : "HISTORY",
                "path" : "/history",
                "show" : true
            },
            {
                "title" : "REPORTS",
                "path" : "/reports",
                "show" : true
            },
            {
                "title" : "Live View",
                "path" : "/all-tracker",
                "show" : true
            },
            {
                "title" : "INDENT",
                "path" : "/indent",
                "show" : true
            },
            {
                "title" : "CONTROL TOWER",
                "path" : "/control-tower",
                "show" : true
            },
            {
                "title" : "Analytics",
                "path" : "/analytics",
                "show" : true
            }
        ]


    },
    
        $push:{
            "config.modules.OPTED_FOR": "SUMMARY"
        }
    
})








// ["arora.gaurav@flipkart.com", "jagdish.singh@flipkart.com", "rashmi.shah@flipkart.com", "karan.chaware@flipkart.com", "akash.gavale@flipkart.com", "sawardekar.umesh@flipkart.com", "lh_bamnoli@flipkart.com", "sriparna.b@flipkart.com", "k.varun@flipkart.com", "sumit.sharma1@flipkart.com", "kk.vinoth@flipkart.com", "priyanshu.s1@flipkart.com", "pranav.vishal.vc@flipkart.com"]



db.getCollection("users").updateOne(
    { "username": {
        $in:["barath.kumar@flipkart.com"] }
    },
    {
        $set:{
            "config.modules.SUMMARY":{
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Summary",
                        "path" : "/summary"
                    },
                    "BASE_URL" : "https://master.dmhqlqdb3g66s.amplifyapp.com/summary"
                }
            }
            
        }
    })





"config.modules.SUMMARY":{
    "FRONTEND" : {
        "NAV" : {
            "title" : "Summary",
            "path" : "/summary"
        },
        "BASE_URL" : "https://master.dmhqlqdb3g66s.amplifyapp.com/summary"
    }
}
