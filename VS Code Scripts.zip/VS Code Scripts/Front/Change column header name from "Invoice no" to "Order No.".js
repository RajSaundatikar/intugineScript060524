
    db.getCollection("users").updateMany(
    {"config.client":"Kuehne + Nagel International AG_test"}, 
    {
        $set:{
            "config.trips.newtripinputfields.$[elem].params.$[elem1]":
            {
                "key":"invoice",
                "placeholder" : "Order No."
            }
        }
    },
    {
        arrayFilters: [
            { "elem.key": "drops" },
            { "elem1.key": "invoice" }
        ]
    })


    