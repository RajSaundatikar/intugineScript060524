

 db.getCollection("users").updateOne(
        {"username":"support@actrans.in"},
        {
            $set:{
                "config.modules":{}
            }
        })
        
//

 db.getCollection("users").updateOne(
            {"username":"nitind@actrans.in"},
            {
                $set:{
                    "config.modules":{}
                }
            })
