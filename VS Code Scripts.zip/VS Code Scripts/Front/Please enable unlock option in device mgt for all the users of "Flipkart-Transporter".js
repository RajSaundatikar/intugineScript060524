db.getCollection("users").updateMany(
        {"config.client": "Flipkart-Transporter"},
        {
            $set:{
                "config.trips.otheroption.device_unlock_access": true
            }
        }) 