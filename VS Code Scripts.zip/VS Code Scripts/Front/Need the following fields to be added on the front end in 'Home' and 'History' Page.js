
    "Haier"


    //home
    db.getCollection("users").updateMany(
        {"config.client":"Haier"},
        {
            $push:{
                "config.home.triplistheaders":{
                    $each:[
                        {
                            "key":"vendor",
                            "value":"Transporter Name"
                        },
                        {
                            "key": "last_city",
                            "value": "Current Location"
                        },
                        {
                            "key": "distance_travelled",
                            "value": "Distance Travelled (km)"
                        },
                        {
                            "key": "distance_remained",
                            "value": "Distance Remaining (km)"
                        }
                    ]
                }
            }
        })


         //history
    db.getCollection("users").updateMany(
        {"config.client":"Haier"},
        {
            $set:{
                "config.history":{
                    "extra_triplistheaders":[
                        {
                            "key":"vendor",
                            "value":"Transporter Name"
                        },
                        {
                            "key": "start_time",
                            "value": "Start Time"
                        },
                        {
                            "key": "distance_travelled",
                            "value": "Distance Travelled (km)"
                        },
                        {
                            "key": "endTime",
                            "value": "Trip End Date	"
                        },
                        {
                            "key": "last_address",
                            "value": "Trip End Place"
                        }
                ]
                }
            }
        })