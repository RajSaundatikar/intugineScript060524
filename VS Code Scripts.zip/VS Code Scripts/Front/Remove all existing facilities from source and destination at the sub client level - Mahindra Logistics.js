
     db.getCollection("users").updateMany(
        { "config.client":"mahindra","config.client_client" : "Mahindra Logistics Bussiness Unit 1"},
        {
            $unset:{
                "config.facilities": ""
            }
        }
        )

        //Removed from
        db.getCollection("facilities").deleteOne({ "_id" : ObjectId("64c0da177d2e1c0008a5fcb4")})