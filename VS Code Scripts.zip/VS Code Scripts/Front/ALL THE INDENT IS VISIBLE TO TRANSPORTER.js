
    db.getCollection("users").find(
        {
            "username": { $in: ["deeparoadlines@gmail.com", "enoshlog2020@gmail.com", "abhishek@chaurasiagroup.com", "saisuperservice2014@gmail.com", "sajjankumarbansal@gmail.com", "maharaja.nanda2020@gmail.com", "orcpl97khd@gmail.com", "shivaroadways@yahoo.com", "sushant1973@rediffmail.com", "sunakar.swaincfpl@gmail.com", "parthagogoi66@yahoo.in", "anjitrans3880@gmail.com", "sales@maalathilogistics.com", "maalathilogistics@gmail.com", "cosmo", "chittaranjannath1982@gmail.com", "svslogisticservices@gmail.com", "vidarbharoadcarriers@gmail.com", "cargohyd@yahoo.in", "vikash.chandra@ucils.in", "muruganroadlines9@gmail.com", "rrctransporthyd@yahoo.com", "sandeep.mohapatra@efclogistics.com", "bangloregujratroadways@gmail.com", "hydsrw@gmail.com", "newsainiroadlines@gmail.com", "arjunreddy.avuthu@gmail.com", "harshfreightcarrier111@gmail.com", "fleetoperations@cosmocarrying.com"] },

            "config.navbar_headers_field":{$exists:true} 
            
     }
        )

//pulled below Object and pulled from opted_for
        {
            "title" : "INDENT",
            "path" : "/indent",
            "show" : true
        },


        "config.modules.INDENT_MANAGEMENT":{$exists:true} 


        