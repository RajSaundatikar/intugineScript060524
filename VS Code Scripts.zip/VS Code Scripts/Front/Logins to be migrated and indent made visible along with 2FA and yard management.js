
    db.getCollection("users").updateMany(
        { "username": { $in: ["varun.shetake@flipkart.com", "siddesh.n.vc@flipkartcom", "vishnu_prabha@flipkart.com", "deepak.ss@flipkart.com", "shrutee.dhodapkar@flipkart.com"] } },
        {
            $set: {
                "config.client" : "FKT_Main"
            }
        })


       
            db.getCollection("users").updateOne(
                {username: "deepak.ss@flipkart.com" },
                {
                      $set:{
        
                        "config.modules" : {
                            "OPTED_FOR" : [
                                "INDENT_MANAGEMENT"     
                            ],
                            "INDENT_MANAGEMENT" : {
                                "FRONTEND" : {
                                    "NAV" : {
                                        "title" : "Indent",
                                        "path" : "/indent"
                                    },
                                    "BASE_URL" : "https://app2.superprocure.com/loadBoard",
                                    "creds" : {
                                        "URL_KEY" : "token",
                                        "token" : "NzkwNDM6OEYzMEE0NDFENkM0QkQwNjJGMTVCRDU4NTMwNEU5Rjc="
                                    }
                                }
                            }
                
                        }
        
                    }
                })


                db.getCollection("users").updateOne(
                    { 
                    "username": "deepak.ss@flipkart.com",   
                    },
                    {
                        $addToSet:{
                            "config.modules.OPTED_FOR": "YARD_MANAGEMENT"
                              
                        },
                
                        $set:{
                            "config.modules.YARD_MANAGEMENT":{
                                "FRONTEND" : {
                                    "NAV" : {
                                        "title" : "Yard Management",
                                        "path" : "/yard"
                                    },
                                    "BASE_URL" : "https://dq2sjc9nuei5i.cloudfront.net/"
                                }
                            }
                        }
                    }
                    )



                    db.getCollection("users").updateOne(
                        {
                            "username": "deepak.ss@flipkart.com"
                        },
                        {
                            $set:{
                                "config.otp_auth": true,
                                "email": "deepak.ss@flipkart.com"
                            }
                        })



                        //


     db.getCollection("users").updateOne(
        {username: "shrutee.dhodapkar@flipkart.com" },
        {
              $set:{

                "config.modules" : {
                    "OPTED_FOR" : [
                        "INDENT_MANAGEMENT"     
                    ],
                    "INDENT_MANAGEMENT" : {
                        "FRONTEND" : {
                            "NAV" : {
                                "title" : "Indent",
                                "path" : "/indent"
                            },
                            "BASE_URL" : "https://app2.superprocure.com/loadBoard",
                            "creds" : {
                                "URL_KEY" : "token",
                                "token" : "NzkxNjc6NjE3MEFERTJEQTE5MENCNTExODRGM0MzNTBCNzk0MzE="
                            }
                        }
                    }
        
                }

            }
        })


        db.getCollection("users").updateOne(
            { 
            "username": "shrutee.dhodapkar@flipkart.com",   
            },
            {
                $addToSet:{
                    "config.modules.OPTED_FOR": "YARD_MANAGEMENT"
                      
                },
        
                $set:{
                    "config.modules.YARD_MANAGEMENT":{
                        "FRONTEND" : {
                            "NAV" : {
                                "title" : "Yard Management",
                                "path" : "/yard"
                            },
                            "BASE_URL" : "https://dq2sjc9nuei5i.cloudfront.net/"
                        }
                    }
                }
            }
            )



            db.getCollection("users").updateOne(
                {
                    "username": "shrutee.dhodapkar@flipkart.com"
                },
                {
                    $set:{
                        "config.otp_auth": true,
                        "email": "shrutee.dhodapkar@flipkart.com"
                    }
                })
