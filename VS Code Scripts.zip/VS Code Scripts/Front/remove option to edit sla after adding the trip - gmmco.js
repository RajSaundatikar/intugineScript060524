
    //config.trips.otheroption.disable_editrip_fields


     db.getCollection("users").updateMany(
        {"config.client":"GMMCO INDIA"},
        {
            $set:{
                "config.trips.otheroption.disable_editrip_fields": ["eta_days"]
            }
        }) 