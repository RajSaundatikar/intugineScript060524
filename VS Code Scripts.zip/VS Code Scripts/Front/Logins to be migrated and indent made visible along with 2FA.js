//"manimaran.k@flipkart.com" exception
     db.getCollection("users").updateMany(
        { "username": { $in: ["sumohan.d@flipkart.com", "manoj.kg@flipkart.com", "vijay.gaikwad@flipkart.com", "gauravkumar.dubey@flipkart.com",
        "arvind.anand@flipkart.com", "momin.roofi@flipkart.com", "kapil.rohit@flipkart.com", "gulamgaus.momin@flipkart.com", "hemant.sunil@flipkart.com", "vhora.farukbhai@flipkart.com", 
        "sohilsha.fakir@flipkart.com", "kumar.kanhaiya@flipkart.com", "mudshirhusen.sayyed@flipkart.com", "hitendra.kumar@flipkart.com", "mayur.getme@flipkart.com", "g.rajan@flipkart.com", 
        "balaji.nv@flipkart.com", "rajesh.p@flipkart.com", "lakshman.naik@flipkart.com", "vishnu.prabha@flipkart.com", "vignesh.venkadesan@flipkart.com", "rajadurai.m@flipkart.com", 
        "mohamed.aqyar@flipkart.com", "manimaran.k@flipkart.com", "amaresh.s@flipkart.com"] } },
        {
            $set: {
                "config.client" : "FKT_Main"
            }
        })




        db.getCollection("users").updateMany(
            {username: { $in: ["sumohan.d@flipkart.com", "manoj.kg@flipkart.com", "vijay.gaikwad@flipkart.com", "gauravkumar.dubey@flipkart.com",
        "arvind.anand@flipkart.com", "momin.roofi@flipkart.com", "kapil.rohit@flipkart.com", "gulamgaus.momin@flipkart.com", "hemant.sunil@flipkart.com", "vhora.farukbhai@flipkart.com", 
        "sohilsha.fakir@flipkart.com", "kumar.kanhaiya@flipkart.com", "mudshirhusen.sayyed@flipkart.com", "hitendra.kumar@flipkart.com", "mayur.getme@flipkart.com", "g.rajan@flipkart.com", 
        "balaji.nv@flipkart.com", "rajesh.p@flipkart.com", "lakshman.naik@flipkart.com", "vishnu.prabha@flipkart.com", "vignesh.venkadesan@flipkart.com", "rajadurai.m@flipkart.com", 
        "mohamed.aqyar@flipkart.com", "amaresh.s@flipkart.com"] }, "config.modules.INDENT_MANAGEMENT":{$exists:false}},
        {
            $set:{

                "config.modules" : {
                    "OPTED_FOR" : [
                        "INDENT_MANAGEMENT"
                        
                        
                    ],
                    "INDENT_MANAGEMENT" : {
                        "FRONTEND" : {
                            "NAV" : {
                                "title" : "Indent",
                                "path" : "/indent"
                            },
                            "BASE_URL" : "https://app2.superprocure.com/loadBoard",
                            "creds" : {
                                "URL_KEY" : "token",
                                "token" : ""
                            }
                        }
                    }
        
                }

            }
        }
        )