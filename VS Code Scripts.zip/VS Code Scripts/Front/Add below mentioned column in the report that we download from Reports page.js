
    


     db.getCollection("users").updateMany(
            {
                "config.client": "FKT EWAYBILL"
            },
            {
                $set:{

                    "config.reports.report_extra_columns":[
                        {
                        "key": "_id",
                        "placeholder": "Intugine ID"
                        },
                        {
                        "key": "trip_id",
                        "placeholder": "Fareye ID"
                        }]
                }
            })