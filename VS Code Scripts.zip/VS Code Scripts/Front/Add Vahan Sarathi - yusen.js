

    db.getCollection("users").updateMany(
        {"config.client":"Yusen Logistics"},
            {
                $set:{
                        "config.trips.otheroption.show_rcdl_details": true      
                    },
                $push:{
                    "config.trips.newtripinputfields":{
                        $each:[
                                {
                                    "key" : "dl_number",
                                    "placeholder" : "Driving Licence Number",
                                    "type" : "text",
                                    "action_name" : "check_dl_data"
                                },
                                {
                                    "key" : "driver_dob",
                                    "placeholder" : "Driver DOB",
                                    "type" : "date",
                                    "action_name" : "check_dl_data"
                                }
                            ]
                        }
                    }
                })


                db.getCollection("users").updateMany(
                    { "config.client":"Yusen Logistics" },
                    {
                        $set: {
                            "config.trips.newtripinputfields.$[elem].action_name": "check_vahan_data"
                        }
                    },
                    {
                        arrayFilters: [
                            { "elem.key": "truck_number" }]
                        
                    })