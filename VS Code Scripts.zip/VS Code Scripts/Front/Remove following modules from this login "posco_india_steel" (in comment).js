
//Remove following modules from this login "posco_india_steel" (in comment)

/*
HOME
TRIPS
HISTORY 
REPORTS
*/

Find username and remove from "show_pages".

"show_pages" : [
    "/epod"
]

Only keep /epod