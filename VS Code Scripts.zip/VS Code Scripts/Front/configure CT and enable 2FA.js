

    db.getCollection("users").updateOne(
        {
            "username":"pooja.sharma@flipkart.com"
        },
        {
            $set:{
                "config.otp_auth": true,
                "email":"pooja.sharma@flipkart.com"
            }
        })