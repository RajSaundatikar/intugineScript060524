
    //config.trips.submittedtripoptions.hide_end_trip

    db.getCollection("users").updateMany(
    {
        "username":
    {   $in:["sk.tahir@leapindia.net", "harshit.bhadauria@leapindia.net", "jaspreet.singh@leapindia.net", "praveen.kumar@leapindia.net", "yogesh.awate@leapindia.net", "prabhat.tiwari@leapindia.net", "sudhirkumar.samantaray@leapindia.net", "niranjan.jena@leapindia.net", "umashankar.c@leapindia.net", "ashish.manikpuri@leapindia.net", "sushil.shrivastava@leapindia.net", "ashish.yadav@leapindia.net", "gaurav.pant@leapindia.net", "muktimanas.mohanty@leapindia.net", "ramachandran.s@leapindia.net", "karthik.j@leapindia.net", "naresh.kumar@leapindia.net", "rajendra.shetty@leapindia.net", "manas.agrawal@leapindia.net", "santosh.rawte@leapindia.net", "sanket.hole@leapindia.net", "hiralal.sahani@leapindia.net", "sandipan.ghosh@leapindia.net"]
    }
    },
    {
        $set:{
            "config.trips.submittedtripoptions.hide_end_trip":false
        }
    })

