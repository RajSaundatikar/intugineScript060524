
    

    db.getCollection("users").updateMany(
        {'config.client': "CCI Logistics"},
        {
            $push:{
                "config.reports.report_extra_columns":{
                    "key" : "submitted_by",
                    "placeholder" : "Submitted By"
                }
            }
        })



        