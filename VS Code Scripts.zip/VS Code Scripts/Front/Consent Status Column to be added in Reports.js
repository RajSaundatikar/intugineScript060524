



    db.getCollection("users").updateMany(
        {"config.client":"Himalaya Production"},
        {
            $push:{
                
                "config.reports.report_header": {
                    "key": "consent_status",
                    "value": "Consent Status"
                   
                    }
            }
        })

        db.getCollection("users").updateMany(
            {"config.client":"Himalaya Production"},
            {
                $push:{
                    "config.reports.report_header":{
                        $each:[    
                                    {
                                        "key" : "consent_status",
                                        "value" : "Consent Status"
                                    }
                        ],
                        $position: 2
                    }
                }
            })