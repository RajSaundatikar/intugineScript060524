
       db.getCollection("users").updateMany(
        {"config.client":"mahindra", "config.client_client":"Mahindra Logistics Bussiness Unit 1"},
        {
            $set:{
                "config.trips.otheroption.fixed_drops_keys" : ["srcname","leg","destname","vehicle_mode"]
            }
        })