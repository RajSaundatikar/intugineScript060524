
      db.getCollection("users").updateOne(
        {
            "username":"sukants@flipkart.com"
        },
        {
            $set:{
                "config.otp_auth": true,
                "email":"sukants@flipkart.com"
            }
        })