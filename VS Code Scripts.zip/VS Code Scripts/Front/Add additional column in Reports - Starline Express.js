
        db.getCollection("users").updateMany(
            {
                "config.client": "Starline Express"
            },{
                $set:{
                    "config.reports.report_extra_columns":[{
                        "key":"submitted_by",
                        "placeholder":" Trip Submitted By"
                    }]
                }
            })






            // If required

            // db.getCollection("users").updateMany(
            //     {
            //         "config.client": "Starline Express"
            //     },{
            //         $set:{
            //             "config.reports.extra_triplistheaders":[{
            //                 "key":"submitted_by",
            //                 "value":" Trip Submitted By"
            //             }]
            //         }
            //     })