db.getCollection("users").updateMany(
  {
    "config.client": "PBL Transport",
    "config.reports.report_extra_columns": { $exists: true },
  },
  {
    $push: {
      "config.reports.report_extra_columns": {
        $each: [
          {
            key: "submitted_by",
            placeholder: "Submitted By",
          },
          {
            key: "started_by",
            placeholder: "Started By",
          },
        ],
      },
    },
  }
);
