
     db.getCollection("users").updateOne(
    {username:"rahiman.abdul@hil.in"},
    {
        $set:{
            "config.filter_trips_by":["location_code"],
            "config.location_code": ["2009", "2032"]
        }
    })