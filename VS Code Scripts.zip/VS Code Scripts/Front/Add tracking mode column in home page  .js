
    db.getCollection("users").updateMany(
        {"config.client":"VEGROW"},
        {
            $push:{
                "config.home.triplistheaders": {
                    "key":"tracking_type",
                    "value":"Tracking Mode"
                }
            }
        })








      