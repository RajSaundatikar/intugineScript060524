db.getCollection("users").updateMany(
  { "config.client": "Kuehne+Nagel Pvt Ltd" },
  {
    $set: {
      "config.trips.expire_trip_based_on_sla": {
        operator: "*",
        threshold: 1,
      },
    },
  }
);
