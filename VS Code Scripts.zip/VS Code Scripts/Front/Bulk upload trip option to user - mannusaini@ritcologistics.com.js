
    db.getCollection("users").updateOne(
            {'username': "mannusaini@ritcologistics.com"},
            {
                $set:{
                    "config.trips.bulk_upload" : {
                        "show" : true,
                        "google" : true,
                        "fixed_headers" : true
                    }
                }
            })