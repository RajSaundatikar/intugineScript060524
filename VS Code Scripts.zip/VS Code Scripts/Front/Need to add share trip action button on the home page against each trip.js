
    


    db.getCollection("users").updateMany(
                    {"config.client": "SISECAM"},
                    {
                        $set:{
                            "config.home.otheroption.share_link": true
                        }
                    })