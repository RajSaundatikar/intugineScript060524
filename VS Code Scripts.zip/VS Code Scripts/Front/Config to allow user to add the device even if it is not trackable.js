
db.getCollection("users").updateMany(
    {"username":{
        $in:["daimlertvspune","daimlertvs_gurugram"]
    }},
    {
        $set:{
            "config.devicemanagment.otheroption.battery_limit":1,
            "config.devicemanagment.otheroption.time_limit":5184000000
        }
    })
    


    
    // "devicemanagment" : {
    //         "otheroption" : {
    //             "send_device" : true,
    //             "check_address" : true,
    //             "battery_limit" : NumberInt(1),
    //             "time_limit" : NumberLong(5184000000),
    //             "message_type" : true
    //         }
    //     }


