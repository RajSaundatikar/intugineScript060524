
    db.getCollection("users").updateMany(
                    {'config.client': "Himalaya Production"},
                    {
                        $push:{
                            "config.trips.extra_triplistheaders": {
                                $each:[
                                    {
                                        "key" : "src_doc_in",
                                        "value" : "Source Doc In"
                                    },
                                    {
                                        "key" : "src_doc_out",
                                        "value" : "Source Doc Out"
                                    },
                                    {
                                        "key" : "src_gate_out",
                                        "value" : "Source Gate Out"
                                    },
                                    {
                                        "key" : "dest_gate_in",
                                        "value" : "Destination Gate In"
                                    },
                                    {
                                        "key" : "dest_doc_in",
                                        "value" : "Destination Doc In"
                                    },
                                    {
                                        "key" : "dest_doc_out",
                                        "value" : "Destination Doc Out"
                                    },
                                    {
                                        "key" : "dest_gate_out",
                                        "value" : "Destination Gate Out"
                                    }

                                ]
                            }
                        }
                    })