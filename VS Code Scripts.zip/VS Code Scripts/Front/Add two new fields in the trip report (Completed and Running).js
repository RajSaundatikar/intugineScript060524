db.getCollection("users").updateMany(
  { "config.client": "LEGRAND GROUP" },
  {
    $set: {
      "config.reports.report_extra_columns": [
        {
          key: "lr_number",
          placeholder: "LR Number",
        },
        {
          key: "endNote",
          placeholder: "Trip End Note",
        },
      ],
    },
  }
);
