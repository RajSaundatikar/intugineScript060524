
    


       db.getCollection("users").updateMany(
        {"config.client" : "bridgestone", "config.vendor":"BGRL"},
        {
            $set:{
                "config.lr.static_fields.vendor_gstin": "23AAHCB5725F1ZY"
            }
        })