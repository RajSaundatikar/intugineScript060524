db.getCollection("users").updateMany(
  { "config.client": "Haier" },
  {
    $push: {
      "config.reports.report_header": {
        $each: [
          {
            key: "trip_start_date",
            value: "Trip Start Date",
          },
          {
            key: "trip_start_time",
            value: "Trip Start Time",
          },
        ],
      },
    },
  }
);
