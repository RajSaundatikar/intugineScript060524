
     db.getCollection("users").updateMany(
        {username: { $in: ["karan@tamannatransport", "vstransport58@gmail.com", "sfcgurgaon@gmail.com", "balajitransport3@gmail.com", "rakesh.srivastava@deliverysolutions.co.in", "msroadcarrier@gmail.com", "parultrslogistics@gmail.com", "rudracargo11@gmail.com", "shankarnath.dubey@gmail.com", "ap.logistics.pb.service@gmail.com", "rdlogis@rediffmail.com", "deeproadwaysj@gmail.com", "apccargo@rediffmail.com", "hvtsharidwar@gmail.com", "shrikrishnatransport2020@gmail.com", "supreme.ac.jpr2019@gmail.com", "supriyagoodscarrier@gmail.com", "themilesservices@gmail.com", "prabhakar@radiantxwayslogistic.com", "amit.kumar34@flipkart.com", "gurpreet@aerial", "vimalshukla@nbet.in", "kamalmalhi2000@gmail.com", "info@jainbandhuroadlines.com", "shriramexpresstransport@gmail.com", "aktransport6@gmail.com"] } },
        {
            $set:{
                "config.trips.submittedtripoptions.hide_end_trip": true,
                "config.trips.submittedtripoptions.edit":false,
                "config.trips.submittedtripoptions.status_update": false
            }
        })