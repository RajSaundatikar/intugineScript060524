
     //"OF BUSINESS"


db.getCollection("users").updateMany(
    {"config.client":"OF BUSINESS"},
    {
        $set:{
            "config.trips.otheroption.ping_disable":true
        }
    })


    