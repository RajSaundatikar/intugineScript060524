//home
    db.getCollection("users").updateMany(
        {"config.client":"BAYER", "config.home.triplistheaders.key": "src_ETA"},
        {
            $set:{
                "config.home.triplistheaders.$.key": "shipment_date"
            }
        })

// home - excel (MIS Report)
    db.getCollection("users").updateMany(
        {"config.client":"BAYER", "config.home.report_header.key": "src_ETA"},
        {
            $set:{
                "config.home.report_header.$.key": "shipment_date"
            }
        })      


//Trips

    db.getCollection("users").updateMany(
        {"config.client":"BAYER", "config.trips.triplistheaders.key": "src_ETA"},
        {
            $set:{
                "config.trips.triplistheaders.$.key": "shipment_date"
            }
        }) 

    //history

    db.getCollection("users").updateMany(
        {"config.client":"BAYER", "config.history.triplistheaders.key": "src_ETA"},
        {
            $set:{
                "config.history.triplistheaders.$.key": "shipment_date"
            }
        }) 


        //reports

        db.getCollection("users").updateMany(
            {"config.client":"BAYER", "config.reports.triplistheaders.key": "src_ETA"},
            {
                $set:{
                    "config.reports.triplistheaders.$.key": "shipment_date"
                }
            }) 


             //reports - excel

        db.getCollection("users").updateMany(
            {"config.client":"BAYER", "config.reports.report_header.key": "src_ETA"},
            {
                $set:{
                    "config.reports.report_header.$.key": "shipment_date"
                }
            }) 






        // db.yourCollectionName.updateOne(
        //     { "username": "935776", "config.home.triplistheaders.key": "src_ETA" },
        //     { 
        //       $set: { "config.home.triplistheaders.$.key": "shipment_date" }
        //     }
        //   )
          