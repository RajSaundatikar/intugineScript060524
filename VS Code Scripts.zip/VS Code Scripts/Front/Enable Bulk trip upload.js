db.getCollection("users").updateMany(
  { "config.client": "UNT Test" },
  {
    $set: {
      "config.trips.bulk_upload": {
        show: true,
        google: true,
        fixed_headers: true,
        triplistheaders: [
          {
            key: "driver_number",
            value: "Driver number",
          },
          {
            key: "srcname",
            value: "Source",
          },
          {
            key: "truck_number",
            value: "Truck number",
          },
          {
            key: "destname",
            value: "Destination",
          },
          {
            key: "tel",
            value: "Device ID",
          },
        ],
      },
    },
  }
);
