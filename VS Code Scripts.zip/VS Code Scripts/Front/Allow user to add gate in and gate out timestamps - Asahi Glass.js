
    //  db.getCollection("users").updateMany(
    //     {"config.client": "ASAHI GLASS" },
    //     {
    //         $set:{ 
    //             "config.app_navigation_lethan" : [
    //                 {
    //                     "key" : "NAV_LETHAN",
    //                     "text" : "Status Updates",
    //                     "desc" : "Status Updates",
    //                     "url" : "https://d8ni6op2f8qee.cloudfront.net/app_assets/form.png",
    //                     "introduced" : {
    //                         "version" : "1.0.14",
    //                         "nav_message" : {
    //                             "outline_color" : NumberInt(1),
    //                             "text" : "New!"
    //                         }
    //                     },
    //                     "web_url" : "https://sct.intutrack.com/?#!/app-trips"
    //                 }
    //             ],

    //             "config.trips.otheroption.trip_start_on_gate_out":true
    //         }
    //     })


        db.getCollection("users").updateMany(
            {"config.client": "ASAHI GLASS" },
            {
                $set:{
    
                    "config.trips.trips_status.newtripinputfields" : [
                        {
                            "key" : "text",
                            "placeholder" : "Select Status",
                            "type" : "list",
                            "values" : [
                                {
                                    "name" : "Source Gate In",
                                    "code" : "GATE_IN"
                                },
                                {
                                    "name" : "Source Gate Out",
                                    "code" : "GATE_OUT"
                                }
                            ]
                        },
                      
                        {
                            "key" : "time",
                            "placeholder" : "Select Date and Time",
                            "type" : "time"
                        }
                    ],
    
    
                    "config.trips.otheroption.trip_start_on_gate_out": true,
    
    
                    "config.trips.submittedtripoptions.status_update": true,
    
                    "config.apptrips.otheroption.update_status": true,
    
                    "config.app_navigation_lethan": [
                {
                    "key" : "NAV_LETHAN",
                    "text" : "Status Updates",
                    "desc" : "Status Updates",
                    "url" : "https://d8ni6op2f8qee.cloudfront.net/app_assets/form.png",
                    "introduced" : {
                        "version" : "1.0.14",
                        "nav_message" : {
                            "outline_color" : NumberInt(1),
                            "text" : "New!"
                        }
                    },
                    "web_url" : "https://sct.intutrack.com/?#!/app-trips"
                }
            ]
    
    
                }
            })