db.getCollection("users").find({username: {$in: ["bayer_in44", "bayer_in47", "bayer_in22", "bayer_in79", "bayer_in33", "bayer_in40", "bayer_in70", "bayer_in61", "bayer_in29", "bayer_in42", "bayer_in45", "bayer_in35", "bayer_in39", "bayer_in41", "bayer_in49", "bayer_in65", "bayer_in69", "bayer_in24", "bayer_in37", "bayer_in56", "bayer_in46", "bayer_in38", "bayer_in31", "bayer_in67", "bayer_in23", "bayer_in25", "bayer_in21", "bayer_in04", "bayer_in20", "bayer_in07", "bayer_in11", "bayer_in12", "bayer_in13", "bayer_in96", "bayer_in46", "bayer_in28", "bayer_in31"]}}).limit(1).forEach((k) => {
    let new_config = k.config;
    new_config["drops.customer_code"] = k.config.src_wh_code;
    new_config["filter_trips_by"].push("drops.customer_code");
    print(new_config)
    /*
    db.getCollection('users').updateOne(
    {_id: k._id, },  
        {
        $set: {
            config: new_config
        }
    })
    */
})