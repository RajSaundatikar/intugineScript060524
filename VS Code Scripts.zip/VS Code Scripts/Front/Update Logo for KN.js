
    //airtel
    
    db.getCollection("users").updateMany(
    {
        "config.client": "Kuehne + Nagel International AG_test"
    },
    {
        $set:{
            "config.logo" : {
                "url" : "https://assetsstatic.s3.ap-south-1.amazonaws.com/airtel-mobility-logo.png",
                "direction" : "left"
            }
        }
    })
    


    
//tetrapack

    db.getCollection("users").updateMany(
        {
            "config.client": "Kuehne+Nagel Pvt Ltd"
        },
        {
            $set:{
                "config.logo" : {
                    "url" : "https://assetsstatic.s3.ap-south-1.amazonaws.com/tetrapack_logo.png",
                    "direction" : "left"
                }
            }
        })