
    //  db.getCollection("users").find(
    //     {
    //         username:{ $in: ["ganesh.ilhe@flipkart.com", "sandesh.bhoir@flipkart", "ashish.tiwari@flipkart.com", "vipul.gohil@flipkart.com", "nirgude.akash@flipkart.com", "praneet.sarve@flipkart.com", "nitesh.patil@flipkart.com", "shashank.khare@flipkart.com"]}, 
            
    //         "config.navbar_headers_field":{$exists:true}

    //     }).count()


        db.getCollection("users").updateMany(
            {
                username:{ $in: ["ganesh.ilhe@flipkart.com", "sandesh.bhoir@flipkart", "ashish.tiwari@flipkart.com", "vipul.gohil@flipkart.com", "nirgude.akash@flipkart.com", "praneet.sarve@flipkart.com", "nitesh.patil@flipkart.com", "shashank.khare@flipkart.com"]}, 
                
                "config.navbar_headers_field":{$exists:true}
            },
            {
                $addToSet:{
                    "config.navbar_headers_field": {
                        "title" : "INDENT",
                        "path" : "/indent",
                        "show" : true
                    }

                    
                }
            })