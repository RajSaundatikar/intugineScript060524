
    db.getCollection("users").updateMany(
        {"config.client": "Expeditors"},
        {
            $set:{
                "config.trips.otheroption.device_unlock_access": true
            }
        }) 