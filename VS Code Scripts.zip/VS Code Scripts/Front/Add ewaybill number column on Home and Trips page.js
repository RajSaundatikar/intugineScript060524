  
    db.getCollection("users").updateMany(
    {"config.client":"SISECAM"},
    {
        $push:{
            "config.home.triplistheaders": {
                        "key":"ewb_number",
                        "value":"EWay Bill"
            }
        },

        $set:{
            "config.trips.extra_triplistheaders":[
                       {
                            "key":"ewb_number",
                            "value":"EWay Bill"
                        }
            ]
        }
    })