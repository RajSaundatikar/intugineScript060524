db.getCollection("users").updateOne(
  { username: "uslkumbalgodu@intugine.com" },
  {
    $set: {
      "config.filter_trips_by": ["srcname"],
      "config.srcname": ["USL Kumbalgodu"],
    },
  }
);
