db.getCollection("users").updateMany(
  {
    username: {
      $in: [
        "vipin.kumar2@flipkart.com",
        "kishlay.lal@flipkart.com",
        "shailesh.rai@flipkart.com",
        "ashish.gawade@flipkart.com",
        "anjan.banerjee@flipkart.com",
        "saivignesh.s@flipkart.com",
      ],
    },
  },
  {
    $set: {
      "config.trips.otheroption.bulk_geofence_upload": false,
      "config.trips.submittedtripoptions.hide_end_trip": true,
    },
  }
);
