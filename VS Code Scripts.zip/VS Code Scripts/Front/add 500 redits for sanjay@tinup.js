
    {
    
    "userId" : ObjectId("61d2d0782210a8363fda6664"),
    "type" : "credit",
    "previous_state" : {
        
            "previous_state": {
                "_id" : ObjectId("61d2d0782210a8363fda6664"),
                "client" : "total integrated logistics solutions",
                "client_name" : "",
                "client_client" : "",
                "available_credits" : NumberInt(-3),
                "env" : "live",
                "tel" : [
            
                ],
                "email" : [
            
                ],
                "createdAt" : ISODate("2022-01-03T10:31:20.168+0000"),
                "updatedAt" : ISODate("2023-09-04T14:27:26.506+0000"),
                "is_locked" : false,
                "account_status" : "activated",
                "mail_alerts" : {
                    "10_CREDIT_MAIL" : true,
                    "5_CREDIT_MAIL" : true,
                    "0_CREDIT_MAIL" : true
                }
                }
        
    },
    "amount" : NumberInt(500),
    "total_amount" : NumberInt(497),
    "manual" : true,
    "createdAt" : ISODate("2023-09-07T05:29:33.395+0000")
}
