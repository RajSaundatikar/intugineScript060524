



//home
    db.getCollection("users").updateOne(
        {"config.client":"FKT EWAYBILL"},
        {
            $push:{
                "config.home.triplistheaders":{
                    $each:[
                        {
                            "key":"ewb_number",
                            "value":"EWay Bill"
                        }
                    ]
                }
            }
        })


//Trips
db.getCollection("users").updateOne(
    {"config.client":"FKT EWAYBILL"},
    {
        $set:{
            "config.trips.extra_triplistheaders":[
                       {
                            "key":"ewb_number",
                            "value":"EWay Bill"
                        }
            ]
        }
    })

    
    
    //history
    db.getCollection("users").updateOne(
    {"config.client":"FKT EWAYBILL"},
    {
        $set:{
            "config.history":{
                "extra_triplistheaders":[
                    {
                         "key":"ewb_number",
                         "value":"EWay Bill"
                     }
            ]
            }
        }
    })
    






    // //reports
    // db.getCollection("users").updateMany(
    //     {"config.client":"Himalaya Test"},
    //     {
    //         $set:{
    //             "config.reports.extra_triplistheaders":[
    //                        {
    //                             "key":"spRequistionId",
    //                             "value":"Requisition ID"
    //                         },
    //                         {
    //                             "key": "vendor",
    //                             "value": "Transporter"
    //                         }
    //             ]
    //         }
    //     })