
    db.getCollection("users").updateMany(
        {"config.client":"Lets Transport"},
        {
            $push:{
                "config.reports.report_header":{
                    $each:[    
                                {
                                    "key" : "source_in_time",
                                    "placeholder" : "Source In Time"
                                }
                    ],
                    $position: 9
                }
            }
        })



         db.getCollection("users").updateMany(
        {"config.client":"Lets Transport"},
        {
            $push:{
                "config.reports.report_header":{
                    $each:[    
                                {
                                    "key" : "dest_out_time",
                                    "placeholder" : "Destination Out Time"
                                }
                    ],
                    $position: 24
                }
            }
        })














                                {
                                    "key" : "dest_out_time",
                                    "placeholder" : "Destination Out Time"
                                }







        db.getCollection("users").updateMany(
            {"config.client":"Himalaya Test"},
            {
                $push:{
                    "config.home.triplistheaders":{
                        $each:[
                            {
                            "key":"spTripId",
                            "value":"Indent Trip ID"
                            }
                        ]
                    }
                }
            })
    










      