
    db.getCollection("facilities").find({ "client" : "GMMCO INDIA", name:"Gmmco Chennai" })