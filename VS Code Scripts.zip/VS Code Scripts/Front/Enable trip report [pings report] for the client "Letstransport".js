

        db.getCollection("users").updateMany(
            {"config.client": "Lets Transport"},
        {
            $addToSet:{
                
                "config.home.triplistheaders": {
                    "key" : "trip_report",
                    "value" : "Trip Report"
                }
            }
        }
        )