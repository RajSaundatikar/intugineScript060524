//end trip action button
    db.getCollection("users").updateMany(
            {"config.client" : "SISECAM"},
            {
                $push:{
                    "config.home.triplistheaders":  {
                        "key" : "end_trip",
                        "value" : "End Trip"
                    }
                }
            })


            // In triplisheader
            // key : end_trip