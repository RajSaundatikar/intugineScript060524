
db.getCollection("customer_master_data").find({"user":"IOCL", value:"ZC0061"})