    //hide end trip button set true
    config.trips.submittedtripoptions.hide_end_trip 


    //edit set false
    config.trips.submittedtripoptions.edit



        db.getCollection("users").updateMany(
            {username:{
                $in:["himalaya_blrmwh","himalaya_ahmcfa"]
            }},
            {
                $set:{
                    "config.trips.submittedtripoptions.hide_end_trip":true,
                    "config.trips.submittedtripoptions.edit":false
                }
            })


            db.getCollection("users").updateOne(
                {username: "himalaya_btl"
                },
                {
                    $set:{
                        "config.trips.submittedtripoptions.hide_end_trip":true
                        
                    }
                })