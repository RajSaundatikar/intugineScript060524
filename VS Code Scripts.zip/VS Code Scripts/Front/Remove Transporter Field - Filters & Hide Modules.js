
   // config.home.otheroption.hide_filter : true


      db.getCollection("users").updateOne(
        {"username": "yusen_samsonite"},
        {
            $set:{
                "config.home.otheroption.hide_filter" : true

            }
        })