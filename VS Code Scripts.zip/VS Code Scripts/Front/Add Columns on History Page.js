
    db.getCollection("users").updateMany(
    {"config.client":"Himalaya Test"},
    {
        $push:{
            
            "config.history.extra_triplistheaders":
                    {
                         "key":"spTripId",
                         "value":"Indent Trip ID"
                     }
            
            }
    }
    )
    