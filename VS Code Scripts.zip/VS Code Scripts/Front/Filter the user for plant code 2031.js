
    db.getCollection("users").updateOne(
    {username:"sanjay.srivastava@hil.in"},
    {
        $set:{
            "config.filter_trips_by":["location_code"],
            "config.location_code": ["2031"]
        }
    })