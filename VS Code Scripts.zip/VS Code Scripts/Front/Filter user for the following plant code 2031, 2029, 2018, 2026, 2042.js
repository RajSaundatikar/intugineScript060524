
     db.getCollection("users").updateOne(
        {username:"sushilsingla84@gmail.com"},
        {
                $set:{
                    "config.filter_trips_by_and":["location_code", "vendor"],
                    "config.location_code": ["2031", "2029", "2018", "2026", "2042"],
                    "config.vendor": ["TripTell"]
                }
        })
        


        