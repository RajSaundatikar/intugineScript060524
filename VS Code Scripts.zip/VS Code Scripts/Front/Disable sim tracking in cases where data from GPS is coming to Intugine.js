
    //Set 'config.trips.gpsCheckEnabled' true for all users in this client
    
    
    db.getCollection("users").updateMany(
        {
           "config.client": "HMEL"
        },
        {
            $set:{
               "config.trips.gpsCheckEnabled": true
            }
        })