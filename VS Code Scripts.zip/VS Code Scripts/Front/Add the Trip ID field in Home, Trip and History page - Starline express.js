



//home
    db.getCollection("users").updateMany(
        {"config.client":"Starline Express"},
        {
            $push:{
                "config.home.triplistheaders":{
                    $each:[
                        {
                            "key":"custom_trip_id",
                            "value":"Trip ID"
                        }
                    ]
                }
            }
        })


//Trips
db.getCollection("users").updateMany(
    {"config.client":"Starline Express"},
    {
        $set:{
            "config.trips.extra_triplistheaders":[
                       {
                            "key":"custom_trip_id",
                            "value":"Trip ID"
                        }
            ]
        }
    })

    
    
    //history
    db.getCollection("users").updateMany(
    {"config.client":"Starline Express"},
    {
        $set:{
            "config.history.extra_triplistheaders":[
                    {
                         "key":"custom_trip_id",
                         "value":"Trip ID"
                     }
            ]
            
        }
    })
    
    //reports
    // db.getCollection("users").updateMany(
    //     {"config.client":"Starline Express"},
    //     {
    //         $set:{
    //             "config.reports.extra_triplistheaders":[
    //                        {
    //                             "key":"custom_trip_id",
    //                             "value":"Trip ID"
    //                         }
    //             ]
    //         }
    //     })