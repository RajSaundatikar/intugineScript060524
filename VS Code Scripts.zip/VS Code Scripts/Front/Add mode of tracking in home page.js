db.getCollection("users").updateMany(
  { "config.client": "Ashok Leyland" },
  {
    $push: {
      "config.home.triplistheaders": {
        key: "location_types_fetched",
        value: "Mode of tracking",
      },
    },
  }
);
