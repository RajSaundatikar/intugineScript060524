
     db.getCollection("users").updateMany(
    {
        "config.client": "Centuary Mattresses India"
    },
    {
        $addToSet:{
            "config.trips.mandatorinputfields": {
                $each: ["lr_number", "invoice"]
            }
        }
    })