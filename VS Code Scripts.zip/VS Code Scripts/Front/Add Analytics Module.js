
    db.getCollection("users").updateMany(
        {"config.client": "Yusen Logistics", "config.navbar_headers_field":{$exists:true}},
        {
            $addToSet:{

                "config.navbar_headers_field" : {
                    "title" : "Analytics",
                    "path" : "/analytics",
                    "show" : true
                }
                                            

            }
        })

        //check 

        db.getCollection("users").updateMany(
            {"config.client": "Yusen Logistics", "config.navbar_headers_field":{$exists:false}},
            {
                $set:{
    
                    "config.extra_headers" : [{
                        "title" : "Analytics",
                        "path" : "/analytics",
                        "show" : true
                    }]
                                                
    
                }
            })