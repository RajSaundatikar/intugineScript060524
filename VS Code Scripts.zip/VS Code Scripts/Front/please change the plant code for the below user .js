
       db.getCollection("users").updateOne(
    {username:"biswajit.p@hilin.onmicrosoft.com"},
    {
        $set:{
            "config.filter_trips_by":["location_code"],
            "config.location_code": ["2040"]
        }
    })