
     db.getCollection("users").updateOne(
    {username: "mahender@mahendercarrier.comm" },
    {
        $set:{

            "config.filter_trips_by":["client_client" ,"vendor"],
            "config.client_client": ["FKT-Large"],
            "config.vendor":["RJ LOGISTICS"]
        }
    })