// //facilities


//      {
   
//     "name" : "Varun Agritech Crop Care Private Ltd",
//     "client" : "DCM SHRIRAM AGRO",
//     "client_client" : null,
//     "trip_location_type" : [
//         "SOURCE"
//     ],
//     "location" : [
//         18.384420142809955, 79.19062733311343
//     ],
//     "extra_info" : {

//     }
//    }

// //


// {
   
//     "name" : "Adithya Agritech",
//     "client" : "DCM SHRIRAM AGRO",
//     "client_client" : null,
//     "trip_location_type" : [
//         "SOURCE"
//     ],
//     "location" : [
//         18.79040836196459, 78.28816151874882
//     ],
//     "extra_info" : {

//     }
//    }
//added in config   newtrip  srcname

   {
    "name" : "Varun Agritech Crop Care Private Ltd",
    "loc" : "18.384420142809955, 79.19062733311343"
   }






   {
    "name" : "Adithya Agritech ",
    "loc" : "18.79040836196459, 78.28816151874882"
   }