



    db.getCollection("users").updateOne(
  { "username": "himalaya_btl" },
  {
    $set:{
        "config.trips.otheroption.fields_to_edit":["tel","truck_number"] 
    }
  })





    //config.trips.otheroption.fields_to_edit:["tel","truck_number"] 