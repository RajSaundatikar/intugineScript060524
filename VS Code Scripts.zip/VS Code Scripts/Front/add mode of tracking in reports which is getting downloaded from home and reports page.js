
       db.getCollection("users").updateMany(
                    {"config.client": "HUNTEYED"},
                    {
                        $set:{
                            "config.reports.report_extra_columns":[{
                                    "key": "location_types_fetched",
                                    "placeholder": "Mode of tracking"
                            }]
                        }
                    })

                  