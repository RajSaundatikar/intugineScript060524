
    db.getCollection("users").updateMany(
    {"config.client": "Calcutta Express roadlines Pvt ltd"},
    {
        $set:{
            "config.trips.otheroption.eway_field_not_to_update": [
                "src",
                "srcname",
                "drops"
                ]
        }
    })