db.getCollection("facilities").insertOne( 
        {
            "name" : "R141",
            "client":"DCM SHRIRAM AGRO",    
               "trip_location_type" : [
                   "DESTINATION"
               ],
               "location" : [26.8539518,75.7612568],
               "other_details" : {
                "ro_name" : "Jaipur",
                "customer_name" : "Jaipur Hub"
            }
        
        });





     