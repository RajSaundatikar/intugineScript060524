// set modules for username
"modules" : {
    "OPTED_FOR" : [
        "INDENT_MANAGEMENT"
    ],
    "INDENT_MANAGEMENT" : {
        "FRONTEND" : {
            "NAV" : {
                "title" : "Indent",
                "path" : "/indent"
            },
            "BASE_URL" : "https://app2.superprocure.com/tripBoard",
            "creds" : {
                "URL_KEY" : "token",
                "token" : "MTE5OTAwOkFBNzkzNDIwMkMyMTVDQ0VDOUZDQzdBN0Y5ODg3Qzkz"
            }
        }
    }
},