
     db.getCollection("users").updateMany(
            {
                "config.client": "Yusen Logistics"
            },
            {
                $set:{

                    "config.reports.report_extra_columns":[
                        {
                        "key": "spRequistionId",
                        "placeholder": "Requisition ID"
                        },
                        {
                        "key": "spTripId",
                        "placeholder": "Indent trip ID"
                        }
                    ]
                }
            })

            db.getCollection("users").updateOne(
                {
                    "username": "yusen_production"
                },
                {
                    $set:{
    
                        "config.reports.report_extra_columns":[
                            {
                            "key": "spRequistionId",
                            "placeholder": "Requisition ID"
                            },
                            {
                            "key": "spTripId",
                            "placeholder": "Indent trip ID"
                            }
                        ]
                    }
                })