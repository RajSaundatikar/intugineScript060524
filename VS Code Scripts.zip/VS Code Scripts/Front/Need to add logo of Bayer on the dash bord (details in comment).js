
     db.getCollection("users").updateMany(
    {
        "config.client": "BAYER"
    },
    {
        $set:{
            "config.logo" : {
                "url" : "https://d8ni6op2f8qee.cloudfront.net/LOGO/bayer.jpg",
                "direction" : "left"
            }
        }
    })


    db.getCollection("users").updateOne(
        {
            "username": "bayer_demo"
        },
        {
            $set:{
                "config.logo" : {
                    "url" : "https://d8ni6op2f8qee.cloudfront.net/LOGO/bayer.png",
                    "direction" : "left"
                }
            }
        })