
                db.getCollection("users").updateMany(
                    {"config.client": "Prozo"},
                    {
                        $set:{
                            "config.reports.report_extra_columns":[{
                                    key: "lr_number",
                                    placeholder: "LR Number"
                            }]
                        }
                    })