
      db.getCollection("facilities").find({ "client" : "GMMCO INDIA", name:"Gmmco Nagpur" })
    
    
     db.getCollection("facilities").find({ "client" : "GMMCO INDIA", name:"Gmmco Singrauli" })