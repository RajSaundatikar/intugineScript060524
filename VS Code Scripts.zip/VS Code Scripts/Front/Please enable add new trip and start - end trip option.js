
     db.getCollection("users").updateMany(
        { username: { $in:["iscsmangalore@ritcologistics.com", "ritcomangalore@ritcologistics.com"] } },
        {
            $set:{
                
                "config.trips.submittedtripoptions.hide_end_trip": false,
                "config.trips.otheroption.hide_newtrip_button":false,
                "config.trips.submittedtripoptions.hide_start_trip": false,
                
            }
        })