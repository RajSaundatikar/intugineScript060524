
    db.getCollection("users").updateMany(
        {username:{ $in: ["guwahati_wh", "patna_wh", "raipur_wh", "ahmedabad_wh", "hissar_wh", "karnal_wh", "bhatinda_wh", "ludhiana_wh", "ranchi_wh", "pune_wh", "akola_wh", "bhopal_wh", "indore_wh", "indore_wh", "jaipur_wh", "kota_wh", "chittorgarh_wh", "srignaganagar_wh", "agra_wh", "bareilly_wh", "lucknow_wh", "kolkata_wh", "siliguri_wh", "karnataka", "andhra_pradesh", "telangana", "hissar_wh"] }},
        {
            $push: {
                
                "config.show_pages": "/trips"
            }
        }
        )