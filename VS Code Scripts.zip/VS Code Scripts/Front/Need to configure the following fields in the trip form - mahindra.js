
    db.getCollection("users").updateMany(
    {"config.client":"mahindra", "config.client_client":"Mahindra Logistics Bussiness Unit 1"},
    {
        $push:{
            "config.trips.newtripinputfields": {
                $each:[
                    
                    {
                        "key" : "leg",
                        "placeholder" : "Leg (1,3)",
                        "type" : "list",
                        "values" : [
                            {
                                "name" : "Leg 1"
                            },
                            {
                                "name" : "Leg 3"
                            }
                        ]
                     },
                     {
                        
                            "key" : "vin_number",
                            "placeholder" : "Vin number",
                            "type" : "text"
                        
                     },
                     {
                        "key" : "vehicle_mode",
                        "placeholder" : "Mode",
                        "type" : "list",
                        "values" : [
                            {
                                "name" : "Truck"
                            },
                            {
                                "name" : "Trailer"
                            },
                            {
                                "name": "Convoy"
                            }
                        ]
                     },
                     {
                        
                        "key" : "driver_name",
                        "placeholder" : "Driver Name",
                        "type" : "text"
                    
                    },
                    {
                        "key" : "dl_number",
                        "placeholder" : "Driver License",
                        "type" : "text"
                    },
                    {
                        "key" : "driver_dob",
                        "placeholder" : "Driver DOB ",
                        "type" : "text"
                    }

                    ]
            }

        }
    })