
    // Add below object which contains source name:"Kantakapalle" with values in days, in destination document.
   "eta_data" : {
        "Kantakapalle" : 2.083
    }