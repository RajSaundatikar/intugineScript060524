
    db.getCollection("users").updateMany(
        {"config.client":"ELGI"},
        {
            $set:{
                "config.alltracker.otheroption.halted_current_marker"  : true 
            }
        })