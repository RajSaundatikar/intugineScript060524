"CCI Logistics"


//invoice pull
db.getCollection("users").updateMany(
    {
        "config.client": "CCI Logistics"
    },
    {
        $pull:{
            "config.trips.newtripinputfields.$[elem].params" :{"key": "invoice"}
            

        }
    },
    {
        arrayFilters: [
            { "elem.key": "drops" }]
        
    }
    )



    // config.trips.newtripinputfields.2.params.0.key
    // config.trips.newtripinputfields.18.key

//load_number pull

        db.getCollection("users").updateMany(
            {
                "config.client": "CCI Logistics"
            },
            { $pull: { "config.trips.newtripinputfields": { "key": "load_number" } } }
         )


         //client_name push
        
         db.getCollection("users").updateMany(
            {
                "config.client": "CCI Logistics"
            },{
                $push:{
                    "config.trips.mandatorinputfields":"client_name"
                }
            })