
     db.getCollection("users").updateMany(
    { "config.client" : "USL Diageo"  },
    {
        $set:{
            "config.trips.otheroption.otp_lock":true

        }
    })