// set this in username preeti.swain@ripplr.in

//config.home.otheroption





            db.getCollection("users").updateMany(
                {"config.client": "Ripplr"},
                {
                    $set:{
                        "config.home.otheroption" : {
                            
                                "consent_status" : true
                                
                    }
                    }
                })