
   


        db.getCollection("users").updateMany(
            {"config.client":"Ritco Logistics"},
            {
                $set:{
                    "config.home.otheroption.show_fastag_tracked_counter": true
                }
            })


     

        