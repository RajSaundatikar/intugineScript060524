
       db.getCollection("users").updateOne(
    {username:"premchandra.s@hil.in"},
    {
        $set:{
            "config.filter_trips_by_and":["location_code"],
            "config.location_code": ["2032", "2019", "2029", "2021", "9910", "9941", "2031"]
        }
    })


    db.getCollection("users").updateOne(
        {username:"arun.magoo@hil.in"},
        {
            $set:{
                "config.filter_trips_by_and":["location_code"],
                "config.location_code": ["2032", "2019", "2029", "2021", "9910", "9941", "2031"]       
            }
        })