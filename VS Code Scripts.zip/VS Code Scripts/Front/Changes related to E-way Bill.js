



    db.getCollection("users").updateMany(
        {"config.client": "Prozo"},
        {
            $set:{
                "config.trips.otheroption.eway_fields_to_update" : ["eway_expiry"]
            }
        }
    )



