
    db.getCollection("users").updateOne(
        {username:"ravithakur@dcmshriram.com"},
        {
            $set:{
                "config.filter_trips_by": ["vertical"],
                "config.vertical" : ["R&OP"]
            }
        })


        db.getCollection("users").updateOne(
            {username:"shivanichawla@dcmshriram.com"},
            {
                $set:{
                    "config.filter_trips_by": ["vertical"],
                    "config.vertical" : ["HY Seed"]
                }
            })

        
            db.getCollection("users").updateOne(
                {username:"anuj.jain@dcmshriram.com"},
                {
                    $set:{
                        "config.filter_trips_by": ["vertical"],
                        "config.vertical" : ["CP"]
                    }
                })

                db.getCollection("users").updateOne(
                    {username:"akbartaria@dcmshriram.com"},
                    {
                        $set:{
                            "config.filter_trips_by": ["vertical"],
                            "config.vertical" : ["SPN"]
                        }
                    })