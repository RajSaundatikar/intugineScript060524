
    db.getCollection("users").updateMany(
    { "config.client" : "Flipkart-Transporter"  },
    {
        $set:{
            "config.trips.otheroption.otp_lock":true

        }
    })