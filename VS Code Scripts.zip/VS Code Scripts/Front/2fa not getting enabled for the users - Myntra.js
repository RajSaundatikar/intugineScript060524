
    db.getCollection("users").updateOne(
        {
            "username":"nikita.sharma3@myntra.com"
        },
        {
            $set:{
                "config.otp_auth": true,
                "email":"nikita.sharma3@myntra.com"
            }
        })

        db.getCollection("users").updateOne(
            {
                "username":"sreenivas.krishnan@myntra.com"
            },
            {
                $set:{
                    "config.otp_auth": true,
                    "email":"sreenivas.krishnan@myntra.com"
                }
            })