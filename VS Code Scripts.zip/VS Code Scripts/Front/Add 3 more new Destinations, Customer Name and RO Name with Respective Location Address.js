
    {   
        "name" : "K001",
        "client" : "DCM SHRIRAM AGRO",
        "client_client" : null,
        "trip_location_type" : [
            "DESTINATION"
        ],
        "location" : [
            15.0926513,
            76.8951551
        ],
        "other_details" : {
            "ro_name" : "Bellary",
            "customer_name" : "Rohit Agencies"
        }
}

{   
    "name" : "A002",
    "client" : "DCM SHRIRAM AGRO",
    "client_client" : null,
    "trip_location_type" : [
        "DESTINATION"
    ],
    "location" : [
        16.2341481,
        80.3992652
    ],
    "other_details" : {
        "ro_name" : "Guntur",
        "customer_name" : "Vijaysai Agro Agencies LLP"
    }
}

{   
    "name" : "A018",
    "client" : "DCM SHRIRAM AGRO",
    "client_client" : null,
    "trip_location_type" : [
        "DESTINATION"
    ],
    "location" : [
        17.3290084,
        78.575381
    ],
    "other_details" : {
        "ro_name" : "Hyderabad",
        "customer_name" : "Vishnupriya Enterprises"
    }
}