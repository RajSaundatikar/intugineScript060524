
    {
    "action": "TRIGGER_MIS_REPORT",
    "user": "FKT EWAYBILL",
    "query": {
      "client_client": null
    },
    "cron_expression": "30 4 * * *",
    "config": {
      "recipients": {"to" : ["kn.sunil@flipkart.com", "adhithya.bhalajee@flipkart.com", "raju.belekar@flipkart.com", "prayushi.kumawat@flipkart.com", "subhanshu.pareek@flipkart.com", "syed.tabrez@flipkart.com"]}
    }
  }

  