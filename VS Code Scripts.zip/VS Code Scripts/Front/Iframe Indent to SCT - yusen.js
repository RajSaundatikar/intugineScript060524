
    db.getCollection("users").updateOne(
        {username:"yusen_production"},
        {

            $set:{

                "config.modules" : {
                    "OPTED_FOR" : [
                        "INDENT_MANAGEMENT"
                        
                        
                    ],
                    "INDENT_MANAGEMENT" : {
                        "FRONTEND" : {
                            "NAV" : {
                                "title" : "Indent",
                                "path" : "/indent"
                            },
                            "BASE_URL" : "https://app2.superprocure.com",
                            "creds" : {
                                "URL_KEY" : "token",
                                "token" : "MTg3OTIyOkZCNjc1OERENEUyOUQ1MTQ5QjNCNUNBOTg4RUEzN0Ez"
                            }
                        }
                    }
        
                }

            }
            

        })