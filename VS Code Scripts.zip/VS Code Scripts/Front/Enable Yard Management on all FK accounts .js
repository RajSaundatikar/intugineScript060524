
  db.getCollection("users").updateMany(
    { "config.client": "FKT_Main" , "config.navbar_headers_field":{$exists:true }},
    {
        $addToSet:{
            "config.modules.OPTED_FOR": "YARD_MANAGEMENT",
            
            

            "config.navbar_headers_field":  {
                "title" : "YARD MGMT.",
                "path" : "/yard",
                "show" : true
            }    
        },

        $set:{
            "config.modules.YARD_MANAGEMENT":{
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Yard Management",
                        "path" : "/yard"
                    },
                    "BASE_URL" : "https://dq2sjc9nuei5i.cloudfront.net/"
                }
            }
        }
    }
    )
    //

    db.getCollection("users").updateMany(
        { "config.client": "FKT_Main" , "config.navbar_headers_field":{$exists:false }},
    {
        $addToSet:{
            "config.modules.OPTED_FOR": "YARD_MANAGEMENT"
              
        },

        $set:{
            "config.modules.YARD_MANAGEMENT":{
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Yard Management",
                        "path" : "/yard"
                    },
                    "BASE_URL" : "https://dq2sjc9nuei5i.cloudfront.net/"
                }
            }
        }
    }
    )


    db.getCollection("users").updateMany(
        { "config.client": "FKT_Main" , "config.show_pages":{$exists:true }},
        {
            $addToSet:{
                "config.show_pages" : "/yard"
            }
        })