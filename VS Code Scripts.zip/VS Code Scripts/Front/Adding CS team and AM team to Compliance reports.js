db.getCollection("configurations").updateMany(
  { action: "TRIGGER_COMPLIANCE_REPORT" },
  {
    $addToSet: {
      "config.recipients": {
        $each: ["cs@intugine.com", "am@intugine.com"],
      },
    },
  }
);
