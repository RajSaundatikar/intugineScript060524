db.getCollection("users").updateOne(
    {username:"akhilkumar.v@flipkart.com"},
    {
        $set:{
            
            "config.srcname": ["BLP_ML","BNL_ML","BLP1_ML","JAI_ML","LKO_ML","CND_ML","Motherhub_BNL"],
            "config.filter_trips_by": ["srcname"] 
        }
    })