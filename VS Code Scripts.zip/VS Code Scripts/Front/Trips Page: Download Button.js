
     db.getCollection("users").updateMany(
    {
        "config.client": "IOCL"
    },
    {
        $set:{
            "config.trips.otheroption.download_report": true,
            "config.trips.otheroption.dynamic_trip_report": true
        }
    })