
    db.getCollection("users").updateMany(
    { "config.client": "Starline Express" },
    {
      $push: {
       "config.trips.extra_triplistheaders" : {
                   
                    "key" : "submitted_by",
                    "value" : "Created By"
                }

      }
    })