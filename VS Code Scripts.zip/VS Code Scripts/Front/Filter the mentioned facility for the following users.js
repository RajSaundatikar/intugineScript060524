
    //filterDrops.js 


    db.getCollection("users").find({username: {$in: ["amiya.bhowmik@flipkart.com", "rajpratap.singh@flipkart.com", "sumit.rai@flipkart.com", "ravi.soni@flipkart.com", "rupali.sahu3@flipkart.com", "kushal.k1@flipkart.com", "sahu.dron@flipkart.com", "bibekananda.p@flipkart.com", "pinaki.mishra@flipkart.com", "prabhat.sahu@flipkart.com", "bhoi.rajesh@flipkart.com", "nitu.deka@flipkart.com", "baruah.nipon@flipkart.com", "dipjyoti.patar@flipkart.com", "dharminder.singh1@flipkart.com", "mithu.b@flipkart.com", "debajit.talukdar@flipkart.com", "noimul.haque@flipkart.com", "medhi.bhabesh@flipkart.com", "das.munindra@flipkart.com", "kumar.pankaj1@flipkart.com", "nitesh.mishra.vc@flipkart.com", "yadav.nitesh@flipkart.com", "bibhuti.shetty@myntra.com", "sunit.r@flipkart.com", "hiranya.p@flipkart.com"]   }}).forEach((k) => {
    let new_config = k.config;
    new_config["drops.name"] = k.config.srcname;
    //new_config["filter_trips_by"].push("drops.customer_code");
    print(new_config)
    
    db.getCollection('users').updateOne(
    {_id: k._id, },  
        {
        $set: {
            config: new_config
        }
    })
    
})