
    db.getCollection("users").updateMany(
    {"config.client": "FKT-Large"},
        {    $set:{
                "config.reports.otheroption.geofence_report": true
                    }
        }
    )


    