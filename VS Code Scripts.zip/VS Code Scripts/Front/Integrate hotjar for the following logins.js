
    


    db.getCollection("users").updateMany(
        { username:{$in:["amit.bidawatka@flipkart.com","debasri.sarkar@flipkart.com","flipkart_ykb",
                            "harvinder.kapur@flipkart.com", "shiva.sankar@flipkart.com", "nimith.shivadas@flipkart.com", 
                            "parixitsinh.kosada@flipkart.com"]}},
        {
            $set:{
                
                "config.hjar_id" : 3595645
              
            }
        })


        