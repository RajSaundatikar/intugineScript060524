
      db.getCollection("users").updateMany(
            {"config.client":"mahindra", "config.client_client":"Mahindra Logistics Bussiness Unit 1"},
            {
                $set:{
                    "config.trips.bulk_upload" :  {
                        "show" : true,
                        "google" : true,
                        "fixed_headers" : true,
                        "triplistheaders" : [
                            {
                                "key" : "tel",
                                "value" : "Mobile Number"
                            },
                            {
                                "key" : "srcname",
                                "value" : "Source"
                            },
                            {
                                "key" : "destname",
                                "value" : "Destination"
                            },
                            {
                                "key" : "invoice",
                                "value" : "Invoice"
                            },
                            {
                                "key" : "lr_number",
                                "value" : "LR Number"
                            },
                            {
                                "key" : "truck_number",
                                "value" : "Vehicle number"
                            },
                            {
                                "key" : "vehicle_capacity",
                                "value" : "Vehicle Capacity"
                            },
                            
                            {
                                "key" : "eta_days",
                                "value" : "ETA in Days"
                            },
                            {
                                "key" : "vendor",
                                "value" : "Transporter"
                            },
                            {
                                "key" : "customer_id",
                                "value" : "Customer ID"
                            },
                            {
                                "key" : "eway_expiry",
                                "value" : "EWAY Bill Expiry Date",
                                "type":"date"
                            },
                            {
                                "key" : "client_name",
                                "value" : "Client Name"
                            },
                            {
                                "key" : "transporter_number",
                                "value" : "Transporter Number"
                            },
                            {
                                "key" : "leg",
                            "value" : "Leg (1,3)"
                            },
                            {
                                "key" : "vin_number",
                            "value" : "Vin number"
                            },
                            {
                                "key" : "vehicle_mode",
                            "value" : "Mode"
                            },
                            {
                                "key" : "driver_name",
                                "value" : "Driver Name"
                            },
                            {
                                "key" : "dl_number",
                                "value" : "Driver License"
                            },
                            {
                                "key" : "driver_dob",
                                "value" : "Driver DOB ",
                                "type" : "date"
                            }
                            
        
        
        
                        ]
                    }
                }
            })


           