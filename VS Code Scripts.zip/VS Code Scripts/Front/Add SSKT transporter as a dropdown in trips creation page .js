
    


    db.getCollection("users").updateMany(
        {
           "config.client": "bridgestone"
        },
        {
            $push:{
               "config.trips.newtripinputfields.$[elem].values": {
                "name": "SSKT"
               }
            }
        },
        {
            arrayFilters: [
                                { "elem.key": "vendor" }]
        })