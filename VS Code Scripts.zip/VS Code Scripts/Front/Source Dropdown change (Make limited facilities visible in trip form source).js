
    {
   
    "name" : "Malkajgiri",
    "client" : "USL Diageo",
    "client_client" : null,
    "trip_location_type" : [
        "SOURCE"
    ],
    "location" : [
        17.4473789,78.5351834    
    ],
    "extra_info" : {

    }
}


db.getCollection("users").updateOne(
    {  "username": "usldiageotgadmin@intugine.com"  },
    {
        $set:{
            "config.facilities" : {
                "inclusive_filters" : {
                    "trip_location_type" : [
                        "SOURCE"
                    ],
                    "name" : [
                        "RK Distilleries",
                        "Nacharam",
                        "Malkajgiri"
                    ]
                }
            }
        }
    })