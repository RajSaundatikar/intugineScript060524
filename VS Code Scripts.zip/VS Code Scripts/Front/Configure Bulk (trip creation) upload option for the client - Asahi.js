
    db.getCollection("users").updateMany(
            {'config.client': "ASAHI GLASS"},
            {
                $set:{
                    "config.trips.bulk_upload" : {
                        "show" : true,
                        "google" : true,
                        "fixed_headers" : true
                    }
                }
            })

           