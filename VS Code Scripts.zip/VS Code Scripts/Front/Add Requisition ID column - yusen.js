
//home
    db.getCollection("users").updateMany(
        {"config.client":"Yusen Logistics"},
        {
            $addToSet:{
                "config.home.triplistheaders":{

                        "key":"spRequistionId",  
                        "value":"Requisition ID"
                }
            }
        })


//Trips
db.getCollection("users").updateMany(
    {"config.client":"Yusen Logistics"},
    {
        $set:{
            "config.trips.extra_triplistheaders":[
                       {
                            "key":"spRequistionId",
                            "value":"Requisition ID"
                        }
            ]
        }
    })

    
    
    //history
    db.getCollection("users").updateMany(
    {"config.client":"Yusen Logistics"},
    {
        $set:{
            "config.history.extra_triplistheaders": [
                    {
                         "key":"spRequistionId",
                         "value":"Requisition ID"
                     }
                ]
            
        }
    })
    
    //reports
    db.getCollection("users").updateMany(
        {"config.client":"Yusen Logistics"},
        {
            $set:{
                "config.reports.extra_triplistheaders":[
                           {
                                "key":"spRequistionId",
                                "value":"Requisition ID"
                            }
                ]
            }
        })