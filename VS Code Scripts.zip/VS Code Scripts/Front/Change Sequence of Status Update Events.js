
    "config.trips.trips_status.newtripinputfields"


                        


                        db.getCollection("users").updateMany(
                                { "config.client":"Himalaya Production" },
                                {
                                    $set: {
                                    "config.trips.trips_status.newtripinputfields.$[elem].values": [
                                                            {
                                                                "name" : "Gate In",
                                                                "code" : "GATE_IN"
                                                            },
                                                            {
                                                                "name" : "Doc In",
                                                                "code" : "DOC_IN"
                                                            },
                                                            {
                                                                "name" : "Doc Out",
                                                                "code" : "DOC_OUT"
                                                            },
                                                            {
                                                                "name" : "Gate Out",
                                                                "code" : "GATE_OUT"
                                                            }
                                                        ]
                                    }
                                },
                                {
                                    arrayFilters: [
                                    {
                                        "elem.key": "text" 
                                    }
                                    ]
                                }
                                )
