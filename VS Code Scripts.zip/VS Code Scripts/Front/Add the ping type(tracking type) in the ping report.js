
     db.getCollection("users").updateMany(
        {'config.client': "Lets Transport"},
        {
            $set:{
                "config.home.otheroption.type_in_trip_report"  : true

            }
        })

        // This will add ping type or tracking type in ping report which is on home page