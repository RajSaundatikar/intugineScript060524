db.getCollection("users").updateMany(
    {"config.client":"CCI Logistics"},
    {
        $push:{
            "config.trips.extra_triplistheaders":{
                "key" : "eta_days",
                "value" : "SLA"
            }
            
        },
        $set:{
            "config.history.extra_triplistheaders":[{
                "key" : "eta_days",
                "value" : "SLA"
            }]
        }
                
    })