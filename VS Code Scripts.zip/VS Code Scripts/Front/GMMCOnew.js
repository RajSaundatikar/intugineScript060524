//Source, Telephone
    db.getCollection("users").updateMany({"config.client":"GMMCO INDIA"},
    {
        $set:{
            "config.trips.newtripinputfields": [
                {
                    "key" : "vendor",
                    "placeholder" : "Transporter",
                    "type" : "list",
                    "values" : [
                        {
                            "name" : "Reach Cargo CHN"
                        },
                        {
                            "name" : "Reach Cargo GOA"
                        },
                        {
                            "name" : "Allied Transport"
                        },
                        {
                            "name" : "Fairmacs"
                        },
                        {
                            "name" : "Super Deluxe"
                        },
                        {
                            "name" : "Premier Transport"
                        },
                        {
                            "name" : "Creative Manufacturing Solutions"
                        },
                        {
                            "name" : "CJ DARCL Logistics Ltd"
                        },
                        {
                            "name" : "MRC Logistics India Pvt Ltd"
                        },
                        {
                            "name" : "tcifreight"
                        }
                    ]
                        },
                         {
                            "key" : "transporter_number",
                            "placeholder" : "Transporter Number",
                            "type" : "text"
                        },
                       
                        {
                            "key" : "vehicle_type",
                            "placeholder" : "Vehicle Type",
                            "type" : "list",
                            "values" : [
                                {
                                    "name" : "LBT"
                                },
                                {
                                    "name" : "SLBT"
                                },
                                {
                                    "name" : "HBT"
                                },
                                {
                                    "name" : "19 Feet Truck"
                                },
                                {
                                    "name" : "20 Feet Truck"
                                },
                                {
                                    "name" : "20 Taurus"
                                },
                                {
                                    "name" : "Through Service Provider - Delhivery"
                                },
                                {
                                    "name" : "Through Service Provider - Xpressbees"
                                },
                                {
                                    "name" : "Others"
                                }
                            ]
                        },
                        {
                            "key" : "vehicle_capacity",
                            "placeholder" : "Vehicle Capacity",
                            "type" : "list",
                            "values" : [
                                {
                                    "name" : "0-5 ton"
                                },
                                {
                                    "name" : "5-10 ton"
                                },
                                {
                                    "name" : "10-15 ton"
                                },
                                {
                                    "name" : "15-20 ton"
                                },
                                {
                                    "name" : "20-25 ton"
                                },
                                {
                                    "name" : "25+ ton"
                                }
                            ]
                        },
                        {
                            "key" : "truck_number",
                            "placeholder" : "Truck Number",
                            "type" : "text"
                        },
                        {
                            "key" : "division",
                            "placeholder" : "Division",
                            "type" : "list",
                            "action_name" : "set_dropdown_data",
                            "mandatory_fields" : [
                                {
                                    "Equipments" : [
                                        "machine_serial_no"
                                    ]
                                }
                            ],
                            "values" : [
                                {
                                    "name" : "Parts"
                                },
                                {
                                    "name" : "Equipments"
                                },
                                {
                                    "name" : "JLG"
                                },
                                {
                                    "name" : "Engines"
                                },
                                {
                                    "name" : "Gensets"
                                },
                                {
                                    "name" : "Others"
                                }
                            ]
                        },
                        
                        
                        {
                            "key" : "division_type",
                            "placeholder" : "Division Type",
                            "type" : "list",
                            "values" : [
        
                            ]
                        },
                        {
                            "key" : "machine_serial_no",
                            "placeholder" : "Machine Serial No",
                            "type" : "text"
                        },
                        {
                            "key" : "client_name",
                            "placeholder" : "Client",
                            "type" : "text"
                        },
                        {
                            "key" : "ewb_no",
                            "placeholder" : "EWB No",
                            "type" : "text"
                        },
                        {
                            "key" : "eway_date",
                            "placeholder" : "EWAY Bill Date",
                            "type" : "date"
                        },
                        {
                            "key" : "eway_expiry",
                            "placeholder" : "EWAY Bill Expiry Date",
                            "type" : "date"
                        },
        
                        
                        {
                            "key" : "drops",
                            "type" : "array",
                            "max_length" : NumberInt(1),
                            "params" : [
                                {
                                    "key" : "be_number",
                                    "placeholder" : "BE Number"
                                },
                                {
                                    "key" : "be_date",
                                    "placeholder" : "BE Date",
                                    "type" : "date"
                                },
                                {
                                    "key" : "bl_number",
                                    "placeholder" : "BL NO / AirWay Bill NO"
                                },
                                {
                                    "key" : "bl_date",
                                    "placeholder" : "BL Date / AirWay Bill Date",
                                    "type" : "date"
                                },
                                {
                                    "key" : "invoice",
                                    "placeholder" : "Invoice No."
                                },
                                {
                                    "key" : "invoice_date",
                                    "placeholder" : "Invoice Date",
                                    "type" : "date"
                                },
                                {
                                    "key" : "lr_number",
                                    "placeholder" : "LR Number"
                                },
                                {
                                    "key" : "lr_date",
                                    "placeholder" : "LR Date",
                                    "type" : "date"
                                },
                                {
                                    "key" : "loc",
                                    "placeholder" : "Location"
                                }
                                
                               
                                
                            ]
                        },
                        {
                            "key" : "destname",
                            "no_show" : true
                        },
                        {
                            "key" : "eta_days",
                            "placeholder" : "ETA in Days",
                            "type" : "number"
                        }
                          
                    ]
        }

    })
    
     