
    db.getCollection("users").updateOne(
        {username:"ravi.shankar2@delhivery.com"},
        {
            $set:{
                "config.modules.INDENT_MANAGEMENT.FRONTEND.BASE_URL": "https://app2.superprocure.com/loadBoard",
                "config.modules.INDENT_MANAGEMENT.FRONTEND.creds.token": "MjU5NjA6REVCRDk5MTlFMkZBQjQ4NEM3MUJBMjM2QUI2MERCMDg="
            }
        })

        