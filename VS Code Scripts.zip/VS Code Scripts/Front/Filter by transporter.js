db.getCollection("users").updateOne(
  { username: "dbs@dbsent.co.in" },
  {
    $set: {
      "config.filter_trips_by": ["vendor"],
      "config.vendor": ["DBS"],
    },
  }
);
