
     db.getCollection("users").updateOne(
    {username: "bibhuti.shetty@myntra.com" },
    {
        $push:{
            "config.filter_trips_by":"client_client" 
        },

        $set:{
            "config.client_client": ["FKT","Flipkart - Myntra"]
        }
    })





    db.getCollection("users").updateOne(
        {username: "sunit.r@flipkart.com" },
        {
            $push:{
                "config.filter_trips_by":"client_client"    
            },
    
            $set:{
                "config.client_client": ["FKT","Flipkart - Myntra"]
            }
            
        })