
    db.getCollection("users").updateMany(
    { "config.client": "FKT"
    },
    {
        $set:{
    
            "config.modules.SUMMARY":{
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Summary",
                        "path" : "/summary"
                    },
                    "BASE_URL" : "https://master.dmhqlqdb3g66s.amplifyapp.com/summary"
                }
            },
    
            "config.navbar_headers" : true,  //1  
    
            "config.home_path" : "/summary", //2 landing page
            
    
            "config.navbar_headers_field" : [ //3 headbar sequence
                {
                    "title" : "SUMMARY",
                    "path" : "/summary",
                    "show" : true
                },
                {
                    "title" : "HOME",
                    "path" : "/home",
                    "show" : true
                },
                {
                    "title" : "TRIPS",
                    "path" : "/trips",
                    "show" : true
                },
                {
                    "title" : "TIMELINE",
                    "path" : "/timeline",
                    "show" : true
                },
                {
                    "title" : "HISTORY",
                    "path" : "/history",
                    "show" : true
                },
               
                {
                    "title" : "Live View",
                    "path" : "/all-tracker",
                    "show" : true
                },
                {
                    "title" : "INDENT",
                    "path" : "/indent",
                    "show" : true
                }
                
            ]
    
    
        }
        
    })


            // $push:{
            //     "config.modules.OPTED_FOR": "SUMMARY",
            //     "config.show_pages": "/summary"
            // }


            // db.getCollection("users").updateOne(
            //     {username:"nl_track"},
            //     {
            //         $set:{
            //             "config.modules.OPTED_FOR": "SUMMARY"
            //         }
            //     })


    db.getCollection("users").updateMany(
        {"config.client":"FKT","config.modules.OPTED_FOR": {$ne: "SUMMARY"}},
        {
            $push:{
                "config.modules.OPTED_FOR": "SUMMARY"
            }
        })

    

        db.getCollection("users").updateMany(
            {"config.client":"FKT","config.show_pages":{$exists:true}},
            {
                $addToSet:{
                    "config.show_pages": "/summary"
                }
            })




            ////////////////////////////////////////////////////// Not Executed




            db.getCollection("users").updateMany(
                {"config.client":"FKT","config.modules.CONTROL_TOWER":{$exists:true}},
                {
                    $addToSet: {
                        "config.navbar_headers_field":  {
                            "title" : "CONTROL TOWER",
                            "path" : "/control-tower",
                            "show" : true
                        }

                    }
                }
            )


            db.getCollection("users").find({
                "config.navbar_headers_field": {
                  $elemMatch: { "path": "/control-tower" }
                }
              })
              






            //
            // {
            //     "title" : "CONTROL TOWER",
            //     "path" : "/control-tower",
            //     "show" : true
            // }






         