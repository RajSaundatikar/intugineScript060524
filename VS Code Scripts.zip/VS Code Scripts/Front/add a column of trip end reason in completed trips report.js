
    db.getCollection("users").updateMany(
    {
        "config.client": {
            $in:["FKT","FKT-Large","Flipkart - Myntra"]
        }
    },
    {
        $push: {
            "config.reports.report_header":{
                key:"endNote",
                value:"End Note"
            }
        }
    })