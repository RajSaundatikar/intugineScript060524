
    db.getCollection("users").updateOne(
    {username:"bangalore_cfpl@centuaryindia.com"},
    {
        $set:{
            "config.filter_trips_by":["srcname"],
            "config.srcname":["BANGALORE CFPL"]
        }
    })