
    db.getCollection("users").updateMany(
    {username: { $in:["amit.kadam@flipkart.com", "pravin.kedar@flipkart.com", "naresh.jadav@flipkart.com", "pritam.gs@flipkart.com", "baviskar.divyesh@flipkart.com", "ranveer.singh@flipkart.com"] } },
    {
        
        $set:{
            "config.client": "FKT_Main",
            "config.filter_trips_by":"client_client",
            "config.client_client": ["FKT","Flipkart - Myntra"]
        }
    })