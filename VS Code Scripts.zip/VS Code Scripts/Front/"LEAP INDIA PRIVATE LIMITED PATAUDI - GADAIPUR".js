Remove this particular entry from the source/dest drop down masters "LEAP INDIA PRIVATE LIMITED PATAUDI - GADAIPUR"

Removed 
name:"LEAP INDIA PRIVATE LIMITED PATAUDI - GADAIPUR" from facilities