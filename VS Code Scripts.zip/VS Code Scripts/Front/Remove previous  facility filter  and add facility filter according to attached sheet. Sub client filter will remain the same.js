
    // Ran filterDrops.js script and below


    db.getCollection("users").find({username: {$in: ["hiranya.p@flipkart.com", "arjit.mondal@flipkart.com", "santanu.sur@flipkart.com", "roy.kamal@flipkart.com", "singh.uddesh@flipkart.com", "deepak.k8@flipkart.com", "sengupta.ranjan@flipkart.com", "avik.bhatt@flipkart.com", "mayank.gupta1@myntra.com", "umesh.kumar@myntra.com", "arindam.dutta@myntra.com", "manoj.kalita@myntra.com", "brijbhusan.bhowmick@flipkart.com", "b.sudipta@flipkart.com", "hironmoy.dutta@flipkart.com", "suryashis.dey@flipkart.com", "tamal.modak@flipkart.com", "simanta.ghosh@flipkart.com", "ks.sanjay@flipkart.com", "bijay.sahu@flipkart.com", "madhab.chatterjee@flipkart.com", "simanta.das@flipkart.com", "vijaykumar.ray@flipkart.com", "kumar.aman@flipkart.com", "kansabanik.madhab@flipkart.com"]   }}).forEach((k) => {
    let new_config = k.config;
    new_config["drops.name"] = k.config.srcname;
    //new_config["filter_trips_by"].push("drops.customer_code");
    print(new_config)
    
    db.getCollection('users').updateOne(
    {_id: k._id, },  
        {
        $set: {
            config: new_config
        }
    })
    
})