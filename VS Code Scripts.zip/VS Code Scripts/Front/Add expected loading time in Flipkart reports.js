


    db.getCollection("users").updateMany(
        {"config.client":"FKT_Main"},
        {
            $push:{
                
                "config.reports.report_header": {
                    key: "spLoadingDate",
                    value: "Expected Loading Date",
                    type: "date"
                    },

                "config.reports.report_extra_columns":{
                    key: "spLoadingDate",
                    placeholder: "Expected Loading Date",
                    type: "date"
                    }
            }
        })