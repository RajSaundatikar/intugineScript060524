// db.getCollection("users").updateMany(
//   { "config.client": "TECHFAB INDIA" },
//   {
//     $push: {
//       "config.trips.newtripinputfields": {
//         $each: [
//           {
//             key: "receiver_name",
//             placeholder: "Receivers Name",
//             type: "text",
//           },
//           {
//             key: "receiver_contact",
//             placeholder: "Receivers Contact",
//             type: "text",
//           },
//         ],
//       },
//     },
//   }
// );

// db.getCollection("users").updateMany(
//     { "config.client": "TECHFAB INDIA" },
//     {
//       $pull: {
//         "config.trips.newtripinputfields": {
//           "key": "receiver_name"
//         },
//       },
//     }
//   );

db.getCollection("users").updateMany(
  { "config.client": "TECHFAB INDIA" },
  {
    $set: {
      "config.trips.otheroption.default_epod_select": true,
    },
  }
);

db.getCollection("users").updateMany(
  { "config.client": "TECHFAB INDIA" },
  {
    $set: {
      "config.epod_enabled": true,
      "config.epod_stuff": {
        API_KEY:
          "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiIiwidXNlcm5hbWUiOiJ0ZWNoZmFiX2FkbWluIiwiY2xpZW50IjoiVEVDSEZBQi1JTkRJQSIsImNsaWVudF9uYW1lIjoiVEVDSEZBQiBJTkRJQSIsImlhdCI6MTcxMDkzNDU0MH0.SYe69GpMclF6Etiy_-mT-7B2odwkw4TQAgiFtRPy1_4",
        data: {
          username: "techfab_admin",
          client: "TECHFAB-INDIA",
          client_name: "TECHFAB INDIA",
          clients: ["TECHFAB-INDIA"],
        },
      },
    },
  }
);
