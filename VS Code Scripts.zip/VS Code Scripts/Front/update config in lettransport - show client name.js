
    db.getCollection("users").updateMany(
        {"config.client":"Lets Transport"},
        {
            $set:{
               "config.reports.otheroption.show_client_name": true
            }
        })



        

        