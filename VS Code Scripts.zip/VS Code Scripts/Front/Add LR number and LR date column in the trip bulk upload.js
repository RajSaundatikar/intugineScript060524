db.getCollection("users").updateMany(
  { "config.client": "Haier" },
  {
    $push: {
      "config.trips.bulk_upload.triplistheaders": {
        $each: [
          {
            key: "lr_number",
            value: "LR Number",
          },
          {
            key: "lr_date",
            value: "LR Date",
            type: "date",
          },
        ],
      },
    },
  }
);
