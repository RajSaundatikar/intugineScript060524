// Bayer

    


            db.getCollection("users").updateMany(
                {"config.client": "BAYER"},
                {
                    $set:{
                        "config.home.options" : {
                            "additional_filters" : [ 
                              {
                                  "key" : "src_wh_code",
                                  "label" : "Source WH Code"
                              },
                              {
                                  "key" : "dest_zone",
                                  "label" : "Destination Zone"
                              },
                              {
                                  "key" : "commodity_entity",
                                  "label" : "Commodity Entity"
                              }
                          
                          ]
                      }
                    }
                })