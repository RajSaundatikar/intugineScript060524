
      db.getCollection("users").updateMany(
    {
        "config.client":"Virya Logistics"
    },
    {
        $set:{
            "config.logo" : {
                "url" : "https://assetsstatic.s3.ap-south-1.amazonaws.com/virya_logistics_logo.png",
                "direction" : "left"
            }
        }
    })