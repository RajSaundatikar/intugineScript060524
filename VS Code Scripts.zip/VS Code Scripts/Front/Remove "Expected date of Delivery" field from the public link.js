
   // Remove "Expected date of Delivery" field from the public link


         db.getCollection("users").updateMany(
        {
            "config.client": "BAYER"
        },
        {
            $set:{
                "config.public.otheroption.hide.triplistheaders": ["base_ETA"]
            }
        })