
     db.getCollection("users").updateMany(
    {"config.client":"Kuehne + Nagel International AG_test" },
    {
        $push:{
            "config.home.triplistheaders": {
                        "key":"transport_mode",
                        "value":"Transport Mode"
            }
        }
    })