
    db.getCollection("users").updateMany(
            {'config.client': "GHCL"},
            {
                    $push:{
                        
                        "config.trips.newtripinputfields.$[element].values": 
                            {
                                "name" : "PORT KANDLA"
                            }
                        
                        }
                
            },
            {
                arrayFilters: [
                                { "element.key": "billed_client_name" }
                ]
            }
        )