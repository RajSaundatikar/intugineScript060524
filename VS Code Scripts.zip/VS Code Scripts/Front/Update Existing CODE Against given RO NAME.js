
  //Bhopal

    db.getCollection("facilities").updateMany(
        {client:"DCM SHRIRAM AGRO", "other_details.ro_name":/bhopal/i},
    {
        $set:{
            "other_details.src_code":"M069"
        }
    })

    //Indore

    db.getCollection("facilities").updateMany(
        {client:"DCM SHRIRAM AGRO", "other_details.ro_name":/indore/i},
    {
        $set:{
            "other_details.src_code":"M065"
        }
    })

    //kota

    db.getCollection("facilities").updateMany(
        {client:"DCM SHRIRAM AGRO", "other_details.ro_name":/kota/i},
    {
        $set:{
            "other_details.src_code":"R007"
        }
    })


    //raipur

    db.getCollection("facilities").updateMany(
        {client:"DCM SHRIRAM AGRO", "other_details.ro_name":/raipur/i},
    {
        $set:{
            "other_details.src_code":"C054"
        }
    })