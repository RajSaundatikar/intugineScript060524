
db.getCollection("configurations").insertOne({
action: "ENABLE_FASTAG_IN_TRIPS",
user: "Unanu",
threshold: {
from: "TRIP_START",
duration: 18000000,
},
});