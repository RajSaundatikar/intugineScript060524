




db.getCollection("users").updateMany(
{"config.client":"Kuehne + Nagel International AG_test"},
{
    $push:{

        "config.home.triplistheaders": 
                {
                    "key":"invoice",
                    "value": "Order No."
                }
    },
    
    $set:{
        "config.reports.extra_triplistheaders":
        [{
            "key":"invoice",
            "value": "Order No."
        }]
    }
})


db.getCollection("users").updateMany(
    {"config.client":"Kuehne + Nagel International AG_test"},
    {
        
        $unset:{
            "config.reports.extra_triplistheaders": ""
           
        }
    })





    db.getCollection("users").updateMany(
        {"config.client":"Kuehne + Nagel International AG_test"},
        {
            $set:{
                "config.history.extra_triplistheaders":
                [{
                    "key":"invoice",
                    "value": "Order No."
                }]
            }
        })