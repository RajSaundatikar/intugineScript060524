
  db.getCollection("users").updateMany(
        {"config.client" : "ELGI"},
        {
            $set:{
                "config.reports.report_header":[
                    {
                        "key": "invoice",
                        "value": "Invoice No."
                    },
                    {
                        "key": "tel",
                        "value": "Driver No."
                    },
                    {
                        "key": "operator", 
                        "value": "Operator"
                    },
                    {
                        "key": "truck_number",
                        "value": "Vehicle"
                    },
                    {
                        "key": "vendor",
                        "value": "Transporter"
                    },
                    {
                        "key": "srcname",
                        "value": "Source"
                    },
                    {
                        "key": "destname",
                        "value": "Destination"
                    },
                    {
                        "key": "client_code",
                        "value": "Client code"
                    },
                    {
                        "key": "client_name",
                        "value": "Client Name"
                    },
                    {
                        "key": "ewb_number",
                        "value": "E-waybill number"
                    },
                    {
                        "key": "vertical",
                        "value": "Vertical"
                    },
                    
                    {
                        "key": "trip_start_date",
                        "value": "Start Date"
                    },
                    {
                        "key": "trip_start_time",
                        "value": "Start Time"
                    },
                    {
                        "key": "source_out_time",
                        "value": "Source Out"
                    },
                    {
                        "key": "last_tracked",
                        "value": "Last Tracked"
                    },
                    {
                        "key": "last_address",
                        "value": "Last Known Location"
                    },
                    {
                        "key": "trip_status",
                        "value": "Status"
                    },
                    {
                        "key": "eta_days",
                        "value": "ETA"
                    },
                    {
                        "key": "status",
                        "value": "Tracked Status"
                    },
                    {
                        "key": "distance_travelled",
                        "value": "Distance Travelled (km)"
                    },
                    {
                        "key": "distance_remained",
                        "value": "Distance Remaining (km)"
                    },
                    {
                        "key": "ewbill",
                        "value": "EWAY BILL"
                    },
                    {
                        "key": "eta_days",
                        "value": "SLA"
                    },
                    
                   
                    {
                        "key": "documents",
                        "value": "Documents"
                    }
                    
                ]

                
            }
        })