
    db.getCollection("users").updateMany(
        {"config.client":"Haier", "config.filter_trips_by":{$exists:true, $size:2}},
        {
            $unset:{
                "config.filter_trips_by": ""
            },

            $set:{
                "config.filter_trips_by_and": [
                    "srcname",
                    "vendor"
                ]
            }
        })




//db.getCollection("users").find({"config.client":"Haier", "config.filter_trips_by":{$exists:true, $size:2}})