//     db.getCollection("users").updateMany(
// {
//     "config.client": "Haier"
// },
// {
//     $push: {
//     "config.reports.report_extra_columns": {
//         $each: [
//         {
//             "key": "lr_number",
//             "placeholder": "LR Number",
//         },
//         {
//             "key": "lr_date",
//             "placeholder": "LR Date",
//         },
//         ],
//     },
//     },
// }
// );

db.getCollection("users").updateMany(
  {
    "config.client": "Haier",
  },
  {
    $push: {
      "config.reports.report_header": {
        $each: [
          {
            key: "lr_number",
            value: "LR Number",
          },
          {
            key: "lr_date",
            value: "LR Date",
          },
        ],
      },
    },
  }
);
