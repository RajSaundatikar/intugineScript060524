
      db.getCollection("status").updateMany(
        {"tripId" : ObjectId("64c8b9521cc8dcf62d64b894")},
        {
            $set:{
                "isRejected" : false
            }
        })