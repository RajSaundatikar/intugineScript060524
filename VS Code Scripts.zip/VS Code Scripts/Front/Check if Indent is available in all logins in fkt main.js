
     db.getCollection("users").updateMany(
            {
                "config.client":"FKT_Main",  
                "config.navbar_headers_field":{$exists:true},
                "config.show_pages": {$exists:true}
            },
            {
                $addToSet:{

                    "config.navbar_headers_field": {
                        "title" : "INDENT",
                        "path" : "/indent",
                        "show" : true
                    },
                    
                    "config.show_pages": "/indent"
                    
                    
                }
            })



            db.getCollection("users").updateMany(
                {
                    "config.client":"FKT_Main",  
                    "config.navbar_headers_field":{$exists:true},
                    "config.show_pages": {$exists:false}
                },
                {
                    $addToSet:{
                        "config.navbar_headers_field": {
                            "title" : "INDENT",
                            "path" : "/indent",
                            "show" : true
                        }    
                    }
                })