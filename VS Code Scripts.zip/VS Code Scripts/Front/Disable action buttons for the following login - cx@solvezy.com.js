
    db.getCollection("users").updateOne(
        { username:"cx@solvezy.com" },
        {
            $set:{
                "config.trips.submittedtripoptions.edit": false,
                "config.trips.submittedtripoptions.hide_end_trip": true,
                "config.trips.submittedtripoptions.hide_update_location": true,
                "config.trips.otheroption.hide.consent_btn": true,
                "config.trips.otheroption.hide_newtrip_button":true,
                "config.trips.submittedtripoptions.hide_start_trip": true,
                "config.trips.otheroption.show_rcdl_details": false
            }
        })