


    
    //users
db.getCollection("users").updateMany(
    {"config.client": "Haier"},
    {$set:{
        "config.trips.fixed_running_threshold": 864000000,
        'config.reachParams.geofence_in': {}

    }
    }
    )


//trips
   

        db.getCollection("trips").find(
            {user:"Haier", running: true, $or:[{expiresAt:null},{expiryNote:"FIXED THRESHOLD EXCEEDED"}, {expiryNote: "GEOFENCE ENTRY"}]})
            .sort({_id:-1}).forEach((k) => {
                print(k.startTime, new Date(k.startTime.valueOf() + 864000000))
               db.getCollection('trips').updateOne(
                {_id: k._id, },
                 {
                    $set: {
                        expiresAt: new Date(k.startTime.valueOf() + 864000000 ),
                    expiryNote: "FIXED THRESHOLD EXCEEDED"
                    }
                 })
            })