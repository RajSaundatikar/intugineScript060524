
   // db.getCollection("users").updateMany(
      //  {"config.client":"FKT_Main", "config.home.options.additional_filters":{$exists:true}})

        db.getCollection("users").updateMany(
            {"config.client":"FKT_Main"},
            {
                $addToSet:{
                    "config.home.options.additional_filters":{
                        $each:[
                            {
                                "key" : "drops.name",
                                "label" : "Drop"
                            },
                            {
                                "key" : "spSubBranchName",
                                "label" : "Movement Type"
                            },
                            {
                                "key" : "zone",
                                "label" : "Zone"
                            },
                            {
                                "key" : "isRoundTrip",
                                "label" : "Round Trip",
                                "values" : [
                                    true,
                                    false
                                ]
                            }
                        ]
                    }
                }
            })