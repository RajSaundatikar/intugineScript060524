
     db.getCollection("users").updateMany(
    {username: { $in: ["ganesh_paradip@gmail.com", "wcil_paradip@gmail.com", "mmt_paradip@gmail.com",  "supreme_paradip@gmail.com", "efc_paradip@gmail.com", "rci_paradip@gmail.com", "sbt_paradip@gmail.com", "fortune_paradip@gmail.com", "inland_paradip@gmail.com", "rapid_paradip@gmail.com", "cet_paradip@gmail.com", "darcl_paradip@gmail.com", "dgfc_paradip@gmail.com", "shriniwasa_paradip@gmail.com"] } },
    {
        $set:{
            "config.filter_trips_by":[],
            "config.filter_trips_by_and":["src_code", "vendor"],
            "config.src_code":  ["0038"]
        },
        
      
    })