
    db.getCollection("users").updateMany(
            {
                "config.client": "Himalaya Production"
            },
            { $pull: { "config.trips.newtripinputfields": { "key": "lr_number" } } }
         )