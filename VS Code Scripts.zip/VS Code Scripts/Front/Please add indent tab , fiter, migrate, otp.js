
      db.getCollection("users").updateOne(
            {username:"mukesh.d1@flipkart.com" },
        {
            $set:{

                "config.modules" : {
                    "OPTED_FOR" : [
                        "INDENT_MANAGEMENT"
                        
                        
                    ],
                    "INDENT_MANAGEMENT" : {
                        "FRONTEND" : {
                            "NAV" : {
                                "title" : "Indent",
                                "path" : "/indent"
                            },
                            "BASE_URL" : "https://app2.superprocure.com/loadBoard",
                            "creds" : {
                                "URL_KEY" : "token",
                                "token" : "MjQyMTYxOkNERDY3MjJBRDc1RTgyMDQ3QjhDM0QxMTg0MTlGQjlE"
                            }
                        }
                    }
        
                }

            }
        }
        )



        db.getCollection("users").updateOne(
            {username:"mukesh.d1@flipkart.com" },
        {
            $set:{ 
                "config.filter_trips_by": ["srcname", "destname", "drops.name"],
                "config.srcname": ["centralhub_L_LKO3"],
                "config.destname":["centralhub_L_LKO3"]

            }

        })


        db.getCollection("users").updateOne(
        {
            "username": "mukesh.d1@flipkart.com"
        },
        {
            $set:{
                "config.otp_auth": true,
                "email": "mukesh.d1@flipkart.com"
            }
        })