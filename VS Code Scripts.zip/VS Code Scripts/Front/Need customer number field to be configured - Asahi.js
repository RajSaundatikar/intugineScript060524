
    db.getCollection("users").updateMany(
            {'config.client': "ASAHI GLASS"},
            {
                $push:{
                    "config.trips.newtripinputfields":{
                                "key" : "customer_number",
                                "placeholder" : "Customer Number",
                                "type" : "text"
                    }
                }
            })