


    
    db.getCollection("users").updateMany(
    {"config.client":"Onmove Prod"},
    {
        $set:{
            "config.home.otheroption.show_fastag_tracked_counter": true,
            "config.home.otheroption.hide.pending_trip_counter": true,
            "config.home.otheroption.hide.online_trip_counter": true
        }
    })