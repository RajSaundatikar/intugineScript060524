
    db.getCollection("users").updateOne(
        {username: "vinodbabu.kc@in.yusen-logistics.com" },
        {

            $set:{

                "config.modules" : {
                    "OPTED_FOR" : [
                        "INDENT_MANAGEMENT"
                        
                        
                    ],
                    "INDENT_MANAGEMENT" : {
                        "FRONTEND" : {
                            "NAV" : {
                                "title" : "Indent",
                                "path" : "/indent"
                            },
                            "BASE_URL" : "https://app2.superprocure.com/",
                            "creds" : {
                                "URL_KEY" : "token",
                                "token" : "MjgwMDg0OkJFMTNDRTVEQTExMzNCNUQ1RDU4REUxMzEyNjZFMjVE"
                            }
                        }
                    }
        
                }

            }
            

        })