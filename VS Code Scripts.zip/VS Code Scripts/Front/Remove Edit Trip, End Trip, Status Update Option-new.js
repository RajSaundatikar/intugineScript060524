
     db.getCollection("users").updateOne(
        {"username": "balaraj.sethi@blrlogistiks.com" },
        {
            $set:{
                "config.trips.submittedtripoptions.hide_end_trip": true,
                "config.trips.submittedtripoptions.edit":false,
                "config.trips.submittedtripoptions.status_update": false
            }
        })