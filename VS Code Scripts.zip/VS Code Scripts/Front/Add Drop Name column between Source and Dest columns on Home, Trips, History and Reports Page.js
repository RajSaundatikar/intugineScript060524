//home
     db.getCollection("users").updateMany(
            {"config.client":"Himalaya Production"},
            {
                $push:{
                    "config.home.triplistheaders":{
                        $each:[    
                            {
                                "key" : "all_drops_name",
                                "value" : "Drop Name"
                            }
                        ],
                        $position: 3
                    }
                }
            })

    //trips

    db.getCollection("users").updateMany(
        {"config.client":"Himalaya Production"},
        {
            $push:{
                "config.trips.extra_triplistheaders":{
                    $each:[    
                        {
                            "key" : "all_drops_name",
                            "value" : "Drop Name"
                        }
                    ],
                    $position: 5
                }
            }
        })



    //history

    db.getCollection("users").updateMany(
        {"config.client":"Himalaya Production"},
        {
            $push:{
                "config.history.extra_triplistheaders":{
                    $each:[    
                        {
                            "key" : "all_drops_name",
                            "value" : "Drop Name"
                        }
                    ],
                    $position: 5
                }
            }
        })


           //reports

    db.getCollection("users").updateMany(
        {"config.client":"Himalaya Production"},
        {
            $push:{
                "config.reports.extra_triplistheaders":{
                    $each:[    
                        {
                            "key" : "all_drops_name",
                            "value" : "Drop Name"
                        }
                    ],
                    $position: 5
                }
            }
        })