
    db.getCollection("users").updateMany(
        {username:{$in:["tilakraj.reddy@letstransport.team", "arvind.swamy@letstransport.team", "pawan.naidu@letstransport.team", "rushikesh.s@letstransport.team", "jyotirling.babu@letstransport.team", "kiran.laware@letstransport.team", "sopan.jogi@letstransport.team", "rishikesh.s@letstransport.team", "rohit.auti@letstransport.team", "sidappa.banegawe@letstransport.team", "shahadev.fajage@letstransport.team"]}},
        {
            $pull:{
                "config.modules.OPTED_FOR": "CONTROL_TOWER",
                "config.extra_headers": { "title": "Device managment"}
            },

            $unset:{
                "config.modules.CONTROL_TOWER": "Control Tower",
                "config.trips.otheroption.default_epod_select" : "",
                    "config.epod_enabled": "",
                    "config.epod_stuff":""

            }
        })


        

        // //epod
        // db.getCollection("users").updateMany(
        //     {username:{$in:["tilakraj.reddy@letstransport.team", "arvind.swamy@letstransport.team", "pawan.naidu@letstransport.team", "rushikesh.s@letstransport.team", "jyotirling.babu@letstransport.team", "kiran.laware@letstransport.team", "sopan.jogi@letstransport.team", "rishikesh.s@letstransport.team", "rohit.auti@letstransport.team", "sidappa.banegawe@letstransport.team", "shahadev.fajage@letstransport.team"]}},
        //     {
    
        //         $unset:{
        //             "config.trips.otheroption.default_epod_select" : "",
        //             "config.epod_enabled": "",
        //             "config.epod_stuff":""
        //         }
        //     })

        //     //

            


        //     db.getCollection("users").updateMany(
        // {username:{$in:["tilakraj.reddy@letstransport.team", "arvind.swamy@letstransport.team", "pawan.naidu@letstransport.team", "rushikesh.s@letstransport.team", "jyotirling.babu@letstransport.team", "kiran.laware@letstransport.team", "sopan.jogi@letstransport.team", "rishikesh.s@letstransport.team", "rohit.auti@letstransport.team", "sidappa.banegawe@letstransport.team", "shahadev.fajage@letstransport.team"]}},
        // {
        //     $pull:{
        //         "config.extra_headers": { "title": "Device managment"}
        //     }
        // })