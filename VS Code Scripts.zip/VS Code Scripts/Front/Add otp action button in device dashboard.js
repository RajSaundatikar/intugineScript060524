
    db.getCollection("users").updateOne(
        {username:"umakanthj@wowtruck.in"},
        {
            $set:{
                "config.trips.otheroption.otp_lock":true

            }
        })

        
               // "email": "umakanthj@wowtruck.in"