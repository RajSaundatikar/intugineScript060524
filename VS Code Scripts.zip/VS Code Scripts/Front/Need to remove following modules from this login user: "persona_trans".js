    
    //To disable/hide edit button set it as false
    "config.trips.submittedtripoptions.edit": false

    //To hide end trip button set this to true
    "config.trips.submittedtripoptions.hide_end_trip": true

    //Update Location
    "config.trips.submittedtripoptions.hide_update_location"

    //Trigger consent
    "config.trips.otheroption.hide.consent_btn"





    db.getCollection("users").updateOne(
        { username:"persona_trans" },
        {
            $set:{
                "config.trips.submittedtripoptions.edit": false,
                "config.trips.submittedtripoptions.hide_end_trip": true,
                "config.trips.submittedtripoptions.hide_update_location": true,
                "config.trips.otheroption.hide.consent_btn": true,

                "config.show_pages" : [
                    "/home",
                    "/trips",
                    "/history",
                    "/all-tracker"
                   
                ]
            }
        })



        //hide new trip
        //"config.trips.otheroption.hide_newtrip_button":true

        //hide start trip button
        //config.trips.submittedtripoptions.hide_start_trip