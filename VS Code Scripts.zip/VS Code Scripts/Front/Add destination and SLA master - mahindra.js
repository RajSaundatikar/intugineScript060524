
    db.getCollection("facilities").insertMany(
        [
            {
    
                "name" : "UNITED AUTOMOBILES",
                "client" : "mahindra",
                "client_client" : "Mahindra Logistics Bussiness Unit 1",
                "trip_location_type" : [
                    "Destination"
                ],
                "location" : [
                    28.48779605979703, 77.30275195569465
                ],
                "eta_data" : {
                                 "Okhala Station" : 0.04
                           },
                "extra_info" : {
            
                }
            },
            {
    
                "name" : "PRIME AUTOMOBILES",
                "client" : "mahindra",
                "client_client" : "Mahindra Logistics Bussiness Unit 1",
                "trip_location_type" : [
                    "Destination"
                ],
                "location" : [
                    28.41253253725617, 77.30597659243857
                ],
                "eta_data" : {
                                 "Okhala Station" : 0.04
                           },
                "extra_info" : {
            
                }
            },
            {
    
                "name" : "SRI DURGA AUTOMOBILES",
                "client" : "mahindra",
                "client_client" : "Mahindra Logistics Bussiness Unit 1",
                "trip_location_type" : [
                    "Destination"
                ],
                "location" : [
                    28.658485616490065, 77.1460489656933
                ],
                "eta_data" : {
                                 "Okhala Station" : 0.04
                           },
                "extra_info" : {
            
                }
            },
            {
    
                "name" : "INDRAPRASTHA AUTOMOBILES",
                "client" : "mahindra",
                "client_client" : "Mahindra Logistics Bussiness Unit 1",
                "trip_location_type" : [
                    "Destination"
                ],
                "location" : [
                    28.73409487455013, 77.21889963205996
                ],
                "eta_data" : {
                                 "Okhala Station" : 0.04
                           },
                "extra_info" : {
            
                }
            },
            {
    
                "name" : "KONCEPT AUTOMOBILES DELHI",
                "client" : "mahindra",
                "client_client" : "Mahindra Logistics Bussiness Unit 1",
                "trip_location_type" : [
                    "Destination"
                ],
                "location" : [
                    28.52441116165561, 77.13526073367152
                ],
                "eta_data" : {
                                 "Okhala Station" : 0.04
                           },
                "extra_info" : {
            
                }
            },
            {
    
                "name" : "KONCEPT AUTOMOBILES NOIDA",
                "client" : "mahindra",
                "client_client" : "Mahindra Logistics Bussiness Unit 1",
                "trip_location_type" : [
                    "Destination"
                ],
                "location" : [
                    28.499346771806266, 77.38642928954246
                ],
                "eta_data" : {
                                 "Okhala Station" : 0.04
                           },
                "extra_info" : {
            
                }
            }

        ])

