
     "config.trips.master_upload" : [
                {
                    "key" : "client_name",
                    "value" : "Client Name",
                    "headers" : [
                        {
                            "key" : "client_name",
                            "value" : "Client name"
                        }
                    ]
                }]



                'config.trips.otheroption.master_data_list': [
                    {
                        "key" : "client_name",
                        "parameter" : "client_name_list",
                        "form_keys" : [
                            "client_name"
                        ]
                    }
                ]

                db.getCollection("users").updateMany(
                {"config.client": "yatayat"},
                {
                    $set:{
                        'config.trips.otheroption.master_data_list': [
                            {
                                "key" : "client_name",
                                "parameter" : "client_name_list",
                                "form_keys" : [
                                    "client_name"
                                ]
                            }
                        ]

                    }
                })


                db.getCollection("users").updateMany(
                    {"config.client":"yatayat"},
                    { $set: { "config.trips.newtripinputfields.$[elem].values": [] } },
                    {
                     arrayFilters: [
                         { "elem.key": "client_name" }
                     ]  
                 }
                 )


                 db.getCollection("users").updateMany(
                    {"username":"gspcropsciencecrop"},
                    { $set: { "config.trips.newtripinputfields.$[elem].values": [] } },
                    {
                     arrayFilters: [
                         { "elem.key": "client_name" }
                     ]  
                 }
                 )