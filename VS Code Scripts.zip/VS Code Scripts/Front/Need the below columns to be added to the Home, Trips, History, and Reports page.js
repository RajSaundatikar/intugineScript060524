
    db.getCollection("users").updateMany(
        {"config.client" : "BAYER"},
        {
            $addToSet:{
                "config.home.triplistheaders":{
                    $each:[

                        {
                               "key" : "load_id",
                               "value" : "Load ID"
                       },
                       {
                           "key" : "src_wh_code",
                           "value" : "Source WH Code"
                       },
                       {
                           "key" : "src_city",
                           "value" : "Source City"
                       },
                       {
                           "key" : "src_pincode",
                           "value" : "Source Pincode"
                       },
                       {
                           "key" : "dest_city",
                           "value" : "Destination City"
                       },
                       {
                           "key" : "dest_pincode",
                           "value" : "Destination Pincode"
                       },
                       {
                           "key" : "dest_zone",
                           "value" : "Destination Zone"
                       },
                       {
                           "key" : "customer_code",
                           "value" : "Customer Code"
                       },
                       {
                           "key" : "vendor",
                           "value" : "Transporter Name"
                       },
                       {
                           "key" : "transporter_code",
                           "value" : "Transporter Code"
                       },
                       {
                           "key" : "src_ETA",
                           "value" : "Invoice Date"
                       },
                       {
                           "key" : "base_ETA",
                           "value" : "Expected Date of Delivery"
                       }
                   ]
                }
            },
            $set:{

                "config.trips.extra_triplistheaders":[

                    {
                           "key" : "load_id",
                           "value" : "Load ID"
                   },
                   {
                       "key" : "src_wh_code",
                       "value" : "Source WH Code"
                   },
                   {
                       "key" : "src_city",
                       "value" : "Source City"
                   },
                   {
                       "key" : "src_pincode",
                       "value" : "Source Pincode"
                   },
                   {
                       "key" : "dest_city",
                       "value" : "Destination City"
                   },
                   {
                       "key" : "dest_pincode",
                       "value" : "Destination Pincode"
                   },
                   {
                       "key" : "dest_zone",
                       "value" : "Destination Zone"
                   },
                   {
                       "key" : "customer_code",
                       "value" : "Customer Code"
                   },
                   {
                       "key" : "vendor",
                       "value" : "Transporter Name"
                   },
                   {
                       "key" : "transporter_code",
                       "value" : "Transporter Code"
                   },
                   {
                       "key" : "src_ETA",
                       "value" : "Invoice Date"
                   },
                   {
                       "key" : "base_ETA",
                       "value" : "Expected Date of Delivery"
                   }
               ],

                "config.history.extra_triplistheaders":[

                    {
                           "key" : "load_id",
                           "value" : "Load ID"
                   },
                   {
                       "key" : "src_wh_code",
                       "value" : "Source WH Code"
                   },
                   {
                       "key" : "src_city",
                       "value" : "Source City"
                   },
                   {
                       "key" : "src_pincode",
                       "value" : "Source Pincode"
                   },
                   {
                       "key" : "dest_city",
                       "value" : "Destination City"
                   },
                   {
                       "key" : "dest_pincode",
                       "value" : "Destination Pincode"
                   },
                   {
                       "key" : "dest_zone",
                       "value" : "Destination Zone"
                   },
                   {
                       "key" : "customer_code",
                       "value" : "Customer Code"
                   },
                   {
                       "key" : "vendor",
                       "value" : "Transporter Name"
                   },
                   {
                       "key" : "transporter_code",
                       "value" : "Transporter Code"
                   },
                   {
                       "key" : "src_ETA",
                       "value" : "Invoice Date"
                   },
                   {
                       "key" : "base_ETA",
                       "value" : "Expected Date of Delivery"
                   }
               ],
                "config.reports.extra_triplistheaders":[

                    {
                           "key" : "load_id",
                           "value" : "Load ID"
                   },
                   {
                       "key" : "src_wh_code",
                       "value" : "Source WH Code"
                   },
                   {
                       "key" : "src_city",
                       "value" : "Source City"
                   },
                   {
                       "key" : "src_pincode",
                       "value" : "Source Pincode"
                   },
                   {
                       "key" : "dest_city",
                       "value" : "Destination City"
                   },
                   {
                       "key" : "dest_pincode",
                       "value" : "Destination Pincode"
                   },
                   {
                       "key" : "dest_zone",
                       "value" : "Destination Zone"
                   },
                   {
                       "key" : "customer_code",
                       "value" : "Customer Code"
                   },
                   {
                       "key" : "vendor",
                       "value" : "Transporter Name"
                   },
                   {
                       "key" : "transporter_code",
                       "value" : "Transporter Code"
                   },
                   {
                       "key" : "src_ETA",
                       "value" : "Invoice Date"
                   },
                   {
                       "key" : "base_ETA",
                       "value" : "Expected Date of Delivery"
                   }
               ]
            }
        })


        // src zone
        // Load ID
        // src wh code
        // destination zone
        // customer code
        // transporter name
        // transporter code
        // Invoice Date
        // Expected date of delivery


        // {src_zone:1, load_id:1,src_wh_code:1,dest_zone:1, customer_code:1, vendor:1, transporter_code:1, src_ETA:1, base_ETA:1}


        [

         {
                "key" : "load_id",
                "value" : "Load ID"
        },
        {
            "key" : "src_wh_code",
            "value" : "Source WH Code"
        },
        {
            "key" : "src_city",
            "value" : "Source City"
        },
        {
            "key" : "src_pincode",
            "value" : "Source Pincode"
        },
        {
            "key" : "dest_city",
            "value" : "Destination City"
        },
        {
            "key" : "dest_pincode",
            "value" : "Destination Pincode"
        },
        {
            "key" : "dest_zone",
            "value" : "Destination Zone"
        },
        {
            "key" : "customer_code",
            "value" : "Customer Code"
        },
        {
            "key" : "vendor",
            "value" : "Transporter Name"
        },
        {
            "key" : "transporter_code",
            "value" : "Transporter Code"
        },
        {
            "key" : "src_ETA",
            "value" : "Invoice Date"
        },
        {
            "key" : "base_ETA",
            "value" : "Expected Date of Delivery"
        }
    ]







        
        
       
     