            
    db.getCollection("users").updateMany(
        {"config.client" : "BAYER"},
        {
            
            $set:{

                "config.home.triplistheaders":[
                    {
                        "key" : "truck_number",
                        "value" : "Truck Number"
                    },
                    {
                        "key" : "tel",
                        "value" : "Tel"
                    },
                    {
                        "key" : "srcname",
                        "value" : "Source"
                    },
                    {
                        "key" : "destname",
                        "value" : "Destination"
                    },
                    {
                        "key" : "invoice",
                        "value" : "SAP Delivery Number"
                    },
                    {
                        "key" : "start_time",
                        "value" : "Start Time"
                    },
                    {
                        "key" : "reached",
                        "value" : "E.T.A."
                    },
                    {
                        "key" : "last_tracked",
                        "value" : "Last Tracked"
                    },
                    {
                        "key" : "load_id",
                        "value" : "Load ID/ SAP Shipment Number"
                    },
                    {
                        "key" : "src_wh_code",
                        "value" : "Source WH Code"
                    },
                    {
                        "key" : "src_city",
                        "value" : "Source City"
                    },
                    {
                        "key" : "src_pincode",
                        "value" : "Source Pincode"
                    },
                    {
                        "key" : "dest_city",
                        "value" : "Destination City"
                    },
                    {
                        "key" : "dest_pincode",
                        "value" : "Destination Pincode"
                    },
                    {
                        "key" : "dest_zone",
                        "value" : "Destination Zone"
                    },
                    {
                        "key" : "customer_code",
                        "value" : "Customer Code"
                    },
                    {
                        "key" : "vendor",
                        "value" : "Transporter Name"
                    },
                    {
                        "key" : "transporter_code",
                        "value" : "Transporter Code"
                    },
                    {
                        "key" : "src_ETA",
                        "value" : "Load ID Date/ SAP Shipment Date"
                    },
                    {
                        "key" : "base_ETA",
                        "value" : "Expected Date of Delivery"
                    }
                ],

                "config.trips.triplistheaders":[
                    {
                        "key" : "device",
                        "value" : "Driver Mobile Number"
                    },
                    {
                        "key" : "truck_number",
                        "value" : "Truck Number"
                    },
                    {
                        "key" : "status",
                        "value" : "Status"
                    },
                    {
                        "key" : "last_tracked",
                        "value" : "Last Track"
                    },
                    {
                        "key" : "srcname",
                        "value" : "Source"
                    },
                    {
                        "key" : "destname",
                        "value" : "Destination"
                    },
                    {
                        "key" : "startTime",
                        "value" : "Start Time"
                    },
                    {
                        "key" : "base_ETA",
                        "value" : " Base E.T.A."
                    },
                    {
                        "key" : "eway_expiry",
                        "value" : "Eway Expiry"
                    },
                    {
                        "key" : "operator",
                        "value" : "Operator"
                    },
                    {
                        "key" : "invoice",
                        "value" : "SAP Delivery Number"
                    },
                  //////////
                    {
                        "key" : "load_id",
                        "value" : "Load ID/ SAP Shipment Number"
                    },
                    {
                        "key" : "src_wh_code",
                        "value" : "Source WH Code"
                    },
                    {
                        "key" : "src_city",
                        "value" : "Source City"
                    },
                    {
                        "key" : "src_pincode",
                        "value" : "Source Pincode"
                    },
                    {
                        "key" : "dest_city",
                        "value" : "Destination City"
                    },
                    {
                        "key" : "dest_pincode",
                        "value" : "Destination Pincode"
                    },
                    {
                        "key" : "dest_zone",
                        "value" : "Destination Zone"
                    },
                    {
                        "key" : "customer_code",
                        "value" : "Customer Code"
                    },
                    {
                        "key" : "vendor",
                        "value" : "Transporter Name"
                    },
                    {
                        "key" : "transporter_code",
                        "value" : "Transporter Code"
                    },
                    {
                        "key" : "src_ETA",
                        "value" : "Load ID Date/ SAP Shipment Date"
                    },
                    {
                        "key" : "base_ETA",
                        "value" : "Expected Date of Delivery"
                    }
                ],

                "config.history.triplistheaders":[

                    {
                        "key" : "truck_number",
                        "value" : "Truck Number"
                    },
                    {
                        "key" : "tel",
                        "value" : "Tel"
                    },
                    {
                        "key" : "invoice",
                        "value" : "SAP Delivery Number"
                    },
                    {
                        "key" : "srcname",
                        "value" : "Source"
                    },
                    {
                        "key" : "dest_name_input",
                        "value" : "Destination"
                    },
                    {
                        "key" : "startTime",
                        "value" : "Start Time"
                    },
                    {
                        "key" : "endTime",
                        "value" : "End Time"
                    },
                    {
                        "key" : "delay",
                        "value" : "Delivery Status"
                    },

                    //
                    {
                        "key" : "load_id",
                        "value" : "Load ID/ SAP Shipment Number"
                   },
                   {
                       "key" : "src_wh_code",
                       "value" : "Source WH Code"
                   },
                   {
                       "key" : "src_city",
                       "value" : "Source City"
                   },
                   {
                       "key" : "src_pincode",
                       "value" : "Source Pincode"
                   },
                   {
                       "key" : "dest_city",
                       "value" : "Destination City"
                   },
                   {
                       "key" : "dest_pincode",
                       "value" : "Destination Pincode"
                   },
                   {
                       "key" : "dest_zone",
                       "value" : "Destination Zone"
                   },
                   {
                       "key" : "customer_code",
                       "value" : "Customer Code"
                   },
                   {
                       "key" : "vendor",
                       "value" : "Transporter Name"
                   },
                   {
                       "key" : "transporter_code",
                       "value" : "Transporter Code"
                   },
                   {
                       "key" : "src_ETA",
                       "value" : "Load ID Date/ SAP Shipment Date"
                   },
                   {
                       "key" : "base_ETA",
                       "value" : "Expected Date of Delivery"
                   }
               ],
                "config.reports.triplistheaders":[

                    {
                        "key" : "tel",
                        "value" : "Driver No."
                    },
                    {
                        "key" : "truck_number",
                        "value" : "Truck Number"
                    },
                    {
                        "key" : "srcname",
                        "value" : "Source"
                    },
                    {
                        "key" : "destname",
                        "value" : "Destination"
                    },
                    {
                        "key" : "invoice",
                        "value" : "SAP Delivery Number"
                    },
                    
                    {
                        "key" : "startTime",
                        "value" : "Start Time"
                    },
                    {
                        "key" : "endTime",
                        "value" : "End Time"
                    },
                    {
                        "key" : "delay_interval",
                        "value" : "Delivery Status"
                    },
                    

                    //
                    {
                        "key" : "load_id",
                        "value" : "Load ID/ SAP Shipment Number"
                   },
                   {
                       "key" : "src_wh_code",
                       "value" : "Source WH Code"
                   },
                   {
                       "key" : "src_city",
                       "value" : "Source City"
                   },
                   {
                       "key" : "src_pincode",
                       "value" : "Source Pincode"
                   },
                   {
                       "key" : "dest_city",
                       "value" : "Destination City"
                   },
                   {
                       "key" : "dest_pincode",
                       "value" : "Destination Pincode"
                   },
                   {
                       "key" : "dest_zone",
                       "value" : "Destination Zone"
                   },
                   {
                       "key" : "customer_code",
                       "value" : "Customer Code"
                   },
                   {
                       "key" : "vendor",
                       "value" : "Transporter Name"
                   },
                   {
                       "key" : "transporter_code",
                       "value" : "Transporter Code"
                   },
                   {
                       "key" : "src_ETA",
                       "value" : "Load ID Date/ SAP Shipment Date"
                   },
                   {
                       "key" : "base_ETA",
                       "value" : "Expected Date of Delivery"
                   },
                   {
                    "key" : "trip_report",
                    "value" : "Trip Report"
                }

               ]
            },
            
                $unset:{
                    "config.trips.extra_triplistheaders":"",
                    "config.history.extra_triplistheaders":"",
                    "config.reports.extra_triplistheaders":""
                }
            

        })