
    db.getCollection("users").updateMany(
        { "config.client":"Ritco Logistics" , "username": {$nin:["mannusaini@ritcologistics.com", "balvinderbanga@ritcologistics.com", "rohitnand@ritcologistics.com", "ritcovapi@ritcologistics.com", "ritcopata@ritcologistics.com", "ritcojamnagar@ritcologistics.com", "ritco_dahej", "rayzon@ritcologistics.com"]} },
        {
            $set:{
                "config.trips.otheroption.hide_newtrip_button":true
            }
        })