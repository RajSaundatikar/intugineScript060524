
    //settingToken.js Script


    db.getCollection("users").updateMany(
        {
            username: {$in: ["rijo.varghese@flipkart.com", "athira.sivan1@flipkart.com", "bibin.varghese@flipkart.com", "jophin.joy@flipkart.com", "pradeep.vk@flipkart.com", "rinshad.tr@flipkart.com", "vishnu.pv@flipkart.com", "biju.kk@flipkart.com", "justin.john@flipkart.com", "paul.thomas@flipkart.com"] }, "config.modules":{ $exists:false } 
        },
        {

            $set:{

                "config.modules" : {
                    "OPTED_FOR" : [
                        "INDENT_MANAGEMENT"
                        
                        
                    ],
                    "INDENT_MANAGEMENT" : {
                        "FRONTEND" : {
                            "NAV" : {
                                "title" : "Indent",
                                "path" : "/indent"
                            },
                            "BASE_URL" : "https://app2.superprocure.com/loadBoard",
                            "creds" : {
                                "URL_KEY" : "token",
                                "token" : ""
                            }
                        }
                    }
        
                }

            }
            

        })


