
    




  db.getCollection("users").updateMany(
    { 

    "username": {
        $in: ["manuj.bansal@flipkart.com", "adhithya.bhalajee@flipkart.com", "nikhil.singh2@flipkart.com", "indranil.dhar@flipkart.com",  
          "nimith.shivadas@flipkart.com", "vidya.bk@flipkart.com", "achu.j@flipkart.com", 
        "snandhini@flipkart.com", "harishn@flipkart.com", "vijaykumar.n@flipkart.com", "lijo.joseph@flipkart.com", "shiva.sankar@flipkart.com", "rahul.singh19@flipkart.com", 
        "ranjan.abhishek@flipkart.com", "bhavya.gn@flipkart.com", "syed.saddam@flipkart.com", "prit.vardhan@flipkart.com", "raghavendra.c@flipkart.com", "mailari.gondi@flipkart.com",
         "yogesh.ip@flipkart.com", "h.vihas@flipkart.com", "mishra.parmanand@flipkart.com", "ranjit.nair@flipkart.com", "barath.kumar@flipkart.com"]},

         "config.navbar_headers_field":{$exists:true }
    },
    {
        $addToSet:{
            "config.modules.OPTED_FOR": "YARD_MANAGEMENT",
            
            

            "config.navbar_headers_field":  {
                "title" : "YARD MGMT.",
                "path" : "/yard",
                "show" : true
            }    
        },

        $set:{
            "config.modules.YARD_MANAGEMENT":{
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Yard Management",
                        "path" : "/yard"
                    },
                    "BASE_URL" : "https://dq2sjc9nuei5i.cloudfront.net/"
                }
            }
        }
    }
    )
    //

    db.getCollection("users").updateMany(
    { 

    "username": {
        $in: ["manuj.bansal@flipkart.com", "adhithya.bhalajee@flipkart.com", "nikhil.singh2@flipkart.com", "indranil.dhar@flipkart.com",  
          "nimith.shivadas@flipkart.com", "vidya.bk@flipkart.com", "achu.j@flipkart.com", 
        "snandhini@flipkart.com", "harishn@flipkart.com", "vijaykumar.n@flipkart.com", "lijo.joseph@flipkart.com", "shiva.sankar@flipkart.com", "rahul.singh19@flipkart.com", 
        "ranjan.abhishek@flipkart.com", "bhavya.gn@flipkart.com", "syed.saddam@flipkart.com", "prit.vardhan@flipkart.com", "raghavendra.c@flipkart.com", "mailari.gondi@flipkart.com",
         "yogesh.ip@flipkart.com", "h.vihas@flipkart.com", "mishra.parmanand@flipkart.com", "ranjit.nair@flipkart.com", "barath.kumar@flipkart.com"]},

         "config.navbar_headers_field":{$exists:false }
    },
    {
        $addToSet:{
            "config.modules.OPTED_FOR": "YARD_MANAGEMENT"
              
        },

        $set:{
            "config.modules.YARD_MANAGEMENT":{
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Yard Management",
                        "path" : "/yard"
                    },
                    "BASE_URL" : "https://dq2sjc9nuei5i.cloudfront.net/"
                }
            }
        }
    }
    )





















    db.getCollection("users").updateOne(
        { "username": "common_admin"
        },
        {
            $set:{
        
                "config.modules.SUMMARY":{
                    "FRONTEND" : {
                        "NAV" : {
                            "title" : "Summary",
                            "path" : "/summary"
                        },
                        "BASE_URL" : "https://master.dmhqlqdb3g66s.amplifyapp.com/summary"
                    }
                },
                
                "config.modules.OPTED_FOR": ["SUMMARY"],
    
                "config.home_path" : "/summary"
                 
            }
        })