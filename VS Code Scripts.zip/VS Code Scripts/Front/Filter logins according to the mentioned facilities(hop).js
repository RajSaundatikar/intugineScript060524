
    // Used filterDrops script and drops.name

    // Filter according to the facilities mentioned in column C(if the trip contains the facility in source,hop or destination, that trips should be visible to the user) and setup CT 


    db.getCollection("users").find({"username" : "bitu.das.vc@flipkart.com"})
    
    db.getCollection("users").find({username: {$in: [ "chinmoy.kk@flipkart.com", "dimple.ssingh@flipkart.com", "soumik.ganguly@flipkart.com", "arindam.ghosh1@flipkart.com", "riktesh.prasad@flipkart.com", "vishv.tiwari@flipkart.com", "devendra.kumar2@flipkart.com", "shreyashi.barua@flipkart.com", "bitu.das.vc@flipkart.com", "debojani.rajkhua@flipkart.com", "ranjan.behera@flipkart.com", "manisha.mohapatra@flipkart.com", "mishra.priyanka@flipkart.com", "surajit.panja@flipkart.com", "umesh.m@flipkart.com", "sujit.p@flipkart.com", "gauravkumar.dubey@flipkart.com", "tushar.sanjay@flipkart.com", "momin.roofi@flipkart.com", "kapil.rohit@flipkart.com", "gulamgaus.momin@flipkart.com", "hemant.sunil@flipkart.com", "vhora.farukbhai@flipkart.com", "vhora.izamamul@flipkart.com", "sohilsha.fakir@flipkart.com", "hitendra.kumar@flipkart.com", "mayur.getme@flipkart.com", "g.rajan@flipkart.com", "amrita.c@flipakrt.com", "mohamed.aqyar@flipkart.com", "elavarasan.ramaraj1@flipkart.com", "manimaran.k@flipkart.com", "karthik.m4@flipkart.com", "prasanth.s@flipkart.com", "anand.kb@flipkart.com", "arjun.yellappa.vc@flipkart.com", "thilak.g@flipkart.com", "p.ramu@flipkart.com", "jeevanagaraj.vc@flipkart.com", "ragulji.r@flipkart.com", "varun.shetake@flipkart.com", "siddesh.n.vc@flipkart.com", "dinesh.durai@flipkart.com", "johnsonramba.c.vc@flipkart.com", "baddamjairam.reddy@flipkart.com", "mallela.naveen@flipkart.com", "vankudothlakshm.n@flipkart.com", "arunkumar.d@flipkart.com", "satyanarayana.m@flipkart.com", "bommali.murali@flipkart.com", "manoranjan.t@flipkart.com", "pradeepkumar.m1@flipkart.com", "ajay.pandey8@flipkart.com", "anand.mishra.vc@flipkart.com", "monoorhasanshah.vc@flipkart.com", "sourav.mourya@flipkart.com", "harpreetsingh.k@flipkart.com", "sunil.sharma3@flipkart.com", "dalbir.singh.vc@flipkart.com", "rahul.kaushik@flipkart.com", "nareshkumar1.vc@flipkart.com", "tarun.kumar2@flipkart.com", "aniket.sagar@flipkart.com", "anuj.saini@flipkart.com", "yogesh.kumar5@flipkart.com", "sukhdev.singh@flipkart.com", "mohit.a@flipkart.com", "bhupesh.kumar@flipkart.com", "mohit.beniwal@flipkart.com", "ravi.sheoran@flipkart.com", "manjeetbhatti.vc@flipkart.com", "dipakkumar.vc@flipkart.com", "kundankumar1.vc@flipkart.com", "kumarpal.vc@flipkart.com", "saurabhs2.vc@flipkart.com", "gajanandg.vc@flipkart.com", "rakeshr1.vc@flipkart.com", "tusharsonkar.vc@flipkart.com", 
        "punit.singh@flipkart.com", 
   "sumit.satbir@flipkart.com"]   }}).forEach((k) => {
   let new_config = k.config;
   new_config["drops.name"] = k.config.srcname;
   //new_config["filter_trips_by"].push("drops.customer_code");
   print(new_config)
   
   db.getCollection('users').updateOne(
   {_id: k._id, },  
       {
       $set: {
           config: new_config
       }
   })
   