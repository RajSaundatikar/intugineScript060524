
     db.getCollection("users").updateOne(
        {username:"devendra_kapoor@rediffmail.com"},
        {
                $set:{
                    "config.filter_trips_by":["vendor"],
                    "config.vendor":["BG Cargo & Logistics"]
                }
        })