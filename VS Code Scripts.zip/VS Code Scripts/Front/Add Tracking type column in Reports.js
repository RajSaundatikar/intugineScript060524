
      db.getCollection("users").updateMany(
        {"config.client":"IOCL"},
        {
            $push:{
                "config.reports.report_extra_columns": {
                    "key":"tracking_type",
                    "placeholder":"Tracking Type"
                }
            }
        })