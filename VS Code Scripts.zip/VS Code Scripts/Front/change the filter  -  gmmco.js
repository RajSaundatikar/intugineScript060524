
    db.getCollection("users").updateOne(
    {username: "dineshmishra@gmmcoindia.com" },
    {   
        $push:{
            "config.filter_trips_by":"destname"
            
        },

        $set:{
            "config.destname": ["Gmmco Bhiwandi"]
        }
    })



    db.getCollection("users").updateOne(
        {username: "rajasekaran.s@gmmcoindia.com" },
        {   
            $push:{
                "config.filter_trips_by": "destname"
            },

            $set:{
               
                "config.destname": ["Gmmco Koppur"]
            }
        })