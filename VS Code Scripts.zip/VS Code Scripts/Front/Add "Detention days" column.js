
       db.getCollection("users").updateMany(
    {"config.client":"IOCL"},
    {
        $push:{
            
                "config.history.extra_triplistheaders":
                        {
                            "key":"unloading_duration",
                            "value": "Detention Days"
                        },

                "config.reports.report_extra_columns": {
                    "key":"unloading_duration",
                    "placeholder": "Detention Days"
                }

            
            }
    }
    )