
//     {
//     "_id" : ObjectId("64c0da177d2e1c0008a5fcb4"),
//     "name" : "Mihirvani Yard",
//     "client" : "mahindra",
//     "client_client" : "Mahindra Logistics Bussiness Unit 1",
//     "trip_location_type" : [
//         "SOURCE"
//     ],
//     "location" : [
//         18.738769870150957,
//         73.80571804638403
//     ],
//     "extra_info" : {

//     }
// }

//Remove 2 facil;ites              done
// Remove config.facilites         done
//Add new fac                      done


db.getCollection("facilities").insertMany(
    [
        {
           
            "name" : "Mihirvani Yard",
            "client" : "mahindra",
            "client_client" : "Mahindra Logistics Bussiness Unit 1",
            "trip_location_type" : [
                "SOURCE"
            ],
            "location" : [
                19.9649444,73.6531667
            ],
            "extra_info" : {
        
            }
        },
        {
           
            "name" : "Nashik Plant",
            "client" : "mahindra",
            "client_client" : "Mahindra Logistics Bussiness Unit 1",
            "trip_location_type" : [
                "SOURCE"
            ],
            "location" : [
                19.9988533,73.7246376
            ],
            "extra_info" : {
        
            }
        },
        {
           
            "name" : "Zaheerabad plant",
            "client" : "mahindra",
            "client_client" : "Mahindra Logistics Bussiness Unit 1",
            "trip_location_type" : [
                "SOURCE"
            ],
            "location" : [
                17.6903468,77.5720572
            ],
            "extra_info" : {
        
            }
        },
        {
           
            "name" : "Haridwar Plant",
            "client" : "mahindra",
            "client_client" : "Mahindra Logistics Bussiness Unit 1",
            "trip_location_type" : [
                "SOURCE"
            ],
            "location" : [
                29.9670833,78.0526111
            ],
            "extra_info" : {
        
            }
        },
        {
           
            "name" : "Haridwar Yard",
            "client" : "mahindra",
            "client_client" : "Mahindra Logistics Bussiness Unit 1",
            "trip_location_type" : [
                "SOURCE"
            ],
            "location" : [
                29.9660976,78.0762298
            ],
            "extra_info" : {
        
            }
        },
        {
           
            "name" : "Chakan Plant",
            "client" : "mahindra",
            "client_client" : "Mahindra Logistics Bussiness Unit 1",
            "trip_location_type" : [
                "SOURCE"
            ],
            "location" : [
                18.7395833,73.8062222
            ],
            "extra_info" : {
        
            }
        },
        {
           
            "name" : "Vasai Yard",
            "client" : "mahindra",
            "client_client" : "Mahindra Logistics Bussiness Unit 1",
            "trip_location_type" : [
                "SOURCE"
            ],
            "location" : [
                19.3029604,72.9029953
            ],
            "extra_info" : {
        
            }
        },
        {
           
            "name" : "Kandivali Plant",
            "client" : "mahindra",
            "client_client" : "Mahindra Logistics Bussiness Unit 1",
            "trip_location_type" : [
                "SOURCE"
            ],
            "location" : [
                19.202025, 72.867317
            ],
            "extra_info" : {
        
            }
        }

    ])















// {
//     "_id" : ObjectId("64c0da177d2e1c0008a5fcb5"),
//     "name" : "Loni station",
//     "client" : "mahindra",
//     "client_client" : "Mahindra Logistics Bussiness Unit 1",
//     "trip_location_type" : [
//         "DESTINATION"
//     ],
//     "location" : [
//         18.49480251872319,
//         74.01224599055703
//     ],
//     "extra_info" : {

//     },
//     "createdAt" : ISODate("2023-07-26T08:32:23.106+0000"),
//     "eta_data" : {
//         "Khed plant" : 0.125
//     }
// }


// {
//     "_id" : ObjectId("64c0da177d2e1c0008a5fcb4"),
//     "name" : "Khed plant",
//     "client" : "mahindra",
//     "client_client" : "Mahindra Logistics Bussiness Unit 1",
//     "trip_location_type" : [
//         "SOURCE"
//     ],
//     "location" : [
//         18.738769870150957,
//         73.80571804638403
//     ],
//     "extra_info" : {

//     },
//     "createdAt" : ISODate("2023-07-26T08:32:23.106+0000")
// }