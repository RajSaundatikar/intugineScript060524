
 


     db.getCollection("users").updateOne(
                { 
                    username:"bayer_east_ci"},
                {
                    $set:{
                        "config.filter_trips_by": ["src_wh_code", "dest_zone", "drops.customer_code"],

                        "config.src_wh_code": ["IN44", "IN47", "IN70", "IN61", "IN29", "IN42", "IN45", "IN35", "IN39", "7719", "7718", "2020", "2136", "2030", "2014", "7715", "7716", "7717"],

                        "config.dest_zone": ["IN44", "IN47", "IN70", "IN61", "IN29", "IN42", "IN45", "IN35", "IN39", "7719", "7718", "2020", "2136", "2030", "2014", "7715", "7716", "7717"]
                    }
                })

    
                db.getCollection("users").updateOne(
                    { 
                        username:"bayer_north_ci"},
                    {
                        $set:{
                            "config.filter_trips_by": ["src_wh_code", "dest_zone", "drops.customer_code"],
    
                            "config.src_wh_code": ["IN33","IN40","IN41","IN49","IN65","IN69","IN24","IN37","2028","7713","7707","2025","2023","7711","7712","7708"],
    
                            "config.dest_zone": ["IN33","IN40","IN41","IN49","IN65","IN69","IN24","IN37","2028","7713","7707","2025","2023","7711","7712","7708"]
                        }
                    })

                    

                 db.getCollection("users").updateOne(
                        { 
                            username:"bayer_south_ci"},
                        {
                            $set:{
                                "config.filter_trips_by": ["src_wh_code", "dest_zone", "drops.customer_code"],
        
                                "config.src_wh_code": ["IN56","IN46","IN38","IN31","IN67","2027","7705","5712","2017","7706"],
        
                                "config.dest_zone": ["IN56","IN46","IN38","IN31","IN67","2027","7705","5712","2017","7706"]
                            }
                        })

    
                
                
                db.getCollection("users").updateOne(
                        { 
                            username:"bayer_west_ci"},
                        {
                            $set:{
                                "config.filter_trips_by": ["src_wh_code", "dest_zone",, "drops.customer_code"],
        
                                "config.src_wh_code": ["IN22","IN79","IN23","IN25","IN21","2021","7502","2024","7721","7720"],
        
                                "config.dest_zone": ["IN22","IN79","IN23","IN25","IN21","2021","7502","2024","7721","7720"]
                            }
                        })
                        

                        db.getCollection("users").find({username: {$in: ["bayer_east_ci", "bayer_north_ci", "bayer_south_ci", "bayer_west_ci"]}}).forEach((k) => {
                            let new_config = k.config;
                            new_config["drops.customer_code"] = k.config.src_wh_code;
                            //new_config["filter_trips_by"].push("drops.customer_code");
                            print(new_config)
                            /*
                            db.getCollection('users').updateOne(
                            {_id: k._id, },  
                                {
                                $set: {
                                    config: new_config
                                }
                            })
                            */
                        })