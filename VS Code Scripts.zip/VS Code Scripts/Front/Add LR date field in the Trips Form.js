db.getCollection("users").updateMany(
  { "config.client": "Haier" },
  {
    $push: {
      "config.trips.newtripinputfields": {
        key: "lr_date",
        placeholder: "LR Date",
        type: "date",
      },
    },
  }
);
