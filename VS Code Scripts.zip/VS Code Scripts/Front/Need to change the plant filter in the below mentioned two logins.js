

    db.getCollection("users").updateOne(
    {username:"bayer_in46"},
    {
        $set:{
            "config.filter_trips_by": ["location_code"],
            "config.location_code": ["IN46", "7705"]
        }
    })



    db.getCollection("users").updateOne(
        {username:"bayer_in31"},
        {
            $set:{
                "config.filter_trips_by": ["location_code"],
                "config.location_code": ["IN31", "2017"]
            }
        })