
     db.getCollection("users").updateMany(
        {"config.client" : "Haier"},
        {
            
            $set:{

                "config.history.triplistheaders": [
                    {
                        "key" : "o_start_date",
                        "value" : "Dispatch Date"
                   
                    },
                    {
                        "key" : "o_start_time",
                        "value" : "Dispatch Time"
                    },
                    {
                        "key" : "srcname",
                        "value" : "Source"
                    },
                    {
                        "key" : "dest_name_input",
                        "value" : "Destination"
                    },
                    {
                        "key" : "vendor",
                        "value" : "Transporters"
                    },
                    {
                        "key" : "truck_number",
                        "value" : "Vehicle Number"
                    },
                    {
                        "key" : "tel",
                        "value" : "Driver Number"
                    },
                    {
                        "key" : "start_time",
                        "value" : "In-Transit Date & Time"
                    },
                    {
                        "key" : "last_remark_time",
                        "value" : "Waiting for Unloading Date & Time"
                    },
                    {
                        "key" : "unloading_time",
                        "value" : "Unloaded Date & Time"
                    },
                    {
                        "key" : "reached_set_time",
                        "value" : "Reporting date"
                    },
                    {
                        "key" : "endTime",
                        "value" : "Actual Unloading date"
                    },
                    {
                        "key" : "unloading_duration",
                        "value" : "Detention Days"
                    },
                    {
                        "key" : "distance_travelled",
                        "value" : "Distance Travelled (Km)"
                    }

                ]

            }
            

        })