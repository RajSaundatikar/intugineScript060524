
        {
            "OPTED_FOR" : [
                "INDENT_MANAGEMENT"
            ],
            "INDENT_MANAGEMENT" : {
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Indent",
                        "path" : "/indent"
                    },
                    "BASE_URL" : "https://app2.superprocure.com/loadBoard",
                    "creds" : {
                        "URL_KEY" : "token",
                        "token" : "MjcwODI6MkIxN0I1ODREMUU1RjZFNzAxQTk3NTQ0NDM2QUU2QkY="
                    }
                }
            }
        }