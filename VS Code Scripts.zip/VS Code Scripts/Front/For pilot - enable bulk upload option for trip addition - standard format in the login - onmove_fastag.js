
    db.getCollection("users").updateOne(
        {username:"onmove_fastag"},
        {
            $set:{
                "config.trips.bulk_upload":{
                    "show" : true,
                    "edit" : true,
                    "google" : true
                    }
            }
        })