 // reports
    db.getCollection("users").updateMany(
        {"config.client":"Starline Express"},
        {
            $push:{
                "config.reports.report_extra_columns":
                           {
                                "key":"custom_trip_id",
                                "placeholder":"Trip ID"
                            }
                
            }
        })