
        db.getCollection("users").updateMany(
   {"config.client":"Shree Cements"},
   { $push: { "config.trips.newtripinputfields.$[elem].values": { "name": "SVT Logistics" } } },
   {
    arrayFilters: [
        { "elem.key": "vendor" }
    ]  
}
)