
db.getCollection("users").updateMany(
    { "config.client" : "Expeditors"  },
    {
        $set:{
            "config.trips.otheroption.otp_lock":true

        }
    })
