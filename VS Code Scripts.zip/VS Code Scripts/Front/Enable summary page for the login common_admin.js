
    db.getCollection("users").updateOne(
    { "username": "common_admin"
    },
    {
        $set:{
    
            "config.modules.SUMMARY":{
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Summary",
                        "path" : "/summary"
                    },
                    "BASE_URL" : "https://master.dmhqlqdb3g66s.amplifyapp.com/summary"
                }
            },
            
            "config.modules.OPTED_FOR": ["SUMMARY"],

            "config.home_path" : "/summary"
             
        }
    })



    
        
    $push:{
        "config.navbar_headers_field" :  {
            "title" : "SUMMARY",
            "path" : "/summary",
            "show" : true
        }
        
    }


   // "config.home_path" : "/summary", //2
   //"config.show_pages": "/summary"

//    "config.navbar_headers_field" : [ //3
//                 {
//                     "title" : "SUMMARY",
//                     "path" : "/summary",
//                     "show" : true
//                 },
//                 {
//                     "title" : "HOME",
//                     "path" : "/home",
//                     "show" : true
//                 },
//                 {
//                     "title" : "TRIPS",
//                     "path" : "/trips",
//                     "show" : true
//                 },
//                 {
//                     "title" : "TIMELINE",
//                     "path" : "/timeline",
//                     "show" : true
//                 },
//                 {
//                     "title" : "HISTORY",
//                     "path" : "/history",
//                     "show" : true
//                 },
               
//                 {
//                     "title" : "Live View",
//                     "path" : "/all-tracker",
//                     "show" : true
//                 },
//                 {
//                     "title" : "INDENT",
//                     "path" : "/indent",
//                     "show" : true
//                 }
                
//             ]   