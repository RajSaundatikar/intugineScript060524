
    db.getCollection("users").updateMany(
            {username:{
                $in: ["tgrao@gmmcoindia.com", "bsrinivasarao@gmmcoindia.com", "aamirsingh.r@gmmcoindia.com", "aamirsingh.r@gmmcoindia.com", "krishnakant@gmmcoindia.com", "sgpatel@gmmcoindia.com", "vijaykumartiwari@gmmcoindia.com", "mukeshkumardas@gmmcoindia.com", "ashokkumar.p@gmmcoindia.com", "ksmansoor@gmmcoindia.com", "rema@gmmcoindia.com", "rameshkrishnan@gmmcoindia.com", "sandeep.t@gmmcoindia.com", "dineshmishra@gmmcoindia.com", "nitintiwari.m@gmmcoindia.com", "pradipkumardas@gmmcoindia.com", "shivkumaryadav@gmmcoindia.com", "sujit@gmmcoindia.com", "rajasekaran.s@gmmcoindia.com", "pavankumar.k@gmmcoindia.com", "ksuresh@gmmcoindia.com"]
            }},
            {
                $set:{
                  
                    "config.trips.submittedtripoptions.edit":false
                }
            })