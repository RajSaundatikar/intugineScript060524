
     db.getCollection("users").updateOne(
    {username:"cx@solvezy.com"},
    {
        $set:{
            "config.filter_trips_by":["client_name"],
            "config.client_name":["Solv"]
        }
    })