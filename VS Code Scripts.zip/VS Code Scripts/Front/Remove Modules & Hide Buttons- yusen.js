
    //3 and 5
    db.getCollection("users").updateMany(
            {"username": { $in: ["yusen_nexg", "yusen_cbc", "yusen_sharp", "yusen_toray", "yusen_lumileds", "yusen_fisher", "yusen_technova", "yusen_adeka", "yusen_konica", "yusen_lexmark", "yusen_asics", "yusen_brother"] } },
            {
                $set:{
                    "config.trips.submittedtripoptions.status_update": false,
                    "config.trips.submittedtripoptions.hide_start_trip": true,
                    "config.trips.submittedtripoptions.hide_end_trip": true,
                    "config.trips.submittedtripoptions.hide_update_location": true,
                    "config.trips.otheroption.hide.consent_btn": true,
                    "config.home.otheroption.hide_filter" : true
                    
                }
            })


    //1 and 2

    // "config.extra_headers"
            
    //             "config.show_pages" : [
    //                 "/home",
    //                 "/trips",
    //                 "/history",
    //                 "/all-tracker",
    //                 "/indent",
    //                 "/timeline"
    //             ]


                db.getCollection("users").updateMany(
                    {"username": { $in: ["yusen_nexg", "yusen_cbc", "yusen_sharp", "yusen_toray", "yusen_lumileds", "yusen_fisher", "yusen_technova", "yusen_adeka", "yusen_konica", "yusen_lexmark", "yusen_asics", "yusen_brother"] } },
                    {
                        $pull:{
                           
                            "config.extra_headers": { "title" : "Analytics" }
                        }
                    })



                    db.getCollection("users").updateMany(
                        {"username": { $in: ["yusen_nexg", "yusen_cbc", "yusen_sharp", "yusen_toray", "yusen_lumileds", "yusen_fisher", "yusen_technova", "yusen_adeka", "yusen_konica", "yusen_lexmark", "yusen_asics", "yusen_brother"] } },
                        {
                            
                            $set:{
                                "config.show_pages" : [
                                    "/home",
                                    "/trips",
                                    "/history",
                                    "/all-tracker",
                                    "/indent",
                                    "/timeline"
                                ]
                            }
                        })



                        db.getCollection("users").updateMany(
                            {"username": { $in: ["yusen_nexg", "yusen_cbc", "yusen_sharp", "yusen_toray", "yusen_lumileds", "yusen_fisher", "yusen_technova", "yusen_adeka", "yusen_konica", "yusen_lexmark", "yusen_asics", "yusen_brother"] } },
                            {
                                $pull:{
                                   
                                    "config.trips.newtripinputfields": { "key" : "vendor" }
                                }
                            })