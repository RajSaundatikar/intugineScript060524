 "modules" : {
            "OPTED_FOR" : [
                "INDENT_MANAGEMENT"
            ],
            "INDENT_MANAGEMENT" : {
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Indent",
                        "path" : "/indent"
                    },
                    "BASE_URL" : "https://app2.superprocure.com/loadBoard",
                    "creds" : {
                        "URL_KEY" : "token",
                        "token" : "MTc3MTkxOjE2NTc2RUUyRDYzMTFEQUIwMEVBMDdFMkMxOTU5OTRF"
                    }
                }
            }
        },