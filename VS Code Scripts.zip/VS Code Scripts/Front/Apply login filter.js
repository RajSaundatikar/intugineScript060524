
       db.getCollection("users").updateOne(
    {username:"sachin.borkar@lanxess.com"},
    {
        $set:{
            "config.filter_trips_by":["srcname"],
            "config.srcname": ["Panvel Warehouse"]
        }
    })


    db.getCollection("users").updateOne(
        {username:"rajesh.yadav@lanxess.com"},
        {
            $set:{
                "config.filter_trips_by":["srcname"],
                "config.srcname": ["Bhiwandi Warehouse"]
            }
        })