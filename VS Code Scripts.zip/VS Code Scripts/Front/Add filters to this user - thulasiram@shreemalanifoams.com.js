
     db.getCollection("users").updateOne(
    {username:"thulasiram@shreemalanifoams.com"},
    {
        $set:{
            "config.filter_trips_by_and":["srcname", "destaddress"],
            "config.srcname": ["SMF - Chegunta", "CFPL - Khurda","CFPL - Medchal","CFPL - Kazipally","BANGALORE CFPL"],
            "config.destaddress": ["Karnataka", "Kerala" , "Telangana"]
        }
    })