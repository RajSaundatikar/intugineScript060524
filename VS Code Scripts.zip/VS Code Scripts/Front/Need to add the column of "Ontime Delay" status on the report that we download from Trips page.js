
    db.getCollection("users").updateMany(
    {
        "config.client": "BAYER"
    },
    {
        $push: {
            
            "config.trips.triplistheaders":{
                "key":"trip_delayed_status",
                "value":"Ontime/ Delay"
            }

        }

    })