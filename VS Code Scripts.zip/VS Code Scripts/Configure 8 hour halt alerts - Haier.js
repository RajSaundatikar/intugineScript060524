
db.getCollection("users").updateMany(
    {"config.client":"Haier"},{

        $set:{

            "config.alerts.alerts_info" : {
                "search_by" : {
                    "srcname" : {
                        "Haier - Noida" : ["mis.primary@ex.haierindia.com", "manish.dagar@haierindia.com", "rakesh.singh1@haierindia.com"],
                        "Haier - Pune" : ["Pune.hub3@ex.haierindia.com", "Pune.hub3@ex.haierindia.com", "prashant.konde@haierindia.com", "yogesh.wani@haierindia.com"]
                    }
                }
            },
            "config.alerts.halt" : {
                "recipients" : {
                    "internal" : [
                        
                    ],
                    "client" : [
                        
                    ],
                    "search_by" : [
                        "srcname"
                    ]
                },
                "haltParams" : [
                    {
                        "durationThreshold" : NumberInt(28800000),
                        "recipients" : [

                        ]
                    }
                ]
            }

        }

    })





            














            // ,
            // "delay" : {
            //     "recipients" : {
            //         "internal" : [
            //             "anuj@intugine.com",
            //             "aatman@intugine.com",
            //             "lavi@intugine.com"
            //         ],
            //         "client" : [
            //             "rrl.bangalore@yahoo.com"
            //         ],
            //         "search_by" : [
            //             "srcname"
            //         ]
            //     },
            //     "haltParams" : [
            //         {
            //             "durationThreshold" : NumberInt(28800000),
            //             "recipients" : [

            //             ]
            //         }
            //     ]
            // }
            