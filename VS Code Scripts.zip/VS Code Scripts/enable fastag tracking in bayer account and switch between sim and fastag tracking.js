
db.getCollection("users").updateMany(
  { "config.client": "BAYER" },
  { $set: { "config.tracking.parallel_fastag_fallback": true } }
);

////

db.getCollection("trips").updateMany(
  { user: "BAYER", running: true },
  {
    $set: { "tracking.parallel_fastag_fallback": true },
  }
);