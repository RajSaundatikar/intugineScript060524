db.getCollection("users").updateMany(
  {
    username: {
      $in: [
        "saroadlines082haier@gmail.com",
        "bhagwaticarrier4533haier@gmail.com",
        "shelkeroadlineshaier@yahoo.com",
        "ranjithaier@mahaveeratransport.com",
        "grtcmultimodeshaier@rediffmail.com",
        "sslogisticsregdhaier@gmail.com",
        "keshavroadlineshaier@yahoo.co.in",
        "maavaishnoroadways55haier@gmail.com",
        "gawade.machhindrahaier@mahindralogistics.com",
        "dosti.roadhaier@gmail.com",
      ],
    },
  },
  {
    $set: {
      "config.filter_trips_by": [],
      "config.filter_trips_by_and": ["srcname", "vendor"],
    },
  }
);

// ("Haier - Pune");

// Haier - Pune;

// ("Haier - Noida");
// ("Haier - Noida");
