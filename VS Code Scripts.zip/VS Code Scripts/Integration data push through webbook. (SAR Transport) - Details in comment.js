
    db.getCollection("users").updateMany(
    {"config.client": "SAR TRANSPORT"},
    { $set:{
        "config.tracking.webhookQueuePushEnabled": true,
        "config.tracking.webhookQueueLocationUrl": "https://api.mywebxpress.com/wh/in/sim/location/C00169?code=3ywZbXey118a5Rdzn65Hu5N6F7ktlcg0GLVXclRcgKVajuPwA7Ok5Q==&AccessKey=0c3dc784-4dc2-4ff1-ac28-cf0511e06ec0&subscription-key=2f6d8403265942b7a736e928b35c3c17",
        "config.tracking.webhookQueueLocationHeaders": {},
        "config.tracking.webhookQueueLocationPayloadStrategy": "DEFAULT"
    } })

    db.getCollection("trips").updateMany(
        {user: "SAR TRANSPORT", running: true},
        {
            $set:{
                "tracking.webhookQueuePushEnabled": true,
                  "tracking.webhookQueueLocationUrl": "https://api.mywebxpress.com/wh/in/sim/location/C00169?code=3ywZbXey118a5Rdzn65Hu5N6F7ktlcg0GLVXclRcgKVajuPwA7Ok5Q==&AccessKey=0c3dc784-4dc2-4ff1-ac28-cf0511e06ec0&subscription-key=2f6d8403265942b7a736e928b35c3c17",
                  "tracking.webhookQueueLocationHeaders": {},
                  "tracking.webhookQueueLocationPayloadStrategy": "DEFAULT"
            }
        }
        )




        // db.collection.updateMany(
        //     { "config.client": "SAR TRANSPORT" }, 
        //     {
        //        $set: {
        //           "config.tracking.webhookQueuePushEnabled": true,
        //           "config.tracking.webhookQueueLocationUrl": "https://api.mywebxpress.com/wh/in/sim/location/C00169?code=3ywZbXey118a5Rdzn65Hu5N6F7ktlcg0GLVXclRcgKVajuPwA7Ok5Q==&AccessKey=0c3dc784-4dc2-4ff1-ac28-cf0511e06ec0&subscription-key=2f6d8403265942b7a736e928b35c3c17",
        //           "config.tracking.webhookQueueLocationHeaders": {},
        //           "config.tracking.webhookQueueLocationPayloadStrategy": "DEFAULT"
        //        }
        //     }
        //  )
         