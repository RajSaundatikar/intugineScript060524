
     //Halt Alerts

      db.getCollection("users").updateMany(
        {"config.client" : "Pai Kane"},
        {
            $set:
            {
                "config.alerts.halt": {
                    "recipients": {
                        "internal": [
                            "support@intugine.com"
                        ],
                        "client": ["pundalik@paikane.com", "rajkumar@paikane.com", "cmslogistics@paikane.com", "swaroop@paikane.com", "siddharth.naik@paikane.com", "it.erp@paikane.com", "shawn@intugine.com"]
        
                    },
                    "haltParams": [{
                        "durationThreshold": 10800000,
                        "sendOncePerHalt": true,
                        "recipients": [
        
                        ]
                    }]
                }
            }
        
        })
    
    
        //ETA Breach and Geofence Alerts
    
        db.getCollection("geofence_alerts_temp").insertOne(
            {
            "user" : "Pai Kane",
            "geofenceAlertData" : {
            "src": 5000,
            "dest": 5000,
            "disableMailAlerts" : false,
            "displayName" : "Pai Kane",
            "alert_emails" : ["pundalik@paikane.com", "rajkumar@paikane.com", "cmslogistics@paikane.com", "swaroop@paikane.com", "siddharth.naik@paikane.com", "it.erp@paikane.com", "shawn@intugine.com"]
            }
    
            })



            db.getCollection("users").updateMany(
                { "config.client": "Pai Kane" },
                {
                  $set: {
                    "config.reachParams.geofence": 5000,
                    "config.tracking.geofence_radius.drop": 5000,
                  },
                }
              );