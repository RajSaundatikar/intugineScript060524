
    db.getCollection("trips").updateMany(
        {"user":"Kuehne + Nagel International AG_test" , "started_by":"kn_api_test" , "running": true},
        {
        $set:{
           "expiresAt": new Date(),
           "expiryNote": "Forced ended"
        }
        })