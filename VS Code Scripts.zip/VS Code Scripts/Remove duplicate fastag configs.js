
     db.getCollection("users").updateMany(
        {"config.client":{$in:["mahindra","Rhenus Logistics"]} },
        {
            $set: { "config.tracking.parallel_fastag_fallback": false },
          });

     db.getCollection("trips").updateMany(
    { user: {$in:["mahindra","Rhenus Logistics"]}, running: true },
    {
      $set: { "tracking.parallel_fastag_fallback": false },
    }
  );




          db.getCollection("configurations").deleteMany(
            {
                "action" : "ENABLE_FASTAG_IN_TRIPS", "user": {$in:["Philips","Lets Transport","Prism Cement","HMEL","VEGROW","LEAP INDIA"]}
          })