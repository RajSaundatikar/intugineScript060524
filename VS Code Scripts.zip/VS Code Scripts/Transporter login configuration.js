db.getCollection("users").updateMany(
  { "config.client": "Haier" },
  {
    $push: {
      "config.trips.newtripinputfields.$[elem].values": {
        $each: [
          { name: "Vayudoot Road Carriers Pvt.Ltd" },
          { name: "Kushwa Logistics" },
          { name: "Kapil Roadline" },
          { name: "ARSH LOGISTICS" },
        ],
      },
    },
  },
  {
    arrayFilters: [{ "elem.key": "vendor" }],
  }
);

//

db.getCollection("users").updateOne(
  { username: "a.banerjee_noida@vayudootlogistics.in" },
  {
    $set: {
      "config.filter_trips_by_and": ["srcname", "vendor"],
      "config.srcname": ["Haier - Noida"],
      "config.vendor": ["Vayudoot Road Carriers Pvt.Ltd"],
    },
  }
);

db.getCollection("users").updateOne(
  { username: "ravikush.kushwahalogistics_noida@gmail.com" },
  {
    $set: {
      "config.filter_trips_by_and": ["srcname", "vendor"],
      "config.srcname": ["Haier - Noida"],
      "config.vendor": ["Kushwa Logistics"],
    },
  }
);

db.getCollection("users").updateOne(
  { username: "kapilroadlines_noida@rediffmail.com" },
  {
    $set: {
      "config.filter_trips_by_and": ["srcname", "vendor"],
      "config.srcname": ["Haier - Noida"],
      "config.vendor": ["Kapil Roadline"],
    },
  }
);

db.getCollection("users").updateOne(
  { username: "arshlogistics2021_pune@gmail.com" },
  {
    $set: {
      "config.filter_trips_by_and": ["srcname", "vendor"],
      "config.srcname": ["Haier - Pune"],
      "config.vendor": ["ARSH LOGISTICS"],
    },
  }
);
