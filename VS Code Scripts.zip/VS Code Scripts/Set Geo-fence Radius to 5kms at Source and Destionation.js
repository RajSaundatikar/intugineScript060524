
//Set Geo-fence Radius to 5kms at Source and Destionation

db.getCollection("users").updateMany(
    { "config.client": "Ripplr" },
    {
      $set: {
        "config.reachParams.geofence": 5000
        
      },
    }
  );