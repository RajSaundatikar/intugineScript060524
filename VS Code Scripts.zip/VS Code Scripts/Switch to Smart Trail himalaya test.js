



//"Himalaya Test"
//30 mins



db.getCollection("users").updateMany(
    { "config.client" : "Himalaya Test" },
    {
      $set: {
        "config.location_providers": {
          airtel: {
            provider: "TELENITY",
            service: "SMARTTRAIL15",
          },
          idea: {
            provider: "TELENITY",
            service: "SMARTTRAIL15",
          },
          vodafone: {
            provider: "TELENITY",
            service: "SMARTTRAIL15",
          },
          jio: {
            provider: "JIO",
            service: "DEFAULT",
          },
          bsnl: {
            provider: "TELENITY",
            service: "SMARTTRAIL",
          },
        },
        "config.pingrate": 1800000,
      },
    }
  );