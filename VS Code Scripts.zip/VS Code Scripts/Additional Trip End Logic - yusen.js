
       //users
db.getCollection("users").updateMany(
    {"config.client": "Yusen Logistics"},
    {$set:{
        "config.trips.fixed_running_threshold":604800000

    }
    }
    )


//trips
    db.getCollection("trips").find(
        {user:"Yusen Logistics", running: true, $or:[{expiresAt:null},{expiryNote:"FIXED THRESHOLD EXCEEDED"}]})
        .sort({_id:-1}).forEach((k) => {
            print(k.startTime, new Date(k.startTime.valueOf() + 604800000))
        
           db.getCollection('trips').updateOne(
            {_id: k._id, },
                
             {
                $set: {
                    expiresAt: new Date(k.startTime.valueOf() + 604800000 ),
                expiryNote: "FIXED THRESHOLD EXCEEDED"
                        
                }
             })
        })