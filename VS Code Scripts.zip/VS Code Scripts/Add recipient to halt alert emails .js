db.getCollection("users").updateMany(
  { "config.client": "Haier", "config.alerts.halt": { $exists: true } },
  {
    $set: {
      "config.alerts.alerts_info.search_by.srcname": {
        "Haier - Noida": [
          "mis.primary@ex.haierindia.com",
          "manish.dagar@haierindia.com",
          "rakesh.singh1@haierindia.com",
          "rekha.kn@sitics.co",
          "sunil.pattewar@qbitscm.ai",
          "jishnu.qbit@sitics.co",
          "rekha.qbit@sitics.co",
        ],
        "Haier - Pune": [
          "Pune.hub3@ex.haierindia.com",
          "prashant.konde@haierindia.com",
          "yogesh.wani@haierindia.com",
          "rekha.kn@sitics.co",
          "sunil.pattewar@qbitscm.ai",
          "jishnu.qbit@sitics.co",
          "rekha.qbit@sitics.co",
        ],
      },
    },
  }
);
