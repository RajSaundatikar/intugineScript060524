db.getCollection("users").updateMany(
  {
    username: {
      $in: [
        "darshan@himalayawellness.com",
        "avinash.s@himalayawellness.com",
        "jagadish.v@himalayawellness.com",
        "prasad.s@himalayawellness.com",
        "sherwin.dhas@himalayawellness.com",
        "raghuveer.dk@himalayawellness.com",
        "bhaskar.reddy@himalayawellness.com",
        "rpa003@himalayawellness.com",
      ],
    },
  },
  {
    $set: {
      "config.modules.INDENT_MANAGEMENT.FRONTEND.BASE_URL":
        "https://app.superprocure.com/SalesOrder/",
    },
  }
);

db.getCollection("users").updateMany(
  {
    username: {
      $in: [
        "darshan@himalayawellness.com",
        "avinash.s@himalayawellness.com",
        "jagadish.v@himalayawellness.com",
        "prasad.s@himalayawellness.com",
        "sherwin.dhas@himalayawellness.com",
        "raghuveer.dk@himalayawellness.com",
        "bhaskar.reddy@himalayawellness.com",
        "rpa003@himalayawellness.com",
      ],
    },
  },
  {
    $push: {
      "config.show_pages": "/indent",
    },
  }
);
