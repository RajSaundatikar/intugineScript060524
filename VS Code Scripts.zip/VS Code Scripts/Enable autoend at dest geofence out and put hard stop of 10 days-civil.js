
db.getCollection("users").updateMany(
    { "config.client": "CivilBaba" },
    {
      $set: {
        "config.reachParams.geofence": 5000
        
      },
    }
  );
    
    
    
    
    db.getCollection("users").updateMany(
    {"config.client": "CivilBaba"},
        {    $set:{
                "config.reachParams.geofence_out.trip_changes.endsIn": 1,
                    }
        }
    )


    
    //users
db.getCollection("users").updateMany(
    {"config.client": "CivilBaba"},
    {$set:{
        "config.trips.fixed_running_threshold": 864000000

    }
    }
    )


//trips
    db.getCollection("trips").find(
        {user:"CivilBaba", running: true, $or:[{expiresAt:null},{expiryNote:"FIXED THRESHOLD EXCEEDED"}]})
        .sort({_id:-1}).forEach((k) => {
            print(k.startTime, new Date(k.startTime.valueOf() + 864000000))
        
           db.getCollection('trips').updateOne(
            {_id: k._id, },
                
             {
                $set: {
                    expiresAt: new Date(k.startTime.valueOf() + 864000000 ),
                expiryNote: "FIXED THRESHOLD EXCEEDED"
                        
                }
             })
        })