
    db.getCollection("users").updateMany(
        { "username": { $in: ["sumohan.d@flipkart.com", "manoj.kg@flipkart.com", "vijay.gaikwad@flipkart.com", "gauravkumar.dubey@flipkart.com",
        "arvind.anand@flipkart.com", "momin.roofi@flipkart.com", "kapil.rohit@flipkart.com", "gulamgaus.momin@flipkart.com", "hemant.sunil@flipkart.com", "vhora.farukbhai@flipkart.com", 
        "sohilsha.fakir@flipkart.com", "kumar.kanhaiya@flipkart.com", "mudshirhusen.sayyed@flipkart.com", "hitendra.kumar@flipkart.com", "mayur.getme@flipkart.com", "g.rajan@flipkart.com", 
        "balaji.nv@flipkart.com", "rajesh.p@flipkart.com", "lakshman.naik@flipkart.com", "vishnu.prabha@flipkart.com", "vignesh.venkadesan@flipkart.com", "rajadurai.m@flipkart.com", 
        "mohamed.aqyar@flipkart.com", "amaresh.s@flipkart.com"] } },
    {
        $addToSet:{
            "config.modules.OPTED_FOR": "YARD_MANAGEMENT"
              
        },

        $set:{
            "config.modules.YARD_MANAGEMENT":{
                "FRONTEND" : {
                    "NAV" : {
                        "title" : "Yard Management",
                        "path" : "/yard"
                    },
                    "BASE_URL" : "https://dq2sjc9nuei5i.cloudfront.net/"
                }
            }
        }
    }
    )


    db.getCollection("users").updateMany(
        { "username": { $in: ["sumohan.d@flipkart.com", "manoj.kg@flipkart.com", "vijay.gaikwad@flipkart.com", "gauravkumar.dubey@flipkart.com",
        "arvind.anand@flipkart.com", "momin.roofi@flipkart.com", "kapil.rohit@flipkart.com", "gulamgaus.momin@flipkart.com", "hemant.sunil@flipkart.com", "vhora.farukbhai@flipkart.com", 
        "sohilsha.fakir@flipkart.com", "kumar.kanhaiya@flipkart.com", "mudshirhusen.sayyed@flipkart.com", "hitendra.kumar@flipkart.com", "mayur.getme@flipkart.com", "g.rajan@flipkart.com", 
        "balaji.nv@flipkart.com", "rajesh.p@flipkart.com", "lakshman.naik@flipkart.com", "vishnu.prabha@flipkart.com", "vignesh.venkadesan@flipkart.com", "rajadurai.m@flipkart.com", 
        "mohamed.aqyar@flipkart.com", "amaresh.s@flipkart.com"] } , "config.show_pages":{$exists:true }},
        {
            $addToSet:{
                "config.show_pages" : "/yard"
            }
        })