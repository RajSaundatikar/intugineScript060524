
    "Himalaya Test"


    db.getCollection("users").updateMany(
  { "config.client": "Himalaya Test" },
  { $set: { "config.tracking.parallel_fastag_fallback": true } }
);

////

db.getCollection("trips").updateMany(
  { user: "Himalaya Test", running: true },
  {
    $set: { "tracking.parallel_fastag_fallback": true },
  }
);